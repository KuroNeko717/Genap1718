<?php require_once('Connections/koneksi.php'); ?><?php require_once('Connections/koneksi.php'); 
if (!isset($_SESSION)) {
  session_start();
}

$group = $_SESSION['MM_UserGroup'];

if($group == "ADMIN"){
include('menu.php');
} elseif ($group == "PANITIA"){
include('menu2.php');
} else {
header( 'Location: input.php' ) ;
}


?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_koneksi, $koneksi);
$query_daftarberita = "SELECT IDBERITA, JUDUL FROM berita ORDER BY IDBERITA DESC";
$daftarberita = mysql_query($query_daftarberita, $koneksi) or die(mysql_error());
$row_daftarberita = mysql_fetch_assoc($daftarberita);
$totalRows_daftarberita = mysql_num_rows($daftarberita);
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Untitled Document</title>
</head>

<body>
<p>DAFTAR INFORMASI</p>
<p><a href="beritaisi.php">TULIS INFO</a></p>

<table border="1" cellpadding="0" cellspacing="0" class="myTable">
  <tr class="myTableth">
    <td width="40">ID</td>
    <td width="136">JUDUL INFO</td>
    <td width="69">Hapus</td>
  </tr>
  <?php do { ?>
    <tr>
      <td width="40"><?php echo $row_daftarberita['IDBERITA']; ?></td>
      <td><?php echo $row_daftarberita['JUDUL']; ?></td>
      <td><input type="button" onClick="show_confirm_del<?php echo $row_daftarberita['IDBERITA']; ?>()" value="Delete" />
      
<script type="text/javascript">
function show_confirm_del<?php echo $row_daftarberita['IDBERITA']; ?>()
{
var r=confirm("Anda Akan Menghapus<?php echo $row_daftarberita['JUDUL']; ?>");
if (r==true)
  {
  window.location="beritadel.php?IDBERITA=<?php echo $row_daftarberita['IDBERITA']; ?>";
  }
}
</script>


</td>
    </tr>
    <?php } while ($row_daftarberita = mysql_fetch_assoc($daftarberita)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($daftarberita);

?>
