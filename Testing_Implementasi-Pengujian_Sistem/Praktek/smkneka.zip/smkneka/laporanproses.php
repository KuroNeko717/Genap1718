<?php require_once('Connections/koneksi.php');  

if (!isset($_SESSION)) {
  session_start();
}

$group = $_SESSION['MM_UserGroup'];

if($group == "ADMIN"){
include('menu.php');
} elseif ($group == "PANITIA"){
include('menu2.php');
} else {
header( 'Location: input.php' ) ;
}

   $mtime = microtime();
   $mtime = explode(" ",$mtime);
   $mtime = $mtime[1] + $mtime[0];
   $starttime = $mtime; 
   
   
   $querydel = "truncate table nilaiakhir";
	mysql_query($querydel);

?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}



$IDJUR = 4;


mysql_select_db($database_koneksi, $koneksi);
$query_pendaftar = "SELECT IDPENDAFTARAN, IDPILJUR1, NOPENDAFTARAN, NAMASISWA, NUN, jurusan.NAMAJURUSAN FROM calonsiswa, jurusan WHERE jurusan.IDJUR = calonsiswa.IDPILJUR1";
$pendaftar = mysql_query($query_pendaftar, $koneksi) or die(mysql_error());
$row_pendaftar = mysql_fetch_assoc($pendaftar);
$totalRows_pendaftar = mysql_num_rows($pendaftar);

mysql_select_db($database_koneksi, $koneksi);
$query_bobot = "SELECT SET1 as BOBOTUN, SET2 as SKORMAKSUN FROM setting WHERE IDSET = 3";
$bobot = mysql_query($query_bobot, $koneksi) or die(mysql_error());
$row_bobot = mysql_fetch_assoc($bobot);
$totalRows_bobot = mysql_num_rows($bobot);




?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style3 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 10px;
}
.style4 {
	font-size: 24px;
	font-weight: bold;
	font-family: Geneva, Arial, Helvetica, sans-serif;
	color: #333333;
}
-->
</style>
</head>

<body>
<table width="802" border="1" cellpadding="0" cellspacing="0">
  <tr>
    <td width="17"><span class="style3">No</span></td>
    <td width="80"><div align="center"><span class="style3">NO DAFTAR</span></div></td>
    <td width="184"><div align="center"><span class="style3">NAMA</span></div></td>
    <td width="164"><div align="center"><span class="style3">JURUSAN</span></div></td>
    <td width="92"><div align="center"><span class="style3">NUN</span></div></td>
    <td width="92"><div align="center"><span class="style3">&sum; NUN</span></div></td>
    <td width="92"><div align="center"><span class="style3">Ujian Sekolah</span></div></td>
    <td width="92"><div align="center"><span class="style3">NA</span></div></td>
  </tr>
  <?php 
  $i = 1;
  do { ?>
    <tr>
      <td width="17" class="style3"><?php echo $i; $i++; ?></td>
      <td width="80" class="style3"><div align="center"><?php echo $row_pendaftar['NOPENDAFTARAN']; ?></div></td>
       <?php 
	  $IDSISWA = $row_pendaftar['IDPENDAFTARAN'];
	  mysql_select_db($database_koneksi, $koneksi);
		$query_nilaiujian = "SELECT ROUND(SUM((nilai.NILAIUJIAN/ujian.SKORMAKSIMAL)*ujian.BOBOT),2) as ujiansekolah
							FROM nilai INNER JOIN ujian ON nilai.IDUJIAN = ujian.IDUJIAN 
							WHERE nilai.IDPENDAFTARAN = '$IDSISWA'";
		$nilaiujian = mysql_query($query_nilaiujian, $koneksi) or die(mysql_error());
		$row_nilaiujian = mysql_fetch_assoc($nilaiujian);
	  
	  ?>
       <?php 
	  $NUNOKE1 = ($row_pendaftar['NUN']/$row_bobot['SKORMAKSUN']);
	  $NUNOKE =  $NUNOKE1 * $row_bobot['BOBOTUN'];
	  $USOKE = $row_nilaiujian['ujiansekolah'];
	  $NAOKE = $NUNOKE + $row_nilaiujian['ujiansekolah'];

	  
	  $kueri ="INSERT INTO nilaiakhir (IDPENDAFTARAN,NUN,US,NA) VALUES 		
	  			('$IDSISWA','$NUNOKE','$USOKE','$NAOKE')"; 
 		
  mysql_select_db($database_koneksi, $koneksi);
  $Result1 = mysql_query($kueri, $koneksi) or die(mysql_error());
	  
	  ?>
      
      
      
      <td width="184" class="style3"><div align="left"><?php echo $row_pendaftar['NAMASISWA']; ?></div></td>
      <td class="style3"><div align="center"><?php echo $row_pendaftar['NAMAJURUSAN']; ?></div></td>
      <td class="style3"><div align="center"><?php echo $row_pendaftar['NUN']; ?></div></td>
      <td class="style3"><div align="center"><?php echo round($NUNOKE,2,2); ?>
      </div></td>
      <td width="92"><div align="center"><span class="style3"><?php echo $row_nilaiujian['ujiansekolah']; ?></span></div></td>
      <td width="92">
        <div align="center"><span class="style3"><?php echo round($NAOKE,2,2);?></span>
      &nbsp;</div></td>
    </tr>
    <?php } while ($row_pendaftar = mysql_fetch_assoc($pendaftar)); ?>
  <tr>
    <td width="17">&nbsp;</td>
    <td width="80">&nbsp;</td>
    <td width="184">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td width="92">&nbsp;</td>
    <td width="92">&nbsp;</td>
  </tr>
</table>
 <p><a href="input.php" class="style4">INPUT PENDAFTARAN</a></p>
<p class="style3">&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($pendaftar);

mysql_free_result($bobot);
mysql_free_result($nilaiujian);

 include('rangking.php'); 
 
 
   $mtime = microtime();
   $mtime = explode(" ",$mtime);
   $mtime = $mtime[1] + $mtime[0];
   $endtime = $mtime;
   $totaltime = ($endtime - $starttime);
 //  echo "<p class='style3'>Query Time : ".$totaltime." seconds,   Proses Berhasil </p>"; 
   
 
?>
