<?php require_once('Connections/koneksi.php');
include ('menu.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE petugas SET NAMAPETUGAS=%s, USERNAMEPETUGAS=%s, PASSWORDPETUGAS=%s, `LEVEL`=%s WHERE IDPETUGAS=%s",
                       GetSQLValueString($_POST['NAMAPETUGAS'], "text"),
                       GetSQLValueString($_POST['USERNAMEPETUGAS'], "text"),
                       GetSQLValueString(md5($_POST['PASSWORDPETUGAS1']), "text"),
                       GetSQLValueString($_POST['LEVEL'], "text"),
                       GetSQLValueString($_POST['IDPETUGAS'], "int"));

  mysql_select_db($database_koneksi, $koneksi);
  $Result1 = mysql_query($updateSQL, $koneksi) or die(mysql_error());

  $updateGoTo = "user.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_Recordset1 = "-1";
if (isset($_GET['IDPETUGAS'])) {
  $colname_Recordset1 = $_GET['IDPETUGAS'];
}
mysql_select_db($database_koneksi, $koneksi);
$query_Recordset1 = sprintf("SELECT * FROM petugas WHERE IDPETUGAS = %s", GetSQLValueString($colname_Recordset1, "int"));
$Recordset1 = mysql_query($query_Recordset1, $koneksi) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>


<script type="text/javascript"> 
 
function checkForm(form) { 
 
if(form.PASSWORDPETUGAS1.value != "" && form.PASSWORDPETUGAS1.value == form.PASSWORDPETUGAS2.value) { 
if(!checkPassword(form.PASSWORDPETUGAS1.value)) { 
alert("The password you have entered is not valid!"); 
form.PASSWORDPETUGAS1.focus(); 
return false; } 
} else { 
alert("Error: Please check that you've entered and confirmed your password!"); 
form.PASSWORDPETUGAS1.focus();
 return false; } 
 return true; } 
 </script>
</head>

<body>
EDIT PETUGAS<br>



<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1" onsubmit="return checkForm(this);">
  <table align="left">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">ID Petugas</div></td>
      <td><?php echo $row_Recordset1['IDPETUGAS']; ?></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Nama Petugas</div></td>
      <td><input type="text" name="NAMAPETUGAS" value="<?php echo htmlentities($row_Recordset1['NAMAPETUGAS'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Username</div></td>
      <td><input type="text" name="USERNAMEPETUGAS" value="<?php echo htmlentities($row_Recordset1['USERNAMEPETUGAS'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Password</div></td>
      <td><input type="password" name="PASSWORDPETUGAS1" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Confirm Password</div></td>
      <td><input type="password" name="PASSWORDPETUGAS2" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Level</div></td>
      <td><select name="LEVEL">
        <option value="PETUGAS" <?php if (!(strcmp("PETUGAS", htmlentities($row_Recordset1['LEVEL'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>PETUGAS</option>
        <option value="PANITIA" <?php if (!(strcmp("PANITIA", htmlentities($row_Recordset1['LEVEL'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>PANITIA</option>
        <option value="ADMIN" <?php if (!(strcmp("ADMIN", htmlentities($row_Recordset1['LEVEL'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>ADMIN</option>
      </select>      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Update" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_update" value="form1" />
  <input type="hidden" name="IDPETUGAS" value="<?php echo $row_Recordset1['IDPETUGAS']; ?>" />
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
