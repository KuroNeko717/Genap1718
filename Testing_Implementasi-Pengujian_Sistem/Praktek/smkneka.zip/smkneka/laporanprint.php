<?php require_once('Connections/koneksi.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?><?php require_once('Connections/koneksi.php'); 


mysql_select_db($database_koneksi, $koneksi);
$query_jurusan = "SELECT * FROM jurusan ORDER BY IDJUR ASC";
$jurusan = mysql_query($query_jurusan, $koneksi) or die(mysql_error());
$row_jurusan = mysql_fetch_assoc($jurusan);
$totalRows_jurusan = mysql_num_rows($jurusan);

?>
<?php
$IDJUR = $_GET['IDJUR'];

$kuerikuota = "select jurusan.JUMLAHMAKS from jurusan where IDJUR = '$IDJUR'";
$kuota = mysql_query($kuerikuota);
$row_kuota = mysql_fetch_assoc($kuota);


mysql_select_db($database_koneksi, $koneksi);
$query_Recordset1 = "SELECT rangking.PERINGKAT, rangking.IDPENDAFTARAN, calonsiswa.NOPENDAFTARAN, calonsiswa.NAMASISWA, calonsiswa.ASALSMP, calonsiswa.NUN as UN, rangking.IDJUR, jurusan.NAMAJURUSAN, nilaiakhir.NUN, nilaiakhir.US, nilaiakhir.NA, rangking.PIL1, rangking.PIL2, if(rangking.PIL1=rangking.IDJUR,'Pilihan 1','Pilihan 2') as Pilihan FROM rangking INNER JOIN calonsiswa ON rangking.IDPENDAFTARAN = calonsiswa.IDPENDAFTARAN INNER JOIN nilaiakhir ON rangking.IDPENDAFTARAN = nilaiakhir.IDPENDAFTARAN INNER JOIN jurusan ON rangking.IDJUR = jurusan.IDJUR WHERE rangking.IDJUR = '$IDJUR' ";
$Recordset1 = mysql_query($query_Recordset1, $koneksi) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $title ?></title>
<style type="text/css">
<!--
.myTable {background-color:#FFFFE0;border-collapse:collapse; }
.style1 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style3 {font-size: 12px}
-->
</style>
</head>

<body>

<p align="center">PENGUMUMAN PENERIMAAN PESERTA DIDIK BARU<br />
<?php echo $NamaSekolah?> TAHUN PELAJARAN <?php echo $TahunPelajaran?></p>
<p align="center">DAFTAR PERINGKAT PROGRAM KEAHLIAN <?php echo $row_Recordset1['NAMAJURUSAN']; ?><br />
  JUMLAH KUOTA : <?php echo  $row_kuota['JUMLAHMAKS'];?></p>
<table width="800" border="1" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="30"><div align="center">No</div></td>
    <td width="50"><div align="center">No Pendaftaran</div></td>
    <td width="177"><div align="center">Nama Calon Siswa</div></td>
    <td width="148"><div align="center">Asal Sekolah</div></td>
    <td width="40"><div align="center">NUN</div></td>
    <td width="40"><div align="center">Nilai Ujian</div></td>
    <td width="40"><div align="center">Total Nilai</div></td>
    <td width="40"><div align="center">Keterangan</div></td>
  </tr>
  <?php 
  $i = 1;
  do { ?>
    <tr>
      <td><div align="center"><?php echo $i; $i++ ?></div></td>
      <td><div align="center"><?php echo $row_Recordset1['NOPENDAFTARAN']; ?></div></td>
      <td><?php echo $row_Recordset1['NAMASISWA']; ?></td>
      <td><?php echo $row_Recordset1['ASALSMP']; ?></td>
      <td><div align="right"><?php echo $row_Recordset1['NUN']; ?></div></td>
      <td><div align="right"><?php echo $row_Recordset1['US']; ?></div></td>
      <td><div align="right"><?php echo $row_Recordset1['NA']; ?></div></td>
      <td>
        <div align="center">
          <?php 
	  if ($i<=$row_kuota['JUMLAHMAKS']+1){
	  	echo "Diterima";
		} else {
		echo "<strong><font color='#FF0000'>Pending</font></strong>";
		}
	  
	  ?>
          
        </div></td>
    </tr>
    <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
