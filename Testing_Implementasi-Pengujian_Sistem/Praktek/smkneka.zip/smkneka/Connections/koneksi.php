<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_koneksi = "localhost";
$database_koneksi = "psb";
$username_koneksi = "root";
$password_koneksi = "root";
$koneksi = mysql_pconnect($hostname_koneksi, $username_koneksi, $password_koneksi) or trigger_error(mysql_error(),E_USER_ERROR);

//====================
$title = "PPDB Online SMK Negeri 1 Kalitengah";
$NamaSekolah = "SMK NEGERI 1 KALITENGAH";
$TahunPelajaran = "2012-2013";
$Kepsek = "Drs. Ali Imron";
$KetuaPanitiaPPDB ="Ekwanto, S.Pd";
//====================
// KETERANGAN LAPORAN
$Laporan1 = "Lulus";
$Laporan2 = "Lulus dengan Pilihan Lain";
$Laporan3 = "Tidak Lulus / Tes Ulang";
$Laporan4 = "Tidak Lulus";

//====================
$jumlahsesiujian = 15;

?>
