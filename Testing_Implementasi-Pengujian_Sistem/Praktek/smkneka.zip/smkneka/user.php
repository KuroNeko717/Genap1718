<?php require_once('Connections/koneksi.php'); 
include ('menu.php');
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_koneksi, $koneksi);
$query_Recordset1 = "SELECT * FROM petugas";
$Recordset1 = mysql_query($query_Recordset1, $koneksi) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
PETUGAS PPDB<br />
<br />
 
<input type="button" value="Tambah User Baru" onclick="window.location ='useradd.php'"  />
<br />
<br />
<table width="610" border="1" class="myTable">
  <tr class="myTableth">
    <td width="30"><div align="center">No</div></td>
    <td width="150"><div align="center">Nama Lengkap</div></td>
    <td width="150"><div align="center">Username</div></td>
    <td width="80"><div align="center">Level</div></td>
    <td width="200"><div align="center">Edit</div></td>
  </tr>
  <?php 
  $i=1;
  do { ?>
    <tr>
      <td width="30"><div align="center"><?php echo $i; $i++ ?></div></td>
      <td width="150"><div align="center"><?php echo $row_Recordset1['NAMAPETUGAS']; ?></div></td>
      <td width="150"><div align="center"><?php echo $row_Recordset1['USERNAMEPETUGAS']; ?></div></td>
      <td width="80"><div align="center"><?php echo $row_Recordset1['LEVEL']; ?></div></td>
      <td width="200">
        <div align="center">
  <input type="button" value="  Edit " onclick="window.location ='useredit.php?IDPETUGAS=<?php echo $row_Recordset1['IDPETUGAS']; ?>'"  />
  </a>&nbsp;&nbsp;
          <input type="button" onClick="show_confirm_del<?php echo $row_Recordset1['IDPETUGAS']; ?>()" value="Delete" />
          
           <script type="text/javascript">
function show_confirm_del<?php echo $row_Recordset1['IDPETUGAS']; ?>()
{
var r=confirm("Anda Akan Menghapus <?php echo $row_Recordset1['NAMAPETUGAS']; ?>");
if (r==true)
  {
  window.location="userdel.php?IDPETUGAS=<?php echo $row_Recordset1['IDPETUGAS']; ?>";
  }
}
         </script>
        </div></td>
    </tr>
    <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
