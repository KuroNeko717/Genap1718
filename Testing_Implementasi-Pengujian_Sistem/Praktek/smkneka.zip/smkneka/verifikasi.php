<?php require_once('Connections/koneksi.php'); ?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "index1.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php require_once('Connections/koneksi.php'); 


?>
<?php

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO calonsiswa (IDPILJUR1, IDPILJUR2, IDPETUGAS, NOPENDAFTARAN, NAMASISWA, TEMPATLAHIR, TGLLAHIR, JENISKELAMIN, AGAMA, ALAMAT, KOTAALAMAT, PROPINSI, NOTELPRUMAH, NOHP, FOTO, NOIJASAH, TGLIJASAH, NUN, NOSKHUN, TGLSKHUN, ASALSMP, KOTAASALSMP, NAMAAYAH, PEKERJAANAYAH, NOHPAYAH, NAMAIBU, PEKERJAANIBU, ALAMATAYAH, KOTAALAMATAYAH, NAMAWALI, ALAMATWALI, PEKERJAANWALI, NOHPWALI, PRESTASI, CATATANLAIN, APPROVE) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['IDPILJUR1'], "int"),
                       GetSQLValueString($_POST['IDPILJUR2'], "int"),
                       GetSQLValueString($_POST['IDPETUGAS'], "int"),
                       GetSQLValueString($_POST['NOPENDAFTARAN'], "int"),
                       GetSQLValueString($_POST['NAMASISWA'], "text"),
                       GetSQLValueString($_POST['TEMPATLAHIR'], "text"),
                       GetSQLValueString($_POST['TGLLAHIR'], "text"),
                       GetSQLValueString($_POST['JENISKELAMIN'], "text"),
                       GetSQLValueString($_POST['AGAMA'], "text"),
                       GetSQLValueString($_POST['ALAMAT'], "text"),
                       GetSQLValueString($_POST['KOTAALAMAT'], "text"),
                       GetSQLValueString($_POST['PROPINSI'], "text"),
                       GetSQLValueString($_POST['NOTELPRUMAH'], "text"),
                       GetSQLValueString($_POST['NOHP'], "text"),
                       GetSQLValueString($_POST['FOTO'], "text"),
                       GetSQLValueString($_POST['NOIJASAH'], "text"),
                       GetSQLValueString($_POST['TGLIJASAH'], "text"),
                       GetSQLValueString($_POST['NUN'], "text"),
                       GetSQLValueString($_POST['NOSKHUN'], "text"),
                       GetSQLValueString($_POST['TGLSKHUN'], "text"),
                       GetSQLValueString($_POST['ASALSMP'], "text"),
                       GetSQLValueString($_POST['KOTAASALSMP'], "text"),
                       GetSQLValueString($_POST['NAMAAYAH'], "text"),
                       GetSQLValueString($_POST['PEKERJAANAYAH'], "text"),
                       GetSQLValueString($_POST['NOHPAYAH'], "text"),
                       GetSQLValueString($_POST['NAMAIBU'], "text"),
                       GetSQLValueString($_POST['PEKERJAANIBU'], "text"),
                       GetSQLValueString($_POST['ALAMATAYAH'], "text"),
                       GetSQLValueString($_POST['KOTAALAMATAYAH'], "text"),
                       GetSQLValueString($_POST['NAMAWALI'], "text"),
                       GetSQLValueString($_POST['ALAMATWALI'], "text"),
                       GetSQLValueString($_POST['PEKERJAANWALI'], "text"),
                       GetSQLValueString($_POST['NOHPWALI'], "text"),
                       GetSQLValueString($_POST['PRESTASI'], "text"),
                       GetSQLValueString($_POST['CATATANLAIN'], "text"),
                       GetSQLValueString($_POST['APPROVE'], "text"));

  mysql_select_db($database_koneksi, $koneksi);
  $Result1 = mysql_query($insertSQL, $koneksi) or die(mysql_error());

  $insertGoTo = "pendaftardel.php?IDPENDAFTARAN=".$row_Recordset1['IDPENDAFTARAN'];
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

$colname_Recordset1 = "-1";
if (isset($_GET['IDPENDAFTARAN'])) {
  $colname_Recordset1 = $_GET['IDPENDAFTARAN'];
}
mysql_select_db($database_koneksi, $koneksi);
$query_Recordset1 = sprintf("SELECT * FROM calon WHERE IDPENDAFTARAN = %s", GetSQLValueString($colname_Recordset1, "int"));
$Recordset1 = mysql_query($query_Recordset1, $koneksi) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);

mysql_select_db($database_koneksi, $koneksi);
$query_jurusan = "SELECT * FROM jurusan ORDER by IDJUR";
$jurusan = mysql_query($query_jurusan, $koneksi) or die(mysql_error());
$row_jurusan = mysql_fetch_assoc($jurusan);
$totalRows_jurusan = mysql_num_rows($jurusan);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {
	color: #FF0000;
	font-size: small;
	font-style: italic;
}
-->
</style>
</head>

<body>
<img src="images/header.jpg" />

<form action="<?php echo $editFormAction; ?>" method="POST" name="form1" id="form1">
  <table align="left">
    <tr valign="baseline">
      <td width="156" align="right" nowrap="nowrap"><div align="left">Pilihan 1:</div></td>
      <td width="272"><select name="IDPILJUR1">
        <?php
do {  
?>
        <option value="<?php echo $row_jurusan['IDJUR']?>"<?php if (!(strcmp($row_jurusan['IDJUR'], htmlentities($row_Recordset1['IDPILJUR1'], ENT_COMPAT, 'utf-8')))) {echo "selected=\"selected\"";} ?>><?php echo $row_jurusan['NAMAJURUSAN']?></option>
<?php
} while ($row_jurusan = mysql_fetch_assoc($jurusan));
  $rows = mysql_num_rows($jurusan);
  if($rows > 0) {
      mysql_data_seek($jurusan, 0);
	  $row_jurusan = mysql_fetch_assoc($jurusan);
  }
?>
      </select>      </td>
      <td width="22">&nbsp;</td>
      <td width="141"><div align="left">NOPENDAFTARAN:</div></td>
      <td width="232"><input type="text" name="NOPENDAFTARAN" value="<?php echo htmlentities($row_Recordset1['NOPENDAFTARAN'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Pilihan 2:</div></td>
      <td><select name="IDPILJUR2">
        <?php
do {  
?>
        <option value="<?php echo $row_jurusan['IDJUR']?>"<?php if (!(strcmp($row_jurusan['IDJUR'], $row_Recordset1['IDPILJUR2']))) {echo "selected=\"selected\"";} ?>><?php echo $row_jurusan['NAMAJURUSAN']?></option>
<?php
} while ($row_jurusan = mysql_fetch_assoc($jurusan));
  $rows = mysql_num_rows($jurusan);
  if($rows > 0) {
      mysql_data_seek($jurusan, 0);
	  $row_jurusan = mysql_fetch_assoc($jurusan);
  }
?>
                  </select></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left"></div></td>
      <td><input type="hidden" name="IDPETUGAS" value="<?php echo htmlentities($row_Recordset1['IDPETUGAS'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Nama Siswa:</div></td>
      <td><input type="text" name="NAMASISWA" value="<?php echo htmlentities($row_Recordset1['NAMASISWA'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td align="right" nowrap="nowrap"><div align="left">NOIJASAH:</div></td>
      <td><input type="text" name="NOIJASAH" value="<?php echo htmlentities($row_Recordset1['NOIJASAH'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Tempat Lahir:</div></td>
      <td><input type="text" name="TEMPATLAHIR" value="<?php echo htmlentities($row_Recordset1['TEMPATLAHIR'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td align="right" nowrap="nowrap"><div align="left">TGLIJASAH:</div></td>
      <td><input type="text" name="TGLIJASAH" value="<?php echo htmlentities($row_Recordset1['TGLIJASAH'], ENT_COMPAT, 'utf-8'); ?>" size="32" />
      <span class="style1">(yyyymmdd)</span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Tanggal Lahir:</div></td>
      <td><input type="text" name="TGLLAHIR" value="<?php echo htmlentities($row_Recordset1['TGLLAHIR'], ENT_COMPAT, 'utf-8'); ?>" size="32" /> 
        <span class="style1">(yyyymmdd)</span></td>
      <td>&nbsp;</td>
      <td align="right" nowrap="nowrap"><div align="left">NUN:</div></td>
      <td><input type="text" name="NUN" value="<?php echo htmlentities($row_Recordset1['NUN'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">JENISKELAMIN:</div></td>
      <td><input type="text" name="JENISKELAMIN" value="<?php echo htmlentities($row_Recordset1['JENISKELAMIN'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td align="right" nowrap="nowrap"><div align="left">NOSKHUN:</div></td>
      <td><input type="text" name="NOSKHUN" value="<?php echo htmlentities($row_Recordset1['NOSKHUN'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">AGAMA:</div></td>
      <td><input type="text" name="AGAMA" value="<?php echo htmlentities($row_Recordset1['AGAMA'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td align="right" nowrap="nowrap"><div align="left">TGLSKHUN:</div></td>
      <td><input type="text" name="TGLSKHUN" value="<?php echo htmlentities($row_Recordset1['TGLSKHUN'], ENT_COMPAT, 'utf-8'); ?>" size="32" />
      <span class="style1">(yyyymmdd)</span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">ALAMAT:</div></td>
      <td><input type="text" name="ALAMAT" value="<?php echo htmlentities($row_Recordset1['ALAMAT'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td align="right" nowrap="nowrap"><div align="left">ASALSMP:</div></td>
      <td><input type="text" name="ASALSMP" value="<?php echo htmlentities($row_Recordset1['ASALSMP'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">KOTAALAMAT:</div></td>
      <td><input type="text" name="KOTAALAMAT" value="<?php echo htmlentities($row_Recordset1['KOTAALAMAT'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td align="right" nowrap="nowrap"><div align="left">KOTAASALSMP:</div></td>
      <td><input type="text" name="KOTAASALSMP" value="<?php echo htmlentities($row_Recordset1['KOTAASALSMP'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">PROPINSI:</div></td>
      <td><input type="text" name="PROPINSI" value="<?php echo htmlentities($row_Recordset1['PROPINSI'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">NOTELPRUMAH:</div></td>
      <td><input type="text" name="NOTELPRUMAH" value="<?php echo htmlentities($row_Recordset1['NOTELPRUMAH'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td align="right" nowrap="nowrap">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">NOHP:</div></td>
      <td><input type="text" name="NOHP" value="<?php echo htmlentities($row_Recordset1['NOHP'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td align="right" nowrap="nowrap"><div align="left">PRESTASI:</div></td>
      <td><input type="text" name="PRESTASI" value="<?php echo htmlentities($row_Recordset1['PRESTASI'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left"></div></td>
      <td><input type="hidden" name="FOTO" value="<?php echo htmlentities($row_Recordset1['FOTO'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td align="right" nowrap="nowrap"><div align="left">CATATANLAIN:</div></td>
      <td><input type="text" name="CATATANLAIN" value="<?php echo htmlentities($row_Recordset1['CATATANLAIN'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">NAMAAYAH:</div></td>
      <td><input type="text" name="NAMAAYAH" value="<?php echo htmlentities($row_Recordset1['NAMAAYAH'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td align="right" nowrap="nowrap">&nbsp;</td>
      <td><input type="hidden" name="APPROVE" value="1" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">PEKERJAANAYAH:</div></td>
      <td><input type="text" name="PEKERJAANAYAH" value="<?php echo htmlentities($row_Recordset1['PEKERJAANAYAH'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">NOHPAYAH:</div></td>
      <td><input type="text" name="NOHPAYAH" value="<?php echo htmlentities($row_Recordset1['NOHPAYAH'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td><input type="submit" value="Accept" /></td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">NAMAIBU:</div></td>
      <td><input type="text" name="NAMAIBU" value="<?php echo htmlentities($row_Recordset1['NAMAIBU'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">PEKERJAANIBU:</div></td>
      <td><input type="text" name="PEKERJAANIBU" value="<?php echo htmlentities($row_Recordset1['PEKERJAANIBU'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">ALAMATAYAH:</div></td>
      <td><input type="text" name="ALAMATAYAH" value="<?php echo htmlentities($row_Recordset1['ALAMATAYAH'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">KOTAALAMATAYAH:</div></td>
      <td><input type="text" name="KOTAALAMATAYAH" value="<?php echo htmlentities($row_Recordset1['KOTAALAMATAYAH'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">NAMAWALI:</div></td>
      <td><input type="text" name="NAMAWALI" value="<?php echo htmlentities($row_Recordset1['NAMAWALI'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">ALAMATWALI:</div></td>
      <td><input type="text" name="ALAMATWALI" value="<?php echo htmlentities($row_Recordset1['ALAMATWALI'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">PEKERJAANWALI:</div></td>
      <td><input type="text" name="PEKERJAANWALI" value="<?php echo htmlentities($row_Recordset1['PEKERJAANWALI'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">NOHPWALI:</div></td>
      <td><input type="text" name="NOHPWALI" value="<?php echo htmlentities($row_Recordset1['NOHPWALI'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
  
  <input type="hidden" name="IDPENDAFTARAN" value="<?php echo $row_Recordset1['IDPENDAFTARAN']; ?>" />
  <input type="hidden" name="MM_insert" value="form1" />
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($Recordset1);

mysql_free_result($jurusan);
?>
