<?php require_once('Connections/koneksi.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?><?php require_once('Connections/koneksi.php'); 
include ('menu.php');
?>

<?php
mysql_select_db($database_koneksi, $koneksi);
$query_jurusan = "SELECT * FROM jurusan ORDER by IDJUR";
$jurusan = mysql_query($query_jurusan, $koneksi) or die(mysql_error());
$row_jurusan = mysql_fetch_assoc($jurusan);
$totalRows_jurusan = mysql_num_rows($jurusan);

$piljur = $_GET['piljur'];
if (empty($piljur)){
	$piljur = 1;
	
	} else {
	$piljur = $_GET['piljur'];
	}


mysql_select_db($database_koneksi, $koneksi);
$query_ujian = "SELECT ujian.IDUJIAN, ujian.NAMAUJIAN, ujian.BOBOT, ujian.SKORMAKSIMAL, jurusan.NAMAJURUSAN FROM ujian, jurusan WHERE ujian.IDJUR = $piljur and jurusan.IDJUR = ujian.IDJUR order by ujian.IDUJIAN";
$ujian = mysql_query($query_ujian, $koneksi) or die(mysql_error());
$row_ujian = mysql_fetch_assoc($ujian);
$totalRows_ujian = mysql_num_rows($ujian);

mysql_select_db($database_koneksi, $koneksi);
$query_UNAS = "SELECT setting.NAMASET, setting.SET1, setting.SET2 FROM setting WHERE setting.IDSET = 3 ";
$UNAS = mysql_query($query_UNAS, $koneksi) or die(mysql_error());
$row_UNAS = mysql_fetch_assoc($UNAS);
$totalRows_UNAS = mysql_num_rows($UNAS);


?>

<html>
<head>
<title>Untitled Document</title>
<script type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){
eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
if (restore) selObj.selectedIndex=0;
}
//-->
</script>
<style type="text/css">
<!--
.style2 {font-family: Georgia, "Times New Roman", Times, serif}
a:link {
	color: #000000;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #000000;
}
a:hover {
	text-decoration: underline;
	color: #333333;
}
a:active {
	text-decoration: none;
	color: #000000;
}
-->
</style>


<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>

<body>
<p><a href="bobot.php">Program Keahlian </a>: 
  <select name="menu1" onChange="MM_jumpMenu('parent',this,0)">
   <option value="---" </option>
    <?php
do {  
?>
	
    <option value="?piljur=<?php echo $row_jurusan['IDJUR']?>"><?php echo $row_jurusan['NAMAJURUSAN']?></option>
    <?php
} while ($row_jurusan = mysql_fetch_assoc($jurusan));
  $rows = mysql_num_rows($jurusan);
  if($rows > 0) {
      mysql_data_seek($jurusan, 0);
	  $row_jurusan = mysql_fetch_assoc($jurusan);
  }
?>
  </select>
</p>
<p class="style2">BOBOT UJIAN PROGRAM KEAHLIAN <?php echo $row_ujian['NAMAJURUSAN']; ?></p>
<table width="747" class="myTable" border="1" bordercolor="#999999">
  <tr class="myTableth">
    <td width="120" class="style2"><div align="center">ID</div></td>
    <td width="180" class="style2"><div align="center">NAMA UJIAN</div></td>
    <td width="113" class="style2"><div align="center">BOBOT</div></td>
    <td width="150" class="style2"><div align="center">Skor Maksimal</div></td>
    <td width="150" class="style2"><div align="center">EDIT</div></td>
  </tr>
 
  <?php 
   $jum = 0;
   $i = 1;
  do {  ?>
    <tr>
    
      <td width="120" class="style2"><div align="center"><?php echo $row_ujian['IDUJIAN']; ?></div></td>
      <td class="style2"><div align="left"><?php echo $row_ujian['NAMAUJIAN']; ?></div></td>
      <td class="style2"><div align="center"><?php echo $row_ujian['BOBOT']; $jum = $jum + $row_ujian['BOBOT'];?></div></td>
      <td class="style2"><div align="center"><?php echo $row_ujian['SKORMAKSIMAL']; ?></div></td>
      <td class="style2"><div align="center"><a href="bobotedit.php?IDUJIAN=<?php echo $row_ujian['IDUJIAN']; ?>"> <input type="button"  value="   Edit  " />
      </a>&nbsp;&nbsp;&nbsp;</a>
      <input type="button" onClick="show_confirm<?php echo $row_ujian['IDUJIAN']; ?>()" value="Delete" /></div></td>
      
      
<script type="text/javascript">
function show_confirm<?php echo $row_ujian['IDUJIAN']; ?>()
{
var r=confirm("Anda Akan Menghapus <?php echo $row_ujian['NAMAUJIAN']; ?>");
if (r==true)
  {
  window.location="delbobot.php?IDUJIAN=<?php echo $row_ujian['IDUJIAN']; ?>";
  }
}
</script>
    </tr>
    <?php } while ($row_ujian = mysql_fetch_assoc($ujian)); ?>
        <tr>
      <td class="style2"><div align="center">UN</div></td>
      <td class="style2">Ujian Nasional</td>
      <td class="style2"><div align="center"><?php echo $row_UNAS['SET1']; ?></div></td>
      <td class="style2"><div align="center"><?php echo $row_UNAS['SET2']; ?></div></td>
      <td class="style2">&nbsp;</td>
  </tr>
    
    <tr>
      <td colspan="2" class="style2"><div align="center">Jumlah Bobot</div></td>
      <td class="style2"><div align="center"><?php echo $jum + $row_UNAS['SET1']; ?>
      </div></td>
      <td class="style2">&nbsp;</td>
      <td class="style2">&nbsp;</td>
    </tr>

</table>
<p class="style2"><a href="addbobot.php">TAMBAH UJIAN</a></p>
</body>
</html>
<?php

mysql_free_result($jurusan);

mysql_free_result($ujian);

mysql_free_result($UNAS);
?>