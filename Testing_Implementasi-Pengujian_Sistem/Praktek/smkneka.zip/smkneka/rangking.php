<?php require_once('Connections/koneksi.php');


$querydel = "truncate table rangking";
mysql_query($querydel);

mysql_select_db($database_koneksi, $koneksi);
$query_jum = "SELECT count(calonsiswa.IDPENDAFTARAN) jumlahsiswa FROM calonsiswa";
$jum = mysql_query($query_jum, $koneksi) or die(mysql_error());
$row_jum = mysql_fetch_assoc($jum);
$totalRows_jum = mysql_num_rows($jum);


mysql_select_db($database_koneksi, $koneksi);
$query_Recordset1 = "SELECT sum(jurusan.JUMLAHMAKS) as totalpagu FROM jurusan";
$Recordset1 = mysql_query($query_Recordset1, $koneksi) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);

mysql_select_db($database_koneksi, $koneksi);
$query_jurusan = "SELECT * FROM jurusan order by IDJUR";
$jurusan = mysql_query($query_jurusan, $koneksi) or die(mysql_error());
$row_jurusan = mysql_fetch_assoc($jurusan);
$totalRows_jurusan = mysql_num_rows($jurusan);


 
for ($i=1;$i<=$totalRows_jurusan;$i++) {

$IDJUR = $row_jurusan['IDJUR']; 
mysql_select_db($database_koneksi, $koneksi);
$query_peringkat = "SELECT nilaiakhir.IDPENDAFTARAN, calonsiswa.NAMASISWA, calonsiswa.ASALSMP, jurusan.NAMAJURUSAN,
					calonsiswa.NUN, calonsiswa.IDPILJUR1, calonsiswa.IDPILJUR2, nilaiakhir.US, nilaiakhir.NA, jurusan.JUMLAHMAKS
					FROM nilaiakhir
					INNER JOIN calonsiswa ON calonsiswa.IDPENDAFTARAN = nilaiakhir.IDPENDAFTARAN
					INNER JOIN jurusan ON calonsiswa.IDPILJUR1 = jurusan.IDJUR
					WHERE (calonsiswa.IDPILJUR1 = '$IDJUR' or IDPILJUR2 = '$IDJUR') 
					ORDER BY IDPILJUR2 ='$IDJUR', nilaiakhir.NA DESC";
					
$peringkat = mysql_query($query_peringkat, $koneksi) or die(mysql_error());
$row_peringkat = mysql_fetch_assoc($peringkat);
$totalRows_peringkat = mysql_num_rows($peringkat);



	for ($j=1;$j<=$totalRows_peringkat;$j++) {	
	
		if ($row_peringkat['IDPILJUR1'] == $IDJUR and $j<=$row_peringkat['JUMLAHMAKS']){
				$masukjur = 1;	
			} elseif ($row_peringkat['IDPILJUR2'] == $IDJUR and $j<=$row_peringkat['JUMLAHMAKS']){
				$masukjur = 2;							
			} elseif ($row_Recordset1['totalpagu'] < $row_jum['jumlahsiswa']) {
				$masukjur = 3;					
			} else {
			$masukjur = 4;
			}
			
			
				
		$idpend = $row_peringkat['IDPENDAFTARAN'];
		$namajur = $row_peringkat['NAMAJURUSAN'];
		$narank = round($row_peringkat['NA'],2,2);
		$kuota = $row_peringkat['JUMLAHMAKS'];
		$pil1 = $row_peringkat['IDPILJUR1'];
		$pil2 = $row_peringkat['IDPILJUR2'];
		$kueri ="INSERT INTO rangking  VALUES 		
	  			('$j','$idpend','$IDJUR','$namajur','$narank','$kuota','$pil1','$pil2','$masukjur')"; 
 		
  		mysql_select_db($database_koneksi, $koneksi);
 			$Result1 = mysql_query($kueri, $koneksi) or die(mysql_error());		
			$row_peringkat = mysql_fetch_assoc($peringkat);
		}

$row_jurusan = mysql_fetch_assoc($jurusan);
}
$querydel2 = "DELETE n1 FROM rangking n1, rangking n2
				WHERE  n1.masukjur = 2  AND  n2.masukjur = 1
				and n1.IDPENDAFTARAN = n2.IDPENDAFTARAN";
mysql_query($querydel2);

$querydel3 = "DELETE n1 FROM rangking n1, rangking n2
				WHERE n1.masukjur = 3 AND  n2.masukjur = 1
				and n1.IDPENDAFTARAN = n2.IDPENDAFTARAN";
mysql_query($querydel3);




?>


