<?php require_once('Connections/koneksi.php'); ?><?php require_once('Connections/koneksi.php'); 
include ('menu.php');
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE ujian SET NAMAUJIAN=%s, BOBOT=%s, SKORMAKSIMAL=%s, IDJUR=%s WHERE IDUJIAN=%s",
                       GetSQLValueString($_POST['NAMAUJIAN'], "text"),
                       GetSQLValueString($_POST['BOBOT'], "int"),
                       GetSQLValueString($_POST['SKORMAKSIMAL'], "int"),
                       GetSQLValueString($_POST['IDJUR'], "int"),
                       GetSQLValueString($_POST['IDUJIAN'], "int"));

  mysql_select_db($database_koneksi, $koneksi);
  $Result1 = mysql_query($updateSQL, $koneksi) or die(mysql_error());

  $updateGoTo = "bobot.php?piljur=".$_POST['IDJUR'];
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_Recordset1 = "-1";
if (isset($_GET['IDUJIAN'])) {
  $colname_Recordset1 = $_GET['IDUJIAN'];
}
mysql_select_db($database_koneksi, $koneksi);
$query_Recordset1 = sprintf("SELECT ujian.*, jurusan.namajurusan FROM ujian, jurusan WHERE IDUJIAN = %s and ujian.idjur = jurusan.idjur", GetSQLValueString($colname_Recordset1, "int"));
$Recordset1 = mysql_query($query_Recordset1, $koneksi) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $title ?></title>
</head>

<body>
EDIT UJIAN
<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="left">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">ID Ujian:</div></td>
      <td><?php echo $row_Recordset1['IDUJIAN']; ?></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Nama Ujian:</div></td>
      <td><input type="text" name="NAMAUJIAN" value="<?php echo htmlentities($row_Recordset1['NAMAUJIAN'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Bobot:</div></td>
      <td><input type="text" name="BOBOT" value="<?php echo htmlentities($row_Recordset1['BOBOT'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Skor Maksimal:</div></td>
      <td><input type="text" name="SKORMAKSIMAL" value="<?php echo htmlentities($row_Recordset1['SKORMAKSIMAL'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Program Keahlian:</div></td>
      <td><input type="hidden"  name="IDJUR" value="<?php echo $row_Recordset1['IDJUR']; ?>" /><?php echo $row_Recordset1['namajurusan']; ?> </td>
    </tr>
    <tr> </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Update record" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_update" value="form1" />
  <input type="hidden" name="IDUJIAN" value="<?php echo $row_Recordset1['IDUJIAN']; ?>" />
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
