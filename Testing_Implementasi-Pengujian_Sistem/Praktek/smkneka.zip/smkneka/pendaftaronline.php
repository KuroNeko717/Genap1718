<?php require_once('Connections/koneksi.php'); 


?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "index1.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$maxRows_Recordset1 = 10;
$pageNum_Recordset1 = 0;
if (isset($_GET['pageNum_Recordset1'])) {
  $pageNum_Recordset1 = $_GET['pageNum_Recordset1'];
}
$startRow_Recordset1 = $pageNum_Recordset1 * $maxRows_Recordset1;

mysql_select_db($database_koneksi, $koneksi);
$query_Recordset1 = "SELECT IDPENDAFTARAN, IDPILJUR1, NOPENDAFTARAN, NAMASISWA, TEMPATLAHIR, TGLLAHIR, NUN, NOSKHUN, ASALSMP FROM calon ORDER BY IDPENDAFTARAN ASC";
$query_limit_Recordset1 = sprintf("%s LIMIT %d, %d", $query_Recordset1, $startRow_Recordset1, $maxRows_Recordset1);
$Recordset1 = mysql_query($query_limit_Recordset1, $koneksi) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);

if (isset($_GET['totalRows_Recordset1'])) {
  $totalRows_Recordset1 = $_GET['totalRows_Recordset1'];
} else {
  $all_Recordset1 = mysql_query($query_Recordset1);
  $totalRows_Recordset1 = mysql_num_rows($all_Recordset1);
}
$totalPages_Recordset1 = ceil($totalRows_Recordset1/$maxRows_Recordset1)-1;
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--


.myTable { background-color:#FFFFE0;border-collapse:collapse; }
.myTableth { background-color:#BDB76B;color:white; }
.myTable td, .myTable th { padding:5px;border:1px solid #BDB76B; }
a:link {
	color: #CC3300;
	text-decoration: none;
}

a:hover {
	text-decoration: underline;

}
a:active {
	text-decoration: none;
	color: #CC3300;
}

a:link {
	color: #FF0000;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
-->
</style></head>

<body>
<p><img src="images/header.jpg" /></p>
<table width="1024" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="514"><strong>VERIFIKASI PENDAFTAR ONLINE</strong></td>
    <td width="187"><a href="siswa.php">KEMBALI KE MENU</a></td>
    <td width="200"><a href="input.php">INPUT PENDAFTARAN</a></td>
    <td width="123"><a href="<?php echo $logoutAction ?>">LOGOUT</a></td>
  </tr>
</table>
<p>&nbsp;</p>
<table border="1" cellpadding="0" cellspacing="0" class="myTable">
  <tr class="myTableth">
    <td><div align="center"><strong>No Pendaftaran</strong></div></td>
    <td><div align="center"><strong>Nama</strong></div></td>
    <td><div align="center"><strong>Tempat Lahir</strong></div></td>
    <td><div align="center"><strong>Tanggal Lahir</strong></div></td>
    <td><div align="center"><strong>Asal Sekolah</strong></div></td>
    <td><div align="center"><strong>Edit</strong></div></td>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_Recordset1['NOPENDAFTARAN']; ?></td>
      <td><?php echo $row_Recordset1['NAMASISWA']; ?></td>
      <td><?php echo $row_Recordset1['TEMPATLAHIR']; ?></td>
      <td><?php echo $row_Recordset1['TGLLAHIR']; ?></td>
      <td><?php echo $row_Recordset1['ASALSMP']; ?></td>
      <td><a href="verifikasi.php?IDPENDAFTARAN=<?php echo $row_Recordset1['IDPENDAFTARAN']; ?>">Approve</a> 
      
      <input type="button" onClick="show_confirm_del<?php echo $row_Recordset1['IDPENDAFTARAN']; ?>()" value="Delete" />
      
<script type="text/javascript">
function show_confirm_del<?php echo $row_Recordset1['IDPENDAFTARAN']; ?>()
{
var r=confirm("Anda Akan Menghapus <?php echo $row_Recordset1['NAMASISWA']; ?>");
if (r==true)
  {
  window.location="pendaftardel.php?IDPENDAFTARAN=<?php echo $row_Recordset1['IDPENDAFTARAN']; ?>";
  }
}
</script></td>
    </tr>
    <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
