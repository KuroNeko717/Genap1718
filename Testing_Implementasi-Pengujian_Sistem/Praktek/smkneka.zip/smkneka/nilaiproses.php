<?php 
require_once('Connections/koneksi.php');

$jumlah = $_POST['jumlah'];
$kodeujian = $_POST['kodeujian'];
$kodejur = $_POST['kodejur'];

for ($i=1;$i<=$jumlah;$i++){
$IDNILAI = $_POST['IDNILAI'.$i];
$IDPENDAFTARAN = $_POST['IDPENDAFTARAN'.$i];
$IDUJIAN = $_POST['IDUJIAN'.$i];
$NILAIUJIAN = $_POST['NILAIUJIAN'.$i];
if ($NILAIUJIAN==""){
	$NILAIUJIAN=0;
	}

$IDJUR = $_POST['IDJUR'.$i];

echo $i, "  IDNILAI = ",$IDNILAI,"----------","IDPENDAFTARAN = ",$IDPENDAFTARAN, "  ", $NILAIUJIAN," ",$IDJUR,"<br>";

$kueri ="INSERT INTO nilai (IDNILAI,IDPENDAFTARAN,IDUJIAN,NILAIUJIAN,IDJUR) VALUES ('$IDNILAI','$IDPENDAFTARAN','$IDUJIAN','$NILAIUJIAN','$IDJUR')
			ON DUPLICATE KEY UPDATE NILAIUJIAN = '$NILAIUJIAN'"; 
 			//UPDATE nilai SET NILAIUJIAN = '$NILAIUJIAN' WHERE IDNILAI='$IDNILAI'";
  mysql_select_db($database_koneksi, $koneksi);
  $Result1 = mysql_query($kueri, $koneksi) or die(mysql_error());
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<meta http-equiv="REFRESH" content="0;url=nilaijur.php?IDUJIAN=<?php echo $kodeujian; ?>&amp;IDJUR=<?php echo $kodejur; ?>">
</head>

<body>




</body>


</html>
 
