<?php require_once('Connections/koneksi.php'); 
if (!isset($_SESSION)) {
  session_start();
}

$group = $_SESSION['MM_UserGroup'];

if($group == "ADMIN"){
include('menu.php');
} elseif ($group == "PANITIA"){
include('menu2.php');
} else {
header( 'Location: input.php' ) ;
}
?>

<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$cari1 = $_POST['carimhs'];
$cari = "%".$cari1."%";



mysql_select_db($database_koneksi, $koneksi);
$query_calonsiswa = "SELECT calonsiswa.* , jurusan.namajurusan, nilaiakhir.NUN as NUNIK, nilaiakhir.US, nilaiakhir.NA 
					FROM calonsiswa, jurusan, nilaiakhir 
					WHERE jurusan.idjur = calonsiswa.idpiljur1 AND nilaiakhir.IDPENDAFTARAN = calonsiswa.IDPENDAFTARAN
					AND (calonsiswa.NOPENDAFTARAN like '$cari' or calonsiswa.NAMASISWA like '$cari')	
					ORDER BY NOPENDAFTARAN";
$calonsiswa = mysql_query($query_calonsiswa, $koneksi) or die(mysql_error());
$row_calonsiswa = mysql_fetch_assoc($calonsiswa);
$totalRows_calonsiswa = mysql_num_rows($calonsiswa);



$jur2 = $row_calonsiswa['IDPILJUR2'];

mysql_select_db($database_koneksi, $koneksi);
$query_jurusan2 = "SELECT * FROM jurusan ORDER BY IDJUR";
$jurusan2 = mysql_query($query_jurusan2, $koneksi) or die(mysql_error());
$row_jurusan2 = mysql_fetch_assoc($jurusan2);
$totalRows_jurusan2 = mysql_num_rows($jurusan2);


?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style15 {font-size: x-small}
.style22 {font-size: small; font-weight: bold; font-family: Arial, Helvetica, sans-serif; }
.style23 {font-family: Arial, Helvetica, sans-serif}
.style24 {font-size: x-small; font-family: Arial, Helvetica, sans-serif; }
.style26 {
	font-size: 12px;
	font-family: Arial, Helvetica, sans-serif;
}
a:link {
	color: #000000;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #000000;
}
a:hover {
	text-decoration: underline;
	color: #999999;
}
a:active {
	text-decoration: none;
	color: #000000;
}
.style57 {	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
-->
</style>
</head>

<body>

  <?php 
  $i = 0;
  do { 
	  	$i++;
	 	$idjuru = "idjuru".$i;
		$$idjuru = $row_jurusan2['IDJUR'];
	 	$namajuru = "namajuru".$i;
		$$namajuru = $row_jurusan2['NAMAJURUSAN'];
		} while ($row_jurusan2 = mysql_fetch_assoc($jurusan2)); ?>
  <table width="536" border="0" align="left" cellpadding="0" cellspacing="0">
  <tr>
    <td width="369"><form id="form1" name="form1" method="post" action="siswa.php">
      <div align="right"><span class="style57">Cari Siswa : </span>
            <input name="carimhs" type="text" id="carimhs" size="30" />
        &nbsp;
        <input type="submit" name="submit" id="submit" value="Cari" />
      </div>
    </form></td>
    <td width="97"><form id="form2" name="form2"action="siswa.php" method="post">
      <div align="center">
        <input name="carimhs" type="hidden" id="carimhs" value="1" />
        <input type="submit" name="submit2" id="submit2" value="Semua" />
      </div>
    </form></td>
  </tr>
</table>
  <p>&nbsp;</p>
<table width="996"  class="myTable" height="73" border="1" bordercolor="#999999">
  <tr class="myTableth">
    <td width="27" rowspan="2"><div align="center" class="style22">No Urut</div>      </td>
    <td width="60" rowspan="2"><div align="center" class="style22">No Pendaftaran</div>      </td>
    <td width="143" rowspan="2"><div align="center" class="style22">Nama</div>      </td>
    <td width="160" rowspan="2"><div align="center" class="style22">Asal Sekolah</div>      </td>
    <td width="135" rowspan="2"><div align="center" class="style22">Pilihan 1</div>      </td>
    <td width="135" rowspan="2"><div align="center" class="style22">Pilihan 2</div>      </td>
    <td height="19" colspan="4"><div align="center" class="style22">Nilai</div></td>
  </tr>
  <tr>
    <td width="40" height="21"><div align="center" class="style22">NUN</div>
    <td width="40" height="21"><div align="center" class="style22">&sum; NUN</div></td>
    <td width="40"><div align="center" class="style22">TES </div></td>
    <td width="40"><div align="center" class="style22">TOTAL</div></td>
  </tr>
  <?php 
  $nomor = 1;
  do { ?>
    <tr>
      <td height="23"><div align="center"><span class="style26"><?php echo $nomor; $nomor++; ?></span></div></td>
      <td><div align="center"><span class="style26"><?php echo $row_calonsiswa['NOPENDAFTARAN']; ?></span></div></td>
      <td><span class="style26"><a href="siswaedit.php?IDPENDAFTARAN=<?php echo $row_calonsiswa['IDPENDAFTARAN']; ?>"><?php echo $row_calonsiswa['NAMASISWA']; ?></a></span></td>
      <td><div align="left"><span class="style26"><?php echo $row_calonsiswa['ASALSMP']; ?></span></div></td>
      <td><span class="style26"><?php echo $row_calonsiswa['namajurusan'] ?></span></td>
      <td><span class="style26"> 
	  <?php 
	  	$aa ="nama";
		$bb = "juru";
	 	$aku = $aa.$bb.$row_calonsiswa['IDPILJUR2'];
		$aku = $$aku;
		echo $aku;
	  ?>
      
      </span></td>
      <td><div align="center"><span class="style26"><?php echo $row_calonsiswa['NUN']; ?></span></div></td>
      <td><div align="center"><span class="style26"><?php echo round($row_calonsiswa['NUNIK'],2,2); ?></span></div></td>
      <td><div align="center"><span class="style26"><?php echo round($row_calonsiswa['US'],2,2); ?></span></div></td>
      <td><div align="center"><span class="style26"><?php echo round($row_calonsiswa['NA'],2,2); ?></span></div></td>
    </tr>
    <?php } while ($row_calonsiswa = mysql_fetch_assoc($calonsiswa)); ?>
</table>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($calonsiswa);

mysql_free_result($jurusan2);
?>
