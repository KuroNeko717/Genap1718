<?php require_once('Connections/koneksi.php'); 

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}



mysql_select_db($database_koneksi, $koneksi);
$query_jum = "SELECT count(calonsiswa.IDPENDAFTARAN) jumlahsiswa FROM calonsiswa";
$jum = mysql_query($query_jum, $koneksi) or die(mysql_error());
$row_jum = mysql_fetch_assoc($jum);
$totalRows_jum = mysql_num_rows($jum);


mysql_select_db($database_koneksi, $koneksi);
$query_Kuota = "SELECT sum(jurusan.JUMLAHMAKS) as totalpagu FROM jurusan";
$Kuota = mysql_query($query_Kuota, $koneksi) or die(mysql_error());
$row_Kuota = mysql_fetch_assoc($Kuota);
$totalRows_Kuota = mysql_num_rows($Kuota);

mysql_select_db($database_koneksi, $koneksi);
$query_jurusan = "SELECT * FROM jurusan ORDER BY IDJUR ASC";
$jurusan = mysql_query($query_jurusan, $koneksi) or die(mysql_error());
$row_jurusan = mysql_fetch_assoc($jurusan);
$totalRows_jurusan = mysql_num_rows($jurusan);

?>
<?php
$IDJUR = $_GET['IDJUR'];

$kuerikuota = "select jurusan.JUMLAHMAKS from jurusan where IDJUR = '$IDJUR'";
$kuota = mysql_query($kuerikuota);
$row_kuota = mysql_fetch_assoc($kuota);


mysql_select_db($database_koneksi, $koneksi);
$query_Recordset1 = "SELECT rangking.PERINGKAT, rangking.IDPENDAFTARAN, calonsiswa.NOPENDAFTARAN, calonsiswa.NAMASISWA, calonsiswa.ASALSMP, calonsiswa.NUN as UN, rangking.IDJUR, jurusan.NAMAJURUSAN, nilaiakhir.NUN, nilaiakhir.US, nilaiakhir.NA, rangking.PIL1, rangking.PIL2, if(rangking.PIL1=rangking.IDJUR,'Pilihan 1','Pilihan 2') as Pilihan FROM rangking INNER JOIN calonsiswa ON rangking.IDPENDAFTARAN = calonsiswa.IDPENDAFTARAN INNER JOIN nilaiakhir ON rangking.IDPENDAFTARAN = nilaiakhir.IDPENDAFTARAN INNER JOIN jurusan ON rangking.IDJUR = jurusan.IDJUR WHERE rangking.IDJUR = '$IDJUR' ";
$Recordset1 = mysql_query($query_Recordset1, $koneksi) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<style type="text/css">
.myTable { background-color:#FFFFE0;border-collapse:collapse; }
.myTableth { background-color:#BDB76B;color:white; }
.myTable td, .myTable th { padding:5px;border:1px solid #BDB76B; }
a:link {
	color: #CC3300;
	text-decoration: none;
}

a:hover {
	text-decoration: underline;

}
a:active {
	text-decoration: none;
	color: #CC3300;
}
.style2 {font-size: 10px}
.style4 {font-family: Verdana, Arial, Helvetica, sans-serif}
</style>
</head>

<body>

<img src="images/header.jpg" />
<table class="myTable" width="1024" border="1" style="font-family:Verdana, Arial, Helvetica, sans-serif">
  <tr>
  
    <?php do { ?>
    <td width="446" style="font-family:Verdana, Arial, Helvetica, sans-serif"><div align="center"><a href="pengumuman.php?IDJUR=<?php echo $row_jurusan['IDJUR']; ?>" ><?php echo $row_jurusan['NAMAJURUSAN']; ?></a></div></td>
    <?php } while ($row_jurusan = mysql_fetch_assoc($jurusan)); ?>
  </tr>
</table>


<table width="1024">
<tr><td>
<p align="center" class="style4">DAFTAR PERINGKAT PROGRAM KEAHLIAN <?php echo $row_Recordset1['NAMAJURUSAN']; ?><br />
  JUMLAH KUOTA : <?php echo  $row_kuota['JUMLAHMAKS'];?></p>
 </td> </tr>
  </table>
  
  
<table width="1024" class="myTable" border="1" cellspacing="0" cellpadding="0" style="font-family:Verdana, Arial, Helvetica, sans-serif" font-size = "8">
  <tr class="myTableth">
    <td width="30"><div align="center" class="style2">No</div></td>
    <td width="50"><div align="center" class="style2">No Pendaftaran</div></td>
    <td width="177"><div align="center" class="style2">Nama Calon Siswa</div></td>
    <td width="148"><div align="center" class="style2">Asal Sekolah</div></td>
    <td width="40"><div align="center" class="style2">NUN</div></td>
    <td width="40"><div align="center" class="style2">&sum; NUN</div></td>
    <td width="40"><div align="center" class="style2">Nilai Ujian</div></td>
    <td width="40"><div align="center" class="style2">Total Nilai</div></td>
    <td width="40"><div align="center" class="style2">Keterangan</div></td>
    <td width="120"><span class="style2"></span></td>
  </tr>
  <?php 
  $i = 1;
  do { ?>
    <tr>
      <td><div align="center" class="style2"><?php echo $i; $i++ ?></div></td>
      <td><div align="center" class="style2"><?php echo $row_Recordset1['NOPENDAFTARAN']; ?></div></td>
      <td class="style2"><?php echo $row_Recordset1['NAMASISWA']; ?></td>
      <td class="style2"><?php echo $row_Recordset1['ASALSMP']; ?></td>
      <td class="style2"><div align="right"><?php echo $row_Recordset1['UN']; ?></div></td>
      <td class="style2"><div align="right"><?php echo round($row_Recordset1['NUN'],2,2);?> </div></td>
      <td class="style2"><div align="right"><?php echo round($row_Recordset1['US'],2,2); ?></div></td>
      <td class="style2"><div align="right"><?php echo round($row_Recordset1['NA'],2,2); ?></div></td>
      <td class="style2">
        <div align="center"> <?php echo $row_Recordset1['Pilihan']; ?></div></td>
      <td width="120">
              <div align="center" class="style2">
          <?php 
	  if ($i<=$row_kuota['JUMLAHMAKS']+1){
	  	echo $Laporan1;
		} elseif ($row_Kuota['totalpagu']>$row_jum['jumlahsiswa']) {
		echo $Laporan2;
		} else {
		echo "<strong><font color='#FF0000'>",$Laporan3,"</font></strong>";
		}
	  
	  ?>
        </div>      </td>
    </tr>
    <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td width="120">&nbsp;</td>
  </tr>
</table>

<p>&sum; NUN = Jumlah Bobot NUN</p>
<p><a href="laporanprint.php?IDJUR=<?php echo $IDJUR; ?>">CETAK</a></p>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
