<?php require_once('Connections/koneksi.php'); ?><?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index1.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "ADMIN,PETUGAS,PANITIA";
$MM_donotCheckaccess = "false";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && false) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "index1.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}

mysql_select_db($database_koneksi, $koneksi);
$query_propinsi = "SELECT NamaPropinsi FROM propinsi ORDER BY NamaPropinsi ASC";
$propinsi = mysql_query($query_propinsi, $koneksi) or die(mysql_error());
$row_propinsi = mysql_fetch_assoc($propinsi);
$totalRows_propinsi = mysql_num_rows($propinsi);

mysql_select_db($database_koneksi, $koneksi);
$query_jurusan = "SELECT IDJUR, NAMAJURUSAN FROM jurusan";
$jurusan = mysql_query($query_jurusan, $koneksi) or die(mysql_error());
$row_jurusan = mysql_fetch_assoc($jurusan);
$totalRows_jurusan = mysql_num_rows($jurusan);

mysql_select_db($database_koneksi, $koneksi);
$query_Recordset1 = "SELECT count( IDPENDAFTARAN) as jumlahpendaftar FROM calonsiswa";
$Recordset1 = mysql_query($query_Recordset1, $koneksi) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);


$jum1 = $row_Recordset1['jumlahpendaftar'];
$aaa = $jum1 / $jumlahsesiujian;



?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $title ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css">
<!--
.style18 {
	font-family: Georgia, "Times New Roman", Times, serif;
	font-size: 14px;
	color: #333333;
}
.style19 {font-size: 12px}
.style20 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 18px;
	color: #666666;
	font-weight: bold;
}
.style22 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-weight: bold;
	color: #FF3300;
}
-->
</style>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style23 {font-size: 24px}
-->
</style>
</head>
<body bgcolor="#FFFFFF"><form action="konfirmasi.php" method="POST" enctype="multipart/form-data" name ="form1">
<!-- ImageReady Slices (Untitled-1 - Slices: footer, header, info, left, menu, right, top) -->
<table width="1024" border="0" align="center" cellpadding="0" cellspacing="0" id="Table_01">
<tr>
		<td colspan="5"><img src="images/header.jpg" alt="" width="1024" height="105" id="header" /></td>
  </tr>
	<tr>
		<td colspan="5" background="images/menu.jpg">&nbsp;</td>
  </tr>
	<tr>
		<td width="1024" height="8" colspan="5">
			<img src="images/spacer.gif" alt="" width="1024" height="8" /></td>
	</tr>
	<tr>
		<td width="48" height="19">&nbsp;</td>
		<td colspan="3"><p align="center" class="style20">FORMULIR PPDB</p>	    </td>
  <td width="54" height="56"><span class="style19"></span></td>
	</tr>
	<tr>
	  <td width="48" height="11">&nbsp;</td>
		<td width="922" height="11" colspan="3"><div align="right"><span class="style19">
		
	   <a href="pendaftaronline.php">VERIFIKASI PENDAFTAR ONLINE</a> 
	   <?php       
			$group = $_SESSION['MM_UserGroup'];
			
			if($group == "ADMIN" or $group == "PANITIA" ){
			echo "<a href='siswa.php'>KEMBALI</a>";
			}
			echo "  &nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp;  ";
			
			?>
       <a href="<?php echo $logoutAction ?>">LOGOUT</a> </span></div>      </td>
        <td width="54" height="11"><span class="style19"></span></td>
  </tr>
	<tr>
	  <td width="48" height="19">&nbsp;</td>
		<td><span class="style22">Identitas Siswa</span></td>
  <td width="42" height="413" rowspan="2"><span class="style19"></span></td>
		<td><span class="style22">Identitas Asal Sekolah</span></td>
        <td width="54" height="19"><span class="style19"></span></td>
  </tr>
	<tr>
	  <td width="48" height="13">&nbsp;</td>
		<td width="440" height="13" align="left" valign="top"><table width="420" border="0" align="left">
          <tr>
            <td width="140" class="style18">Nomer Pendaftaran</td>
            <td width="7" class="style18">:</td>
            <td width="251" class="style18"><span id="sprytextfield1">
              <input type="text" name="NoPendaftaran" id="NoPendaftaran" />
            <span class="textfieldRequiredMsg">Harap diisi</span></span></td>
          </tr>
          <tr>
            <td class="style18">Nama Calon Siswa</td>
            <td class="style18">:</td>
            <td class="style18">
            <span id="sprytextfield2">
            <input type="text" name="NamaSiswa" id="NamaSiswa" />
            <span class="textfieldRequiredMsg">Harap diisi</span></span></td>
          </tr>
          <tr>
            <td class="style18">Tempat Lahir</td>
            <td class="style18">:</td>
            <td class="style18"><input type="text" name="TempatLahir" id="TempatLahir" /></td>
          </tr>
          <tr>
            <td class="style18">Tanggal Lahir</td>
            <td class="style18">:</td>
            <td class="style18"><select name="Tgl" id="Tgl">
              <option value="01" selected="selected">01</option>
              <option value="02">02</option>
              <option value="03">03</option>
              <option value="04">04</option>
              <option value="05">05</option>
              <option value="06">06</option>
              <option value="07">07</option>
              <option value="08">08</option>
              <option value="09">09</option>
              <option value="10">10</option>
              <option value="11">11</option>
              <option value="12">12</option>
              <option value="13">13</option>
              <option value="14">14</option>
              <option value="15">15</option>
              <option value="16">16</option>
              <option value="17">17</option>
              <option value="18">18</option>
              <option value="19">19</option>
              <option value="20">20</option>
              <option value="21">21</option>
              <option value="22">22</option>
              <option value="23">23</option>
              <option value="24">24</option>
              <option value="25">25</option>
              <option value="26">26</option>
              <option value="27">27</option>
              <option value="28">28</option>
              <option value="29">29</option>
              <option value="30">30</option>
              <option value="31">31</option>
            </select>
              <select name="bulan" id="bulan">
                <option value="01" selected="selected">Januari</option>
                <option value="02">Pebruari</option>
                <option value="03">Maret</option>
                <option value="04">April</option>
                <option value="05">Mei</option>
                <option value="06">Juni</option>
                <option value="07">Juli</option>
                <option value="08">Agustus</option>
                <option value="09">September</option>
                <option value="10">Oktober</option>
                <option value="11">Nopember</option>
                <option value="12">Desember</option>
              </select>
              <select name="tahun" id="tahun">
                <option value="1998">1998</option>
                <option value="1997">1997</option>
                <option value="1996" selected="selected">1996</option>
                <option value="1995">1995</option>
                <option value="1994">1994</option>
                <option value="1993">1993</option>
                <option value="1992">1992</option>
              </select>            </td>
          </tr>
          <tr>
            <td class="style18">Jenis Kelamin</td>
            <td class="style18">:</td>
            <td class="style18"><input name="radio" type="radio" id="jeniskelamin" value="L" checked="checked" />
              Laki-laki 
              <input type="radio" name="radio" id="jeniskelamin" value="P" />
              Perempuan</td>
          </tr>
          <tr>
            <td class="style18">Agama</td>
            <td class="style18">:</td>
            <td class="style18"><select name="Agama" id="Agama">
              <option value="Islam" selected="selected">Islam</option>
              <option value="Non Muslim">Non Muslim</option>
            </select>            </td>
          </tr>
          <tr>
            <td class="style18">Alamat</td>
            <td class="style18">:</td>
            <td class="style18"><input name="Alamat" type="text" id="Alamat" size="40" /></td>
          </tr>
          <tr>
            <td class="style18">Kota</td>
            <td class="style18">:</td>
            <td class="style18"><input name="KotaAlamatSiswa" type="text" id="KotaAlamatSiswa" value="Lamongan" /></td>
          </tr>
          <tr>
            <td class="style18">Propinsi</td>
            <td class="style18">:</td>
            <td class="style18"><select name="Propinsi" id="Propinsi">
              <?php
do {  
?>
              <option value="<?php echo $row_propinsi['NamaPropinsi']?>"<?php if (!(strcmp($row_propinsi['NamaPropinsi'], "Jawa Timur"))) {echo "selected=\"selected\"";} ?>><?php echo $row_propinsi['NamaPropinsi']?></option>
              <?php
} while ($row_propinsi = mysql_fetch_assoc($propinsi));
  $rows = mysql_num_rows($propinsi);
  if($rows > 0) {
      mysql_data_seek($propinsi, 0);
	  $row_propinsi = mysql_fetch_assoc($propinsi);
  }
?>
            </select></td>
          </tr>
          <tr>
            <td class="style18">No Telp</td>
            <td class="style18">:</td>
            <td class="style18"><input type="text" name="NOTELPRUMAH" id="NOTELPRUMAH" /></td>
          </tr>
          <tr>
            <td class="style18">No Hp</td>
            <td class="style18">:</td>
            <td class="style18"><input type="text" name="NOHP" id="NOHP" /></td>
          </tr>
        </table>
	  <p class="style18">&nbsp;</p>
	  <p class="style18">&nbsp;</p>
	  <p class="style18">&nbsp;</p>
	  <p class="style18">&nbsp;</p>
	  <p class="style18">&nbsp;</p>
	  <p class="style18">&nbsp;</p>
	  <p class="style18">&nbsp;</p>
	  <p class="style18">&nbsp;</p>
	  <table width="420" border="0" align="left">
        <tr>
          <td colspan="3" class="style22">Identitas Orang Tua / Wali</td>
        </tr>
        <tr>
          <td width="140" class="style18">Nama Ayah</td>
          <td width="7" class="style18">:</td>
          <td width="251" class="style18"><input type="text" name="NAMAAYAH" id="NAMAAYAH" /></td>
        </tr>
        <tr>
          <td class="style18">Pekerjaan Ayah</td>
          <td class="style18">&nbsp;</td>
          <td class="style18"><input type="text" name="PEKERJAANAYAH" id="PEKERJAANAYAH" /></td>
        </tr>
        <tr>
          <td class="style18">No Telp Ayah</td>
          <td class="style18">&nbsp;</td>
          <td class="style18"><input type="text" name="NOHPAYAH" id="NOHPAYAH" /></td>
        </tr>
        <tr>
          <td class="style18">Nama Ibu</td>
          <td class="style18">&nbsp;</td>
          <td class="style18"><input type="text" name="NAMAIBU" id="NAMAIBU" /></td>
        </tr>
        <tr>
          <td class="style18">Pekerjaan Ibu</td>
          <td class="style18">&nbsp;</td>
          <td class="style18"><input type="text" name="PEKERJAANIBU" id="PEKERJAANIBU" /></td>
        </tr>
        <tr>
          <td class="style18">Alamat</td>
          <td class="style18">&nbsp;</td>
          <td class="style18"><input name="ALAMATAYAH" type="text" id="ALAMATAYAH" size="30" /></td>
        </tr>
        <tr>
          <td class="style18">Kota </td>
          <td class="style18">&nbsp;</td>
          <td class="style18"><input type="text" name="KOTAALAMATAYAH" id="KOTAALAMATAYAH" /></td>
        </tr>
        <tr>
          <td class="style18">&nbsp;</td>
          <td class="style18">&nbsp;</td>
          <td class="style18">&nbsp;</td>
        </tr>
        <tr>
          <td class="style18">Nama Wali</td>
          <td class="style18">&nbsp;</td>
          <td class="style18"><input type="text" name="NAMAWALI" id="NAMAWALI" /></td>
        </tr>
        <tr>
          <td class="style18">Alamat Wali</td>
          <td class="style18">&nbsp;</td>
          <td class="style18"><input name="ALAMATWALI" type="text" id="ALAMATWALI" size="30" /></td>
        </tr>
        <tr>
          <td class="style18">Pekerjaan Wali</td>
          <td class="style18">&nbsp;</td>
          <td class="style18"><input type="text" name="PEKERJAANWALI" id="PEKERJAANWALI" /></td>
        </tr>
        <tr>
          <td class="style18">No Telp Wali</td>
          <td class="style18">&nbsp;</td>
          <td class="style18"><input type="text" name="NOHPWALI" id="NOHPWALI" /></td>
        </tr>
        <tr>
          <td class="style18">&nbsp;</td>
          <td class="style18">&nbsp;</td>
          <td class="style18">&nbsp;</td>
        </tr>
      </table>	  
	  <p class="style18">&nbsp;</p></td>
  <td width="440" height="13" align="left" valign="top"><table width="420" border="0" align="left">
    <tr>
      <td width="140" class="style18">Nomor Ijazah</td>
      <td width="7" class="style18">:</td>
      <td width="251" class="style18"><input type="text" name="NOIJASAH" id="NOIJASAH" /></td>
    </tr>
    <tr>
      <td class="style18">Tanggal Ijazah</td>
      <td class="style18">&nbsp;</td>
      <td class="style18"><select name="Tgl2" id="Tgl2">
        <option value="01" selected="selected">01</option>
        <option value="02">02</option>
        <option value="03">03</option>
        <option value="04">04</option>
        <option value="05">05</option>
        <option value="06">06</option>
        <option value="07">07</option>
        <option value="08">08</option>
        <option value="09">09</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
        <option value="13">13</option>
        <option value="14">14</option>
        <option value="15">15</option>
        <option value="16">16</option>
        <option value="17">17</option>
        <option value="18">18</option>
        <option value="19">19</option>
        <option value="20">20</option>
        <option value="21">21</option>
        <option value="22">22</option>
        <option value="23">23</option>
        <option value="24">24</option>
        <option value="25">25</option>
        <option value="26">26</option>
        <option value="27">27</option>
        <option value="28">28</option>
        <option value="29">29</option>
        <option value="30">30</option>
        <option value="31">31</option>
      </select>
        <select name="bulan2" id="bulan2">
          <option value="05" selected="selected">Mei</option>
          <option value="06">Juni</option>
          <option value="07">Juli</option>
          <option value="08">Agustus</option>
        </select>
        <select name="tahun2" id="tahun2">
          <option value="2012"  selected="selected">2012</option>
          <option value="2011">2011</option>
          <option value="2010">2010</option>
        </select></td>
    </tr>
    <tr>
      <td class="style18">Nilai Ujian Nasional</td>
      <td class="style18">:</td>
      <td class="style18"><select name="NUN1" id="NUN1">
        <option value="0">0</option>
        <option value="1">1</option>
        <option value="2" selected="selected">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
      </select>
        <select name="NUN2" id="NUN2">
          <option value="0" selected="selected">0</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
        </select>
        &nbsp; <strong>,&nbsp;</strong>&nbsp;
        <select name="NUN3" id="NUN3">
          <option value="0">0</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
        </select>
        <select name="NUN4" id="NUN4">
          <option value="0">0</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
        </select></td>
    </tr>
    <tr>
      <td class="style18">Nomor STL/SKHUN</td>
      <td class="style18">&nbsp;</td>
      <td class="style18"><input type="text" name="NOSKHUN" id="NOSKHUN" /></td>
    </tr>
    <tr>
      <td class="style18">Tanggal STL/SKHUN</td>
      <td class="style18">&nbsp;</td>
      <td class="style18"><select name="Tgl3" id="Tgl3">
        <option value="01" selected="selected">01</option>
        <option value="02">02</option>
        <option value="03">03</option>
        <option value="04">04</option>
        <option value="05">05</option>
        <option value="06">06</option>
        <option value="07">07</option>
        <option value="08">08</option>
        <option value="09">09</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
        <option value="13">13</option>
        <option value="14">14</option>
        <option value="15">15</option>
        <option value="16">16</option>
        <option value="17">17</option>
        <option value="18">18</option>
        <option value="19">19</option>
        <option value="20">20</option>
        <option value="21">21</option>
        <option value="22">22</option>
        <option value="23">23</option>
        <option value="24">24</option>
        <option value="25">25</option>
        <option value="26">26</option>
        <option value="27">27</option>
        <option value="28">28</option>
        <option value="29">29</option>
        <option value="30">30</option>
        <option value="31">31</option>
      </select>
        <select name="bulan3" id="bulan3">
          <option value="05" selected="selected">Mei</option>
          <option value="06">Juni</option>
          <option value="07">Juli</option>
          <option value="08">Agustus</option>
        </select>
        <select name="tahun3" id="tahun3">
          <option value="2012"  selected="selected">2012</option>
          <option value="2011">2011</option>
          <option value="2010">2010</option>
        </select></td>
    </tr>
    <tr>
      <td class="style18">Asal SMP / Mts</td>
      <td class="style18">:</td>
      <td class="style18"><input name="ASALSMP" type="text" id="ASALSMP" size="30" /></td>
    </tr>
    <tr>
      <td class="style18">Kota SMP / Mts</td>
      <td class="style18">:</td>
      <td class="style18"><input type="text" name="KOTAASALSMP" id="KOTAASALSMP" /></td>
    </tr>
    <tr>
      <td class="style18">Prestasi</td>
      <td class="style18">:</td>
      <td rowspan="2" align="left" valign="top" class="style18">&nbsp;</td>
    </tr>
    <tr>
      <td class="style18">&nbsp;</td>
      <td class="style18">&nbsp;</td>
      </tr>
  </table>
    <p class="style18">&nbsp;</p>
    <p class="style18">&nbsp;</p>
    <p class="style18">&nbsp;</p>
    <p class="style18">&nbsp;</p>
    <p class="style18">
      <textarea name="PRESTASI" id="PRESTASI" cols="45" rows="5"></textarea>
    </p>
    <table width="420" border="0" align="left">
      <tr>
        <td colspan="3" class="style22">Program Keahlian</td>
        </tr>
      <tr>
        <td width="140" class="style18">Pilihan 1</td>
        <td width="7" class="style18">:</td>
        <td width="251" class="style18"><select name="NAMAJURUSAN1" id="NAMAJURUSAN1">
          <?php
do {  
?>
          <option value="<?php echo $row_jurusan['IDJUR']?>"<?php if (!(strcmp($row_jurusan['IDJUR'], $row_jurusan['IDJUR']))) {echo "selected=\"selected\"";} ?>><?php echo $row_jurusan['NAMAJURUSAN']?></option>
<?php
} while ($row_jurusan = mysql_fetch_assoc($jurusan));
  $rows = mysql_num_rows($jurusan);
  if($rows > 0) {
      mysql_data_seek($jurusan, 0);
	  $row_jurusan = mysql_fetch_assoc($jurusan);
  }
?>
        </select></td>
      </tr>
      <tr>
        <td class="style18">Pilihan 2</td>
        <td class="style18">:</td>
        <td class="style18"><select name="NAMAJURUSAN2" id="NAMAJURUSAN2">
          <?php
do {  
?>
          <option value="<?php echo $row_jurusan['IDJUR']?>"<?php if (!(strcmp($row_jurusan['IDJUR'], $row_jurusan['IDJUR']))) {echo "selected=\"selected\"";} ?>><?php echo $row_jurusan['NAMAJURUSAN']?></option>
          <?php
} while ($row_jurusan = mysql_fetch_assoc($jurusan));
  $rows = mysql_num_rows($jurusan);
  if($rows > 0) {
      mysql_data_seek($jurusan, 0);
	  $row_jurusan = mysql_fetch_assoc($jurusan);
  }
?>
        </select></td>
      </tr>
      <tr>
        <td class="style18">&nbsp;</td>
        <td class="style18">:</td>
        <td class="style18">&nbsp;</td>
      </tr>
      <tr>
        <td class="style18">Catatan</td>
        <td class="style18">:</td>
        <td rowspan="2" align="left" valign="top" class="style18"><textarea name="CATATANLAIN" id="CATATANLAIN" cols="26" rows="5"></textarea></td>
      </tr>
      <tr>
        <td class="style18">&nbsp;</td>
        <td class="style18">&nbsp;</td>
        </tr>
      <tr>
        <td colspan="3" valign="middle" class="style18"><p>
            <input type="submit" name="Submit" id="Submit" value="Submit" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="reset" name="Reset" id="Reset" value="Reset" />
          </p>
          <p>&nbsp;</p>
          <p class="style23">SESI UJIAN = <?php echo substr($aaa,0,1) + 1; ?></p></td>
        </tr>
    </table>    
    <p class="style18">&nbsp;</p></td>
  <td width="54" height="13"><span class="style19"></span></td>
  </tr>
	<tr>
	  <td width="48" height="146">&nbsp;</td>
		<td colspan="3">&nbsp;</td>
        <td width="54" height="146">&nbsp;</td>
  </tr>
	<tr>
	  <td width="48" height="7">&nbsp;</td>
		<td width="922" height="7" colspan="3">
			<img src="images/spacer.gif" width="922" height="7" alt="" /></td>
	    <td width="54" height="7">&nbsp;</td>
	</tr>
	<tr>
	  <td width="48" height="300">&nbsp;</td>
		<td colspan="3">&nbsp;</td>
        <td width="54" height="300">&nbsp;</td>
  </tr>
	<tr>
	  <td width="48" height="25">&nbsp;</td>
		<td width="922" height="25" colspan="3">&nbsp;</td>
        <td width="54" height="25">&nbsp;</td>
  </tr>
</table>
<input type="hidden" name="MM_insert" value="form1" />
</form>
<!-- End ImageReady Slices -->
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
//-->
</script>
</body>
</html>
<?php
mysql_free_result($propinsi);

mysql_free_result($jurusan);

mysql_free_result($Recordset1);
?>