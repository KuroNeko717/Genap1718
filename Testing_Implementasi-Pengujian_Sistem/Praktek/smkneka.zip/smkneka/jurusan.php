<?php require_once('Connections/koneksi.php'); 
include ('menu.php');
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_koneksi, $koneksi);
$query_Recordset1 = "SELECT * FROM jurusan ORDER by IDJUR";
$Recordset1 = mysql_query($query_Recordset1, $koneksi) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
a:link {
	color: #000000;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #000000;
}
a:hover {
	text-decoration: underline;
	color: #666666;
}
a:active {
	text-decoration: none;
	color: #000000;
}
-->
</style>



</head>
<body>
<table class="myTable" border="1">
  <tr class="myTableth">
    <td width="40"><div align="center">ID</div></td>
    <td width="250"><div align="center">Nama Program Keahlian</div></td>
    <td width="80"><div align="center">Kuota</div></td>
    <td width="150"><div align="center">Edit</div></td>
  </tr>
  <?php do { ?>
    <tr>
      <td width="40"><div align="center"><?php echo $row_Recordset1['IDJUR']; ?></div></td>
      <td width="250"><?php echo $row_Recordset1['NAMAJURUSAN']; ?></td>
      <td width="80"><div align="center"><?php echo $row_Recordset1['JUMLAHMAKS']; ?></div></td>
      <td><a href="jurusanedit.php?IDJUR=<?php echo $row_Recordset1['IDJUR']; ?>"><input type="button" value="  Edit  " />
</a>&nbsp;&nbsp;&nbsp;
         <input type="button" onClick="show_confirm_del<?php echo $row_Recordset1['IDJUR']; ?>()" value="Delete" />
      
<script type="text/javascript">
function show_confirm_del<?php echo $row_Recordset1['IDJUR']; ?>()
{
var r=confirm("Anda Akan Menghapus<?php echo $row_Recordset1['NAMAJURUSAN']; ?>");
if (r==true)
  {
  window.location="jurusandel.php?IDJUR=<?php echo $row_Recordset1['IDJUR']; ?>";
  }
}
</script>
      
      
      </td>
    </tr>
    <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
</table>
<p><a href="jurusanadd.php">Tambah Program Keahlian</a></p>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
