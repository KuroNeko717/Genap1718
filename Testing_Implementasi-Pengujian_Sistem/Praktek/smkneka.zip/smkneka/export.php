<?php require_once('Connections/koneksi.php'); ?><?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_koneksi, $koneksi);
$query_siswa = "SELECT calonsiswa.NOPENDAFTARAN, calonsiswa.NAMASISWA, calonsiswa.ASALSMP, jurusan.NAMAJURUSAN, calonsiswa.IDPILJUR2 as PILIHAN_2, calonsiswa.TEMPATLAHIR, calonsiswa.TGLLAHIR, calonsiswa.JENISKELAMIN, calonsiswa.AGAMA, calonsiswa.ALAMAT, calonsiswa.KOTAALAMAT, calonsiswa.PROPINSI, calonsiswa.NOTELPRUMAH, calonsiswa.NOHP, calonsiswa.NOIJASAH, calonsiswa.TGLIJASAH, calonsiswa.NOSKHUN, calonsiswa.TGLSKHUN, calonsiswa.KOTAASALSMP, calonsiswa.NAMAAYAH, calonsiswa.PEKERJAANAYAH, calonsiswa.NOHPAYAH, calonsiswa.NAMAIBU, calonsiswa.PEKERJAANIBU, calonsiswa.ALAMATAYAH, calonsiswa.KOTAALAMATAYAH, calonsiswa.NAMAWALI, calonsiswa.ALAMATWALI, calonsiswa.PEKERJAANWALI, calonsiswa.NOHPWALI, calonsiswa.NUN, nilaiakhir.NUN as BUN, nilaiakhir.US, nilaiakhir.NA, calonsiswa.PRESTASI FROM nilaiakhir INNER JOIN calonsiswa ON calonsiswa.IDPENDAFTARAN = nilaiakhir.IDPENDAFTARAN INNER JOIN jurusan ON calonsiswa.IDPILJUR1 = jurusan.IDJUR ORDER BY NOPENDAFTARAN";
$siswa = mysql_query($query_siswa, $koneksi) or die(mysql_error());
$row_siswa = mysql_fetch_assoc($siswa);
$totalRows_siswa = mysql_num_rows($siswa);



?>

<?php 

$file="ppdb.xls";

for ($i=1;$i<=$totalRows_siswa;$i++){
$therow = "
<tr>
	<td>".$row_siswa['NOPENDAFTARAN']."</td>
    <td>".$row_siswa['NAMASISWA']."</td>
	<td>".$row_siswa['ASALSMP']."</td>
    <td>".$row_siswa['NAMAJURUSAN']."</td>
    <td>".$row_siswa['PILIHAN_2']."</td>
    <td>".$row_siswa['TEMPATLAHIR']."</td>
    <td>".$row_siswa['TGLLAHIR']."</td>
    <td>".$row_siswa['JENISKELAMIN']."</td>
    <td>".$row_siswa['AGAMA']."</td>
    <td>".$row_siswa['ALAMAT']."</td>
    <td>".$row_siswa['KOTAALAMAT']."</td>
    <td>".$row_siswa['PROPINSI']."</td>
    <td>".$row_siswa['NOTELPRUMAH']."</td>
    <td>".$row_siswa['NOHP']."</td>
    <td>".$row_siswa['NOIJASAH']."</td>
    <td>".$row_siswa['TGLIJASAH']."</td>
    <td>".$row_siswa['NOSKHUN']."</td>
    <td>".$row_siswa['TGLSKHUN']."</td>
    <td>".$row_siswa['KOTAASALSMP']."</td>
    <td>".$row_siswa['NAMAAYAH']."</td>
    <td>".$row_siswa['PEKERJAANAYAH']."</td>
    <td>".$row_siswa['NOHPAYAH']."</td>
    <td>".$row_siswa['NAMAIBU']."</td>
    <td>".$row_siswa['PEKERJAANIBU']."</td>
    <td>".$row_siswa['ALAMATAYAH']."</td>
    <td>".$row_siswa['KOTAALAMATAYAH']."</td>
    <td>".$row_siswa['NAMAWALI']."</td>
    <td>".$row_siswa['ALAMATWALI']."</td>
    <td>".$row_siswa['PEKERJAANWALI']."</td>
    <td>".$row_siswa['NOHPWALI']."</td>
    <td>".$row_siswa['NUN']."</td>
	<td>".$row_siswa['BUN']."</td>
    <td>".$row_siswa['US']."</td>
    <td>".$row_siswa['NA']."</td>
    <td>".$row_siswa['PRESTASI']."</td> 
</tr>";

$hasil = $hasil . $therow;
$row_siswa = mysql_fetch_array($siswa);
}

$test = "<table border=1>
<tr>
    <td>No Pendaftaran</td>
    <td>Nama Siswa</td>
    <td>Asal Sekolah</td>
    <td>Proli Pilihan 1</td>
    <td>Proli Pilihan 2</td>
    <td>Tempat Lahir</td>
    <td>Tanggal Lahir</td>
    <td>Jenis Kelamin</td>
    <td>Agama</td>
    <td>Alamat Rumah</td>
    <td>Kota</td>
    <td>Propinsi</td>
    <td>No Telp</td>
    <td>No HP</td>
    <td>No Ijazah</td>
    <td>Tgl Ijazah</td>
    <td>No SKHUN</td>
    <td>Tgl SKHUN</td>
    <td>Kota Asal Sekolah</td>
    <td>Nama Ayah</td>
    <td>Pekerjaan Ayah</td>
    <td>No Telp Ayah</td>
    <td>Nama Ibu</td>
    <td>Pekerjaan Ibu</td>
    <td>Alamat</td>
    <td>Kota</td>
    <td>Nama Wali</td>
    <td>Alamat</td>
    <td>Pekerjaan</td>
    <td>No Telp Wali</td>
    <td>NUN</td>
    <td>Bobot NUN</td>	
    <td>Ujian Sekolah</td>
    <td>Total Nilai</td>
    <td>Prestasi</td>
  </tr>

".$hasil."</table>";

header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=$file");
echo $test;

?>

<?php
mysql_free_result($siswa);
?>
