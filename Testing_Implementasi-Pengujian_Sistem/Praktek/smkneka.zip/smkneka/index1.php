<?php require_once('Connections/koneksi.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['username'])) {
  $loginUsername=$_POST['username'];
  $password=md5($_POST['password']);
  $MM_fldUserAuthorization = "LEVEL";
  $MM_redirectLoginSuccess = "index2.php";
  $MM_redirectLoginFailed = "index1.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_koneksi, $koneksi);
  	
  $LoginRS__query=sprintf("SELECT USERNAMEPETUGAS, PASSWORDPETUGAS, LEVEL FROM petugas WHERE USERNAMEPETUGAS=%s AND PASSWORDPETUGAS=%s",
  GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $koneksi) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
    
    $loginStrGroup  = mysql_result($LoginRS,0,'LEVEL');
    
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;
	$_SESSION['user'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $title ?></title>
<style type="text/css">
<!--
.style1 {	font-family: Geneva, Arial, Helvetica, sans-serif
}
.style2 {color: #666666}
.style3 {
	font-size: 12px
}
.style4 {
	color: #666666;
	font-size: 12px;
}
.style5 {font-size: 12}
-->
</style>
</head>

<body><img src="images/header.jpg" />
<form id="form1" name="form1" method="POST" action="<?php echo $loginFormAction; ?>">
  <label></label>
  <table width="1024" height="24" border="0" align="left" cellpadding="0" cellspacing="0">
    <tr>
      <td width="37" height="24" bgcolor="#EEEEEE" class="style1"><p align="right" class="style2 style3">&nbsp;</p>      </td>
      <td width="7" bgcolor="#EEEEEE" class="style1"><p align="right" class="style2"><span class="style2">
        <label></label>
          </span>
          <label> </label>
      </p>      </td>
      <td width="84" bgcolor="#EEEEEE" class="style1"><p><a href="index.php">HOME</a></p>      </td>
      <td width="37" bgcolor="#EEEEEE" class="style1">&nbsp;</td>
      <td width="840" align="left" valign="middle" bgcolor="#EEEEEE" class="style1"><p align="right" class="style5">
        <span class="style4">
        <span class="style2 style3">Username</span>
        <input type="text" name="username" id="username" />
        Password</span>
        <input type="password" name="password" id="password" />
        <input type="submit" name="login" id="login" value="Login" />
      </p>      </td>
      <td width="19" align="left" valign="middle" bgcolor="#EEEEEE" class="style1">&nbsp;</td>
    </tr>
  </table>
  <label></label>
  <p>
    <label></label>
  </p>
</form>
<p align="center">&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>
