<?php require_once('Connections/koneksi.php'); 
if (!isset($_SESSION)) {
  session_start();
}

$group = $_SESSION['MM_UserGroup'];

if($group == "ADMIN"){
include('menu.php');
} elseif ($group == "PANITIA"){
include('menu2.php');
} else {
header( 'Location: input.php' ) ;
}

?>
