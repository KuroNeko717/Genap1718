/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50137
Source Host           : localhost:3306
Source Database       : ppdb

Target Server Type    : MYSQL
Target Server Version : 50137
File Encoding         : 65001

Date: 2012-06-24 22:08:10
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `berita`
-- ----------------------------
DROP TABLE IF EXISTS `berita`;
CREATE TABLE `berita` (
  `IDBERITA` bigint(20) NOT NULL AUTO_INCREMENT,
  `JUDUL` varchar(255) DEFAULT NULL,
  `ISIAWAL` text,
  `ISILANJUT` text,
  `DATE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`IDBERITA`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of berita
-- ----------------------------

-- ----------------------------
-- Table structure for `calon`
-- ----------------------------
DROP TABLE IF EXISTS `calon`;
CREATE TABLE `calon` (
  `IDPENDAFTARAN` int(11) NOT NULL AUTO_INCREMENT,
  `IDPILJUR1` tinyint(4) NOT NULL,
  `IDPILJUR2` tinyint(4) NOT NULL,
  `IDPETUGAS` tinyint(4) NOT NULL,
  `NOPENDAFTARAN` int(11) DEFAULT NULL,
  `NAMASISWA` varchar(50) DEFAULT NULL,
  `TEMPATLAHIR` varchar(50) DEFAULT NULL,
  `TGLLAHIR` varchar(20) DEFAULT NULL,
  `JENISKELAMIN` char(1) DEFAULT NULL,
  `AGAMA` varchar(20) DEFAULT NULL,
  `ALAMAT` varchar(100) DEFAULT NULL,
  `KOTAALAMAT` varchar(50) DEFAULT NULL,
  `PROPINSI` varchar(30) DEFAULT NULL,
  `NOTELPRUMAH` varchar(20) DEFAULT NULL,
  `NOHP` text,
  `FOTO` varchar(100) DEFAULT NULL,
  `NOIJASAH` varchar(50) DEFAULT NULL,
  `TGLIJASAH` varchar(20) DEFAULT NULL,
  `NUN` varchar(5) DEFAULT NULL,
  `NOSKHUN` varchar(50) DEFAULT NULL,
  `TGLSKHUN` varchar(20) DEFAULT NULL,
  `ASALSMP` varchar(50) DEFAULT NULL,
  `KOTAASALSMP` varchar(30) DEFAULT NULL,
  `NAMAAYAH` varchar(50) DEFAULT NULL,
  `PEKERJAANAYAH` varchar(50) DEFAULT NULL,
  `NOHPAYAH` varchar(20) DEFAULT NULL,
  `NAMAIBU` varchar(50) DEFAULT NULL,
  `PEKERJAANIBU` varchar(30) DEFAULT NULL,
  `ALAMATAYAH` varchar(100) DEFAULT NULL,
  `KOTAALAMATAYAH` varchar(30) DEFAULT NULL,
  `NAMAWALI` varchar(50) DEFAULT NULL,
  `ALAMATWALI` varchar(100) DEFAULT NULL,
  `PEKERJAANWALI` varchar(30) DEFAULT NULL,
  `NOHPWALI` varchar(20) DEFAULT NULL,
  `POINT` tinyint(4) DEFAULT NULL,
  `PRESTASI` mediumtext,
  `CATATANLAIN` mediumtext,
  `APPROVE` char(1) DEFAULT NULL,
  PRIMARY KEY (`IDPENDAFTARAN`),
  UNIQUE KEY `CALONSISWA_PK` (`IDPENDAFTARAN`),
  KEY `MEMILIH1_FK` (`IDPILJUR1`),
  KEY `MEMILIH2_FK` (`IDPILJUR2`),
  KEY `ENTRI_FK` (`IDPETUGAS`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of calon
-- ----------------------------

-- ----------------------------
-- Table structure for `calonsiswa`
-- ----------------------------
DROP TABLE IF EXISTS `calonsiswa`;
CREATE TABLE `calonsiswa` (
  `IDPENDAFTARAN` int(11) NOT NULL AUTO_INCREMENT,
  `IDPILJUR1` tinyint(4) NOT NULL,
  `IDPILJUR2` tinyint(4) NOT NULL,
  `IDPETUGAS` tinyint(4) NOT NULL,
  `NOPENDAFTARAN` int(11) DEFAULT NULL,
  `NAMASISWA` varchar(50) DEFAULT NULL,
  `TEMPATLAHIR` varchar(50) DEFAULT NULL,
  `TGLLAHIR` varchar(20) DEFAULT NULL,
  `JENISKELAMIN` char(1) DEFAULT NULL,
  `AGAMA` varchar(20) DEFAULT NULL,
  `ALAMAT` varchar(100) DEFAULT NULL,
  `KOTAALAMAT` varchar(50) DEFAULT NULL,
  `PROPINSI` varchar(30) DEFAULT NULL,
  `NOTELPRUMAH` varchar(20) DEFAULT NULL,
  `NOHP` text,
  `FOTO` varchar(100) DEFAULT NULL,
  `NOIJASAH` varchar(50) DEFAULT NULL,
  `TGLIJASAH` varchar(20) DEFAULT NULL,
  `NUN` varchar(5) DEFAULT NULL,
  `NOSKHUN` varchar(50) DEFAULT NULL,
  `TGLSKHUN` varchar(20) DEFAULT NULL,
  `ASALSMP` varchar(50) DEFAULT NULL,
  `KOTAASALSMP` varchar(30) DEFAULT NULL,
  `NAMAAYAH` varchar(50) DEFAULT NULL,
  `PEKERJAANAYAH` varchar(50) DEFAULT NULL,
  `NOHPAYAH` varchar(20) DEFAULT NULL,
  `NAMAIBU` varchar(50) DEFAULT NULL,
  `PEKERJAANIBU` varchar(30) DEFAULT NULL,
  `ALAMATAYAH` varchar(100) DEFAULT NULL,
  `KOTAALAMATAYAH` varchar(30) DEFAULT NULL,
  `NAMAWALI` varchar(50) DEFAULT NULL,
  `ALAMATWALI` varchar(100) DEFAULT NULL,
  `PEKERJAANWALI` varchar(30) DEFAULT NULL,
  `NOHPWALI` varchar(20) DEFAULT NULL,
  `POINT` tinyint(4) DEFAULT NULL,
  `PRESTASI` mediumtext,
  `CATATANLAIN` mediumtext,
  `APPROVE` char(1) DEFAULT NULL,
  PRIMARY KEY (`IDPENDAFTARAN`),
  UNIQUE KEY `CALONSISWA_PK` (`IDPENDAFTARAN`),
  KEY `MEMILIH1_FK` (`IDPILJUR1`),
  KEY `MEMILIH2_FK` (`IDPILJUR2`),
  KEY `ENTRI_FK` (`IDPETUGAS`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of calonsiswa
-- ----------------------------

-- ----------------------------
-- Table structure for `jurusan`
-- ----------------------------
DROP TABLE IF EXISTS `jurusan`;
CREATE TABLE `jurusan` (
  `IDJUR` tinyint(4) NOT NULL AUTO_INCREMENT,
  `NAMAJURUSAN` varchar(50) DEFAULT NULL,
  `JUMLAHMAKS` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDJUR`),
  UNIQUE KEY `JURUSANPILIHAN1_PK` (`IDJUR`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of jurusan
-- ----------------------------

-- ----------------------------
-- Table structure for `nilai`
-- ----------------------------
DROP TABLE IF EXISTS `nilai`;
CREATE TABLE `nilai` (
  `IDNILAI` bigint(4) NOT NULL AUTO_INCREMENT,
  `IDPENDAFTARAN` int(11) DEFAULT NULL,
  `IDUJIAN` tinyint(4) DEFAULT NULL,
  `NILAIUJIAN` tinyint(4) DEFAULT NULL,
  `IDJUR` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`IDNILAI`)
) ENGINE=MyISAM AUTO_INCREMENT=184 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of nilai
-- ----------------------------

-- ----------------------------
-- Table structure for `nilaiakhir`
-- ----------------------------
DROP TABLE IF EXISTS `nilaiakhir`;
CREATE TABLE `nilaiakhir` (
  `IDPENDAFTARAN` int(11) NOT NULL DEFAULT '0',
  `NUN` decimal(11,4) DEFAULT NULL,
  `US` decimal(11,4) DEFAULT NULL,
  `NA` decimal(11,4) DEFAULT NULL,
  PRIMARY KEY (`IDPENDAFTARAN`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of nilaiakhir
-- ----------------------------

-- ----------------------------
-- Table structure for `petugas`
-- ----------------------------
DROP TABLE IF EXISTS `petugas`;
CREATE TABLE `petugas` (
  `IDPETUGAS` tinyint(4) NOT NULL AUTO_INCREMENT,
  `NAMAPETUGAS` varchar(50) DEFAULT NULL,
  `USERNAMEPETUGAS` varchar(20) NOT NULL DEFAULT '',
  `PASSWORDPETUGAS` varchar(50) DEFAULT NULL,
  `LEVEL` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`IDPETUGAS`,`USERNAMEPETUGAS`),
  UNIQUE KEY `PETUGAS_PK` (`IDPETUGAS`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of petugas
-- ----------------------------
INSERT INTO petugas VALUES ('1', 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'ADMIN');
INSERT INTO petugas VALUES ('3', 'petugas', 'petugas', 'afb91ef692fd08c445e8cb1bab2ccf9c', 'PETUGAS');
INSERT INTO petugas VALUES ('2', 'panitia', 'panitia', 'd32b1673837a6a45f795c13ea67ec79e', 'PANITIA');

-- ----------------------------
-- Table structure for `propinsi`
-- ----------------------------
DROP TABLE IF EXISTS `propinsi`;
CREATE TABLE `propinsi` (
  `IdPropinsi` tinyint(2) NOT NULL,
  `NamaPropinsi` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`IdPropinsi`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of propinsi
-- ----------------------------
INSERT INTO propinsi VALUES ('0', 'Pusat');
INSERT INTO propinsi VALUES ('1', 'DKI Jakarta');
INSERT INTO propinsi VALUES ('2', 'Jawa Barat');
INSERT INTO propinsi VALUES ('3', 'Jawa Tengah');
INSERT INTO propinsi VALUES ('4', 'DI Yogyakarta');
INSERT INTO propinsi VALUES ('5', 'Jawa Timur');
INSERT INTO propinsi VALUES ('6', 'Nanggroe Aceh Darussalam');
INSERT INTO propinsi VALUES ('7', 'Sumatera Utara');
INSERT INTO propinsi VALUES ('8', 'Sumatera Barat');
INSERT INTO propinsi VALUES ('9', 'Riau');
INSERT INTO propinsi VALUES ('10', 'Jambi');
INSERT INTO propinsi VALUES ('11', 'Sumatera Selatan');
INSERT INTO propinsi VALUES ('12', 'Lampung');
INSERT INTO propinsi VALUES ('13', 'Kalimantan Barat');
INSERT INTO propinsi VALUES ('14', 'Kalimantan Tengah');
INSERT INTO propinsi VALUES ('15', 'Kalimantan Selatan');
INSERT INTO propinsi VALUES ('16', 'Kalimantan Timur');
INSERT INTO propinsi VALUES ('17', 'Sulawesi Utara');
INSERT INTO propinsi VALUES ('18', 'Sulawesi Tengah');
INSERT INTO propinsi VALUES ('19', 'Sulawesi Selatan');
INSERT INTO propinsi VALUES ('20', 'Sulawesi Tenggara');
INSERT INTO propinsi VALUES ('21', 'Maluku');
INSERT INTO propinsi VALUES ('22', 'Bali');
INSERT INTO propinsi VALUES ('23', 'Nusa Tenggara Barat');
INSERT INTO propinsi VALUES ('24', 'Nusa Tenggara Timur');
INSERT INTO propinsi VALUES ('25', 'Papua');
INSERT INTO propinsi VALUES ('26', 'Bengkulu');
INSERT INTO propinsi VALUES ('28', 'Maluku Utara');
INSERT INTO propinsi VALUES ('29', 'Banten');
INSERT INTO propinsi VALUES ('30', 'Bangka Belitung');
INSERT INTO propinsi VALUES ('31', 'Gorontalo');
INSERT INTO propinsi VALUES ('32', 'Kepulauan Riau');
INSERT INTO propinsi VALUES ('33', 'Irian Jaya Barat');
INSERT INTO propinsi VALUES ('34', 'Sulawesi Barat');

-- ----------------------------
-- Table structure for `rangking`
-- ----------------------------
DROP TABLE IF EXISTS `rangking`;
CREATE TABLE `rangking` (
  `PERINGKAT` int(11) DEFAULT NULL,
  `IDPENDAFTARAN` int(11) DEFAULT NULL,
  `IDJUR` int(11) DEFAULT NULL,
  `NAMAJURUSAN` varchar(50) DEFAULT NULL,
  `NA` decimal(10,0) DEFAULT NULL,
  `KUOTA` int(11) DEFAULT NULL,
  `PIL1` tinyint(4) DEFAULT NULL,
  `PIL2` tinyint(4) DEFAULT NULL,
  `MASUKJUR` tinyint(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of rangking
-- ----------------------------

-- ----------------------------
-- Table structure for `setting`
-- ----------------------------
DROP TABLE IF EXISTS `setting`;
CREATE TABLE `setting` (
  `IDSET` tinyint(4) NOT NULL AUTO_INCREMENT,
  `NAMASET` varchar(50) DEFAULT NULL,
  `SET1` varchar(50) DEFAULT NULL,
  `SET2` varchar(50) DEFAULT NULL,
  `SET3` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IDSET`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of setting
-- ----------------------------
INSERT INTO setting VALUES ('3', 'Ujian Nasional', '40', '40', null);

-- ----------------------------
-- Table structure for `ujian`
-- ----------------------------
DROP TABLE IF EXISTS `ujian`;
CREATE TABLE `ujian` (
  `IDUJIAN` tinyint(4) NOT NULL AUTO_INCREMENT,
  `NAMAUJIAN` varchar(50) DEFAULT NULL,
  `BOBOT` tinyint(4) DEFAULT NULL,
  `SKORMAKSIMAL` tinyint(4) DEFAULT NULL,
  `IDJUR` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`IDUJIAN`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of ujian
-- ----------------------------
