/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50137
Source Host           : localhost:3306
Source Database       : psb

Target Server Type    : MYSQL
Target Server Version : 50137
File Encoding         : 65001

Date: 2012-06-24 22:06:25
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `berita`
-- ----------------------------
DROP TABLE IF EXISTS `berita`;
CREATE TABLE `berita` (
  `IDBERITA` bigint(20) NOT NULL AUTO_INCREMENT,
  `JUDUL` varchar(255) DEFAULT NULL,
  `ISIAWAL` text,
  `ISILANJUT` text,
  `DATE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`IDBERITA`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of berita
-- ----------------------------
INSERT INTO berita VALUES ('31', 'Syarat dan Ketentuan', '<ol>\r\n<li>Calon peserta didik datang sendiri untuk proses verifikasi</li>\r\n<li>Calon peserta didik dapat memilih dua Kompetensi Keahlian</li>\r\n<li>Calon peserta didik dapat mengisi formulir melalui online atau offline</li>\r\n<li>Calon peserta didik menyerahkan :</li>\r\n</ol>\r\n<ul>\r\n<li>Formulir pendaftaran yang lengkap</li>\r\n<li>Fotocopy Danun terlegalisir 1 lembar</li>\r\n<li>Fotocopy Ijazah, STL/STK yang dilegalisir 1 lembar</li>\r\n<li>Fotocopy Akta Kelahiran 1 lembar</li>\r\n<li>Rapor asli</li>\r\n<li>Ijazah dan Danun/SKHUN Asli</li>\r\n<li>Foto Hitam putih 3x4 = 1 lembar</li>\r\n</ul>\r\n<p>&nbsp;</p>', null, '0000-00-00 00:00:00');
INSERT INTO berita VALUES ('13', 'Kompetensi Keahlian dan Pagu', '<ol>\r\n<li>Teknik Kendaraan Ringan (TKR) 36 Siswa</li>\r\n<li>Busana Butik (BB) 36 Siswa</li>\r\n<li>Multimedia (MM) 36 Siswa</li>\r\n<li>Teknik Komputer dan Jaringan (TKJ) 36 Siswa</li>\r\n<li>Perbankan (PB) 36 Siswa</li>\r\n</ol>', null, '0000-00-00 00:00:00');

-- ----------------------------
-- Table structure for `calon`
-- ----------------------------
DROP TABLE IF EXISTS `calon`;
CREATE TABLE `calon` (
  `IDPENDAFTARAN` int(11) NOT NULL AUTO_INCREMENT,
  `IDPILJUR1` tinyint(4) NOT NULL,
  `IDPILJUR2` tinyint(4) NOT NULL,
  `IDPETUGAS` tinyint(4) NOT NULL,
  `NOPENDAFTARAN` int(11) DEFAULT NULL,
  `NAMASISWA` varchar(50) DEFAULT NULL,
  `TEMPATLAHIR` varchar(50) DEFAULT NULL,
  `TGLLAHIR` varchar(20) DEFAULT NULL,
  `JENISKELAMIN` char(1) DEFAULT NULL,
  `AGAMA` varchar(20) DEFAULT NULL,
  `ALAMAT` varchar(100) DEFAULT NULL,
  `KOTAALAMAT` varchar(50) DEFAULT NULL,
  `PROPINSI` varchar(30) DEFAULT NULL,
  `NOTELPRUMAH` varchar(20) DEFAULT NULL,
  `NOHP` text,
  `FOTO` varchar(100) DEFAULT NULL,
  `NOIJASAH` varchar(50) DEFAULT NULL,
  `TGLIJASAH` varchar(20) DEFAULT NULL,
  `NUN` varchar(5) DEFAULT NULL,
  `NOSKHUN` varchar(50) DEFAULT NULL,
  `TGLSKHUN` varchar(20) DEFAULT NULL,
  `ASALSMP` varchar(50) DEFAULT NULL,
  `KOTAASALSMP` varchar(30) DEFAULT NULL,
  `NAMAAYAH` varchar(50) DEFAULT NULL,
  `PEKERJAANAYAH` varchar(50) DEFAULT NULL,
  `NOHPAYAH` varchar(20) DEFAULT NULL,
  `NAMAIBU` varchar(50) DEFAULT NULL,
  `PEKERJAANIBU` varchar(30) DEFAULT NULL,
  `ALAMATAYAH` varchar(100) DEFAULT NULL,
  `KOTAALAMATAYAH` varchar(30) DEFAULT NULL,
  `NAMAWALI` varchar(50) DEFAULT NULL,
  `ALAMATWALI` varchar(100) DEFAULT NULL,
  `PEKERJAANWALI` varchar(30) DEFAULT NULL,
  `NOHPWALI` varchar(20) DEFAULT NULL,
  `POINT` tinyint(4) DEFAULT NULL,
  `PRESTASI` mediumtext,
  `CATATANLAIN` mediumtext,
  `APPROVE` char(1) DEFAULT NULL,
  PRIMARY KEY (`IDPENDAFTARAN`),
  UNIQUE KEY `CALONSISWA_PK` (`IDPENDAFTARAN`),
  KEY `MEMILIH1_FK` (`IDPILJUR1`),
  KEY `MEMILIH2_FK` (`IDPILJUR2`),
  KEY `ENTRI_FK` (`IDPETUGAS`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of calon
-- ----------------------------

-- ----------------------------
-- Table structure for `calonsiswa`
-- ----------------------------
DROP TABLE IF EXISTS `calonsiswa`;
CREATE TABLE `calonsiswa` (
  `IDPENDAFTARAN` int(11) NOT NULL AUTO_INCREMENT,
  `IDPILJUR1` tinyint(4) NOT NULL,
  `IDPILJUR2` tinyint(4) NOT NULL,
  `IDPETUGAS` tinyint(4) NOT NULL,
  `NOPENDAFTARAN` int(11) DEFAULT NULL,
  `NAMASISWA` varchar(50) DEFAULT NULL,
  `TEMPATLAHIR` varchar(50) DEFAULT NULL,
  `TGLLAHIR` varchar(20) DEFAULT NULL,
  `JENISKELAMIN` char(1) DEFAULT NULL,
  `AGAMA` varchar(20) DEFAULT NULL,
  `ALAMAT` varchar(100) DEFAULT NULL,
  `KOTAALAMAT` varchar(50) DEFAULT NULL,
  `PROPINSI` varchar(30) DEFAULT NULL,
  `NOTELPRUMAH` varchar(20) DEFAULT NULL,
  `NOHP` text,
  `FOTO` varchar(100) DEFAULT NULL,
  `NOIJASAH` varchar(50) DEFAULT NULL,
  `TGLIJASAH` varchar(20) DEFAULT NULL,
  `NUN` varchar(5) DEFAULT NULL,
  `NOSKHUN` varchar(50) DEFAULT NULL,
  `TGLSKHUN` varchar(20) DEFAULT NULL,
  `ASALSMP` varchar(50) DEFAULT NULL,
  `KOTAASALSMP` varchar(30) DEFAULT NULL,
  `NAMAAYAH` varchar(50) DEFAULT NULL,
  `PEKERJAANAYAH` varchar(50) DEFAULT NULL,
  `NOHPAYAH` varchar(20) DEFAULT NULL,
  `NAMAIBU` varchar(50) DEFAULT NULL,
  `PEKERJAANIBU` varchar(30) DEFAULT NULL,
  `ALAMATAYAH` varchar(100) DEFAULT NULL,
  `KOTAALAMATAYAH` varchar(30) DEFAULT NULL,
  `NAMAWALI` varchar(50) DEFAULT NULL,
  `ALAMATWALI` varchar(100) DEFAULT NULL,
  `PEKERJAANWALI` varchar(30) DEFAULT NULL,
  `NOHPWALI` varchar(20) DEFAULT NULL,
  `POINT` tinyint(4) DEFAULT NULL,
  `PRESTASI` mediumtext,
  `CATATANLAIN` mediumtext,
  `APPROVE` char(1) DEFAULT NULL,
  PRIMARY KEY (`IDPENDAFTARAN`),
  UNIQUE KEY `CALONSISWA_PK` (`IDPENDAFTARAN`),
  KEY `MEMILIH1_FK` (`IDPILJUR1`),
  KEY `MEMILIH2_FK` (`IDPILJUR2`),
  KEY `ENTRI_FK` (`IDPETUGAS`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of calonsiswa
-- ----------------------------
INSERT INTO calonsiswa VALUES ('1', '4', '1', '0', '101', 'INKAM SUSANTI', 'Lamongan', '19960604', 'P', 'Islam', 'Ds. Mayong Kec Kalitengah', 'Lamongan', 'Jawa Timur', '085706333333', '085706333333', null, '323/2323/D/1', '20120501', '36.53', '323/2323/D/1', '20120501', 'SMPN 1 Kalitengah', 'Lamongan', 'LUKMAN HADI', 'Tani', '081331313113', 'NOPRI MURTASIAH', 'Tani', 'Ds. Mayong Kec Kalitengah', 'Lamongan', null, null, null, null, null, null, 'OKE', '1');
INSERT INTO calonsiswa VALUES ('2', '1', '2', '0', '102', 'JAYANTI', 'Lamongan', '19960101', 'P', 'Islam', 'Karanggeneng', 'Lamongan', 'Jawa Timur', '085706333333', '85706333333', null, '323/2323/D/2', '20120501', '36.53', '323/2323/D/2', '20120501', 'SMPN 1 Kalitengah', 'Lamongan', 'MAWI BAWAJI AHMAD NUR', 'Tani', '85706333333', 'NUR HAMIYAH', null, 'Karanggeneng', 'Lamongan', null, null, null, null, '0', null, 'OKE', '1');
INSERT INTO calonsiswa VALUES ('3', '4', '3', '0', '103', 'LULUK AGUSTINAH', 'Lamongan', '19970101', 'P', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '81331313113', '81331313113', null, '323/2323/D/3', '20120601', '38', '323/2323/D/3', '20120601', 'SMPN 1 Kalitengah', 'Lamongan', 'Achmad Danang Ainurrozaq', 'PNS', '85706333333', 'OKTABELLA DWI HAKIKI', 'Wirausaha', 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('4', '1', '4', '0', '104', 'MOHAMAD IMAM HARIS FADLI', 'Lamongan', '19960101', 'L', 'Islam', 'Mertani', 'Lamongan', 'Jawa Timur', '85706333333', '85706333333', null, '323/2323/D/4', '20120501', '37', '323/2323/D/4', '20120501', 'SMPN 1 Kalitengah', 'Lamongan', 'Achmad Nizarwanto', 'Tani', '81331313113', 'PUTRI DIANTARI', null, 'Mertani', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('5', '1', '5', '0', '105', 'MUKHAROMAH', 'Lamongan', '19970604', 'P', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '85706333333', '85706333333', null, '323/2323/D/5', '20120601', '36', '323/2323/D/5', '20120601', 'SMPN 1 Kalitengah', 'Lamongan', 'Achmad Zainuri', 'Tani', '82497985172', 'Satuning Tyas', null, 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('6', '1', '2', '0', '106', 'NISKA LUKMANA PUTRI', 'Lamongan', '19961221', 'P', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '81331313113', '81331313113', null, '323/2323/D/6', '20120601', '35', '323/2323/D/6', '20120601', 'SMPN 1 Karanggeneg', 'Lamongan', 'Adi Setiawan', 'PNS', '81997982861', 'Septa Sri Andriani', null, 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '10', 'Juara 1 Tk Propinsi', null, '1');
INSERT INTO calonsiswa VALUES ('7', '1', '4', '0', '107', 'NUR HIDAYAH', 'Lamongan', '19960604', 'P', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '85706333333', '85706333333', null, '323/2323/D/7', '20120601', '34', '323/2323/D/7', '20120601', 'SMPN 1 Kalitengah', 'Lamongan', 'Adit Purwandoko', 'TNI', '81497980550', 'Septy Noviana Mulis', 'Wirausaha', 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '10', 'Juara 3 Tk Propinsi', null, '1');
INSERT INTO calonsiswa VALUES ('8', '3', '4', '0', '108', 'NURUL AZIZAH', 'Lamongan', '19960101', 'P', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '085706333333', '85706333333', null, '323/2323/D/8', '20120601', '33', '323/2323/D/8', '20120601', 'SMPN 1 Karanggeneg', 'Lamongan', 'Agus Bastian', 'Tani', '80997978239', 'Siti Rukhana', 'Tani', 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('9', '3', '5', '0', '109', 'RIRIN SAFAATIN', 'Lamongan', '19970101', 'P', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '081331313113', '81331313113', null, '323/2323/D/9', '20120601', '32', '323/2323/D/9', '20120601', 'SMPN 1 Kalitengah', 'Lamongan', 'Agus Suprapto', 'Tani', '81331313113', 'Siti Wahyu Tri Warni', 'Tani', 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, null, null, null, '1');
INSERT INTO calonsiswa VALUES ('10', '3', '4', '0', '110', 'ROSA KUSPAWESTRI', 'Lamongan', '19960101', 'P', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '082497985172', '82497985172', null, '323/2323/D/10', '20120601', '38', '323/2323/D/10', '20120601', 'SMPN 1 Karanggeneg', 'Lamongan', 'Ahmad Afrianto', 'Tani', '85706333333', 'Siti Zulaikha', 'Wirausaha', 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('11', '3', '4', '0', '111', 'SEFI ARIYANTIKA', 'Lamongan', '19970604', 'P', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '081997982861', '81997982861', null, '323/2323/D/11', '20120601', '37', '323/2323/D/11', '20120601', 'SMPN 1 Kalitengah', 'Lamongan', 'Ahmad Itsnaini P. Kh. N', 'PNS', '85706333333', 'Nur Azizah', null, 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('12', '3', '2', '0', '112', 'SETIO PAMUJI UTOMO', 'Surabaya', '19961221', 'L', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '81497980550', '81497980550', null, '323/2323/D/12', '20120601', '36', '323/2323/D/12', '20120601', 'SMPN 1 Sukodadi', 'Lamongan', 'Ahmad Makhis Hamdani', 'Tani', '81331313113', 'Nur Hadi Darmawan', 'Wirausaha', 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('13', '3', '5', '0', '113', 'SIGIT SAPTO WAHYONOR', 'Mojokerto', '19960604', 'L', 'Islam', 'Ds. Mayong Kec Kalitengah', 'Lamongan', 'Jawa Timur', '80997978239', '80997978239', null, '323/2323/D/13', '20120601', '35', '323/2323/D/13', '20120601', 'SMPN 1 Kalitengah', 'Lamongan', 'Ahmad Muzzamil', 'Tani', '82497985172', 'Nur Laili Hidayah', 'Wirausaha', 'Ds. Mayong Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('14', '4', '1', '0', '114', 'SRI HARTATIK', 'Lamongan', '19960101', 'P', 'Islam', 'Karanggeneng', 'Lamongan', 'Jawa Timur', '80497975928', '80497975928', null, '323/2323/D/14', '20120601', '34', '323/2323/D/14', '20120601', 'SMPN 1 Karanggeneg', 'Lamongan', 'Ahmad Saifudin', 'Tani', '81997982861', 'Nur Sholihah', 'Tani', 'Karanggeneng', 'Lamongan', null, null, null, null, '5', 'Juara Tk Kabupaten', null, '1');
INSERT INTO calonsiswa VALUES ('15', '4', '5', '0', '115', 'SUBIANTORO', 'Lamongan', '19970101', 'L', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '79997973617', '79997973617', null, '323/2323/D/15', '20120601', '33', '323/2323/D/15', '20120601', 'SMPN 1 Kalitengah', 'Lamongan', 'Ahmad Tigani Lubis', 'PNS', '081497980550', 'Oktavia Hardianti', null, 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '5', 'OSIS', null, '1');
INSERT INTO calonsiswa VALUES ('16', '2', '1', '0', '116', 'SUCI RAHAYU', 'Gresik', '19960101', 'P', 'Islam', 'Mertani', 'Lamongan', 'Jawa Timur', '79497971307', '79497971307', null, '323/2323/D/16', '20120601', '32', '323/2323/D/16', '20120601', 'SMPN 1 Bungah', 'Lamongan', 'TONI MUJI PANGESTU', 'Tani', '80997978239', 'Puji Permatasari', 'Wirausaha', 'Mertani', 'Lamongan', null, null, null, null, '5', 'Juara Tk Kabupaten', null, '1');
INSERT INTO calonsiswa VALUES ('17', '4', '3', '0', '117', 'AHMAD FARID FIRDAUS', 'Gresik', '19970604', 'L', 'Islam', 'Ds. Mayong Kec Kalitengah', 'Lamongan', 'Jawa Timur', '78997968996', '78997968996', null, '323/2323/D/17', '20120601', '36.53', '323/2323/D/17', '20120601', 'SMPN 1 Kalitengah', 'Lamongan', 'TRIWAHYONO', 'PNS', '80497975928', 'Ratna Umalasari', null, 'Ds. Mayong Kec Kalitengah', 'Lamongan', null, null, null, null, '5', 'OSIS', null, '1');
INSERT INTO calonsiswa VALUES ('18', '4', '3', '0', '118', 'AHMAD SYAIFUDDIN ZUHRI', 'Lamongan', '19961221', 'L', 'Islam', 'Ds. Mayong Kec Kalitengah', 'Lamongan', 'Jawa Timur', '78497966685', '78497966685', null, '323/2323/D/18', '20120601', '36.53', '323/2323/D/18', '20120601', 'SMPN 1 Karanggeneg', 'Lamongan', 'Andi Ferianto', 'Tani', '79997973617', 'Dwi Ratna Gandasari', null, 'Ds. Mayong Kec Kalitengah', 'Lamongan', null, null, null, null, '5', 'Juara Tk Kabupaten', null, '1');
INSERT INTO calonsiswa VALUES ('19', '4', '5', '0', '119', 'ANI DWI JAYANTI', 'Lamongan', '19960101', 'P', 'Islam', 'Ds. Mayong Kec Kalitengah', 'Lamongan', 'Jawa Timur', '77997964374', '77997964374', null, '323/2323/D/19', '20120601', '35', '323/2323/D/19', '20120601', 'SMPN 1 Kalitengah', 'Lamongan', 'Andi hardianto', 'Tani', '79497971307', 'Dwi Supriliati', null, 'Ds. Mayong Kec Kalitengah', 'Lamongan', null, null, null, null, '5', 'Rangking Kelas', null, '1');
INSERT INTO calonsiswa VALUES ('20', '4', '5', '0', '120', 'ANISATUL CHISBIYAHA', 'Lamongan', '19970604', 'P', 'Islam', 'Ds. Mayong Kec Kalitengah', 'Lamongan', 'Jawa Timur', '77497962063', '77497962063', null, '323/2323/D/20', '20120601', '34', '323/2323/D/20', '20120601', 'SMPN 1 Karanggeneg', 'Lamongan', 'Andrian Febrianto', 'Tani', '78997968996', 'Dysma Rachmayanti', null, 'Ds. Mayong Kec Kalitengah', 'Lamongan', null, null, null, null, '5', 'Juara Tk Kabupaten', null, '1');
INSERT INTO calonsiswa VALUES ('21', '5', '2', '0', '121', 'A. MUSTOFA', 'Lamongan', '19960604', 'L', 'Islam', 'Ds. Mayong Kec Kalitengah', 'Lamongan', 'Jawa Timur', '85706333333', '85706333333', null, '323/2323/D/21', '20120501', '32', '323/2323/D/21', '20120501', 'SMPN 1 Kalitengah', 'Lamongan', 'LUKMAN HADI', 'Tani', '81331313113', 'NOPRI MURTASIAH', 'Tani', 'Ds. Mayong Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('22', '5', '2', '0', '122', 'ABDUL HADI MUSLICH', 'Lamongan', '19960101', 'L', 'Islam', 'Karanggeneng', 'Lamongan', 'Jawa Timur', '85706333333', '85706333333', null, '323/2323/D/22', '20120501', '33.75', '323/2323/D/22', '20120501', 'SMPN 1 Kalitengah', 'Lamongan', 'MAWI BAWAJI AHMAD NUR', 'Tani', '85706333333', 'NUR HAMIYAH', null, 'Karanggeneng', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('23', '2', '1', '0', '123', 'AFNAN MIGHFARUL MISHAD', 'Lamongan', '19970101', 'L', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '81331313113', '81331313113', null, '323/2323/D/23', '20120601', '38', '323/2323/D/23', '20120601', 'MTS Wachid Hasyim Sukodadi', 'Lamongan', 'Achmad Danang Ainurrozaq', 'PNS', '85706333333', 'OKTABELLA DWI HAKIKI', 'Wirausaha', 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('24', '1', '5', '0', '124', 'AKHMAD YUNIAR FIRMANZAH', 'Lamongan', '19960101', 'L', 'Islam', 'Mertani', 'Lamongan', 'Jawa Timur', '85706333333', '85706333333', null, '323/2323/D/24', '20120501', '37', '323/2323/D/24', '20120501', 'MTSN 1 BABAT ', 'Lamongan', 'Achmad Nizarwanto', 'Tani', '81331313113', 'PUTRI DIANTARI', null, 'Mertani', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('25', '1', '3', '0', '125', 'AMBAR IRMAWATI', 'Lamongan', '19970604', 'P', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '85706333333', '85706333333', null, '323/2323/D/25', '20120601', '33.75', '323/2323/D/25', '20120601', 'SMPN 1 Kalitengah', 'Lamongan', 'Achmad Zainuri', 'Tani', '82497985172', 'Satuning Tyas', null, 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('26', '1', '4', '0', '126', 'AYU LESTARI', 'Lamongan', '19961221', 'P', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '81331313113', '81331313113', null, '323/2323/D/26', '20120601', '34.5', '323/2323/D/26', '20120601', 'SMPN 1 Karanggeneg', 'Lamongan', 'Adi Setiawan', 'PNS', '81997982861', 'Septa Sri Andriani', null, 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '10', 'Juara 1 Tk Propinsi', null, '1');
INSERT INTO calonsiswa VALUES ('27', '5', '4', '0', '127', 'CESAR YUNI ARIYANTO', 'Lamongan', '19960604', 'L', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '85706333333', '85706333333', null, '323/2323/D/27', '20120601', '33.6', '323/2323/D/27', '20120601', 'MTS Wachid Hasyim Sukodadi', 'Lamongan', 'Adit Purwandoko', 'TNI', '81497980550', 'Septy Noviana Mulis', 'Wirausaha', 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '10', 'Juara 3 Tk Propinsi', null, '1');
INSERT INTO calonsiswa VALUES ('28', '3', '1', '0', '128', 'DEWI KARTINI', 'Lamongan', '19960101', 'P', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '85706333333', '85706333333', null, '323/2323/D/28', '20120601', '33', '323/2323/D/28', '20120601', 'MTSN 1 BABAT ', 'Lamongan', 'Agus Bastian', 'Tani', '80997978239', 'Siti Rukhana', 'Tani', 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, null, null, null, '1');
INSERT INTO calonsiswa VALUES ('29', '3', '5', '0', '129', 'EKO WAHYU KURNIAWAN', 'Lamongan', '19970101', 'L', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '81331313113', '81331313113', null, '323/2323/D/29', '20120601', '32', '323/2323/D/29', '20120601', 'SMPN 1 Kalitengah', 'Lamongan', 'Agus Suprapto', 'Tani', '81331313113', 'Siti Wahyu Tri Warni', 'Tani', 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('30', '3', '4', '0', '130', 'FIFIN NOVIYANTI', 'Lamongan', '19960101', 'P', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '82497985172', '82497985172', null, '323/2323/D/30', '20120601', '33.75', '323/2323/D/30', '20120601', 'MTS Wachid Hasyim Sukodadi', 'Lamongan', 'Ahmad Afrianto', 'Tani', '85706333333', 'Siti Zulaikha', 'Wirausaha', 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('31', '3', '4', '0', '131', 'FINAS WIRNIAWATI', 'Lamongan', '19970604', 'P', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '81997982861', '81997982861', null, '323/2323/D/31', '20120601', '37', '323/2323/D/31', '20120601', 'SMPN 1 Kalitengah', 'Lamongan', 'Ahmad Itsnaini P. Kh. N', 'PNS', '85706333333', 'Nur Azizah', null, 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('32', '3', '2', '0', '132', 'HAFIDHOTUL AFIFAH', 'Surabaya', '19961221', 'L', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '81497980550', '81497980550', null, '323/2323/D/32', '20120601', '36', '323/2323/D/32', '20120601', 'SMPN 1 Sukodadi', 'Lamongan', 'Ahmad Makhis Hamdani', 'Tani', '81331313113', 'Nur Hadi Darmawan', 'Wirausaha', 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('33', '3', '2', '0', '133', 'HENDRA SISWANTO', 'Mojokerto', '19960604', 'L', 'Islam', 'Ds. Mayong Kec Kalitengah', 'Lamongan', 'Jawa Timur', '80997978239', '80997978239', null, '323/2323/D/33', '20120601', '33', '323/2323/D/33', '20120601', 'MTSN 1 BABAT ', 'Lamongan', 'Ahmad Muzzamil', 'Tani', '82497985172', 'Nur Laili Hidayah', 'Wirausaha', 'Ds. Mayong Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('34', '4', '2', '0', '134', 'KARTIKA DWI SUPRIYANTI', 'Lamongan', '19960101', 'P', 'Islam', 'Karanggeneng', 'Lamongan', 'Jawa Timur', '80497975928', '80497975928', null, '323/2323/D/34', '20120601', '34', '323/2323/D/34', '20120601', 'SMPN 1 Karanggeneg', 'Lamongan', 'Ahmad Saifudin', 'Tani', '81997982861', 'Nur Sholihah', 'Tani', 'Karanggeneng', 'Lamongan', null, null, null, null, '5', 'Juara Tk Kabupaten', null, '1');
INSERT INTO calonsiswa VALUES ('35', '4', '2', '0', '135', 'LISA VILAYATI', 'Lamongan', '19970101', 'P', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '79997973617', '79997973617', null, '323/2323/D/35', '20120601', '33.75', '323/2323/D/35', '20120601', 'MTSN 1 BABAT ', 'Lamongan', 'Ahmad Tigani Lubis', 'PNS', '81497980550', 'Oktavia Hardianti', null, 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '5', 'OSIS', null, '1');
INSERT INTO calonsiswa VALUES ('36', '4', '2', '0', '136', 'M. HENDRIK PRASETYAWAN', 'Gresik', '19960101', 'L', 'Islam', 'Mertani', 'Lamongan', 'Jawa Timur', '79497971307', '79497971307', null, '323/2323/D/36', '20120601', '32', '323/2323/D/36', '20120601', 'SMPN 1 Bungah', 'Lamongan', 'TONI MUJI PANGESTU', 'Tani', '80997978239', 'Puji Permatasari', 'Wirausaha', 'Mertani', 'Lamongan', null, null, null, null, '5', 'Juara Tk Kabupaten', null, '1');
INSERT INTO calonsiswa VALUES ('37', '4', '2', '0', '137', 'M. SYIFA\'UDIN', 'Gresik', '19970604', 'L', 'Islam', 'Ds. Mayong Kec Kalitengah', 'Lamongan', 'Jawa Timur', '78997968996', '78997968996', null, '323/2323/D/37', '20120601', '36.53', '323/2323/D/37', '20120601', 'SMPN 1 Kalitengah', 'Lamongan', 'TRIWAHYONO', 'PNS', '80497975928', 'Ratna Umalasari', null, 'Ds. Mayong Kec Kalitengah', 'Lamongan', null, null, null, null, '5', 'OSIS', null, '1');
INSERT INTO calonsiswa VALUES ('38', '4', '2', '0', '138', 'MASITA DIAN LESTARI', 'Lamongan', '19961221', 'P', 'Islam', 'Ds. Mayong Kec Kalitengah', 'Lamongan', 'Jawa Timur', '78497966685', '78497966685', null, '323/2323/D/38', '20120601', '34.53', '323/2323/D/38', '20120601', 'SMPN 1 Karanggeneg', 'Lamongan', 'Andi Ferianto', 'Tani', '79997973617', 'Dwi Ratna Gandasari', null, 'Ds. Mayong Kec Kalitengah', 'Lamongan', null, null, null, null, '5', 'Juara Tk Kabupaten', null, '1');
INSERT INTO calonsiswa VALUES ('39', '4', '5', '0', '139', 'MEIATUS SHOLIHAH', 'Lamongan', '19960101', 'P', 'Islam', 'Ds. Mayong Kec Kalitengah', 'Lamongan', 'Jawa Timur', '77997964374', '77997964374', null, '323/2323/D/39', '20120601', '35', '323/2323/D/39', '20120601', 'SMPN 1 Kalitengah', 'Lamongan', 'Andi hardianto', 'Tani', '79497971307', 'Dwi Supriliati', null, 'Ds. Mayong Kec Kalitengah', 'Lamongan', null, null, null, null, '5', 'Rangking Kelas', null, '1');
INSERT INTO calonsiswa VALUES ('40', '4', '5', '0', '140', 'MOH. HARIANTO', 'Lamongan', '19970604', 'L', 'Islam', 'Ds. Mayong Kec Kalitengah', 'Lamongan', 'Jawa Timur', '77497962063', '77497962063', null, '323/2323/D/40', '20120601', '34', '323/2323/D/40', '20120601', 'SMPN 1 Karanggeneg', 'Lamongan', 'Andrian Febrianto', 'Tani', '78997968996', 'Dysma Rachmayanti', null, 'Ds. Mayong Kec Kalitengah', 'Lamongan', null, null, null, null, '5', 'Juara Tk Kabupaten', null, '1');
INSERT INTO calonsiswa VALUES ('41', '2', '1', '0', '141', 'MOHAMAD SHALEH FUDIN', 'Lamongan', '19960101', 'L', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '85706333333', '85706333333', null, '323/2323/D/41', '20120601', '33.75', '323/2323/D/41', '20120601', 'MTSN 1 BABAT ', 'Lamongan', 'MAWI BAWAJI AHMAD NUR', 'Tani', '78497966685', 'PUTRI DIANTARI', null, 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '10', null, null, '1');
INSERT INTO calonsiswa VALUES ('42', '2', '1', '0', '142', 'MOHAMMAD KHARIS NURHUDA', 'Lamongan', '19970604', 'L', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '85706333333', '85706333333', null, '323/2323/D/42', '20120601', '32', '323/2323/D/42', '20120601', 'MTS Wachid Hasyim Sukodadi', 'Lamongan', 'Achmad Danang Ainurrozaq', 'Tani', '77997964374', 'Satuning Tyas', null, 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '10', null, null, '1');
INSERT INTO calonsiswa VALUES ('43', '2', '1', '0', '143', 'MUHAMMAD FAJAR SIDIK ASYAHADAT', 'Surabaya', '19961221', 'L', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '81331313113', '81331313113', null, '323/2323/D/43', '20120601', '36.53', '323/2323/D/43', '20120601', 'MTS Wachid Hasyim Sukodadi', 'Lamongan', 'Achmad Nizarwanto', 'PNS', '77497962063', 'Septa Sri Andriani', null, 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('44', '2', '1', '0', '144', 'NAFI\' BAGUS WARDIYANTO', 'Mojokerto', '19960604', 'L', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '85706333333', '85706333333', null, '323/2323/D/44', '20120601', '34.53', '323/2323/D/44', '20120601', 'MTSN 1 BABAT ', 'Lamongan', 'Achmad Zainuri', 'Tani', '76997959752', 'Septy Noviana Mulis', null, 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('45', '4', '1', '0', '145', 'NUR HIDAYAT', 'Lamongan', '19960101', 'L', 'Islam', 'Ds. Mayong Kec Kalitengah', 'Lamongan', 'Jawa Timur', '85706333333', '85706333333', null, '323/2323/D/45', '20120601', '35', '323/2323/D/45', '20120601', 'MTS Wachid Hasyim Sukodadi', 'Lamongan', 'Adi Setiawan', 'Tani', '76497957441', 'Siti Rukhana', null, 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, null, null, null, '1');
INSERT INTO calonsiswa VALUES ('46', '4', '1', '0', '146', 'NURHAYATI IKA PRASASTI', 'Surabaya', '19970101', 'P', 'Islam', 'Karanggeneng', 'Lamongan', 'Jawa Timur', '81331313113', '81331313113', null, '323/2323/D/46', '20120601', '34', '323/2323/D/46', '20120601', 'MTSN 1 BABAT ', 'Lamongan', 'Adit Purwandoko', 'Tani', '75997955131', 'Siti Wahyu Tri Warni', null, 'Ds. Mayong Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('47', '1', '4', '0', '147', 'NURWAHYUDIN INDRA KUSUMA', 'Mojokerto', '19960101', 'L', 'Islam', 'Ds Dibee Kec Kalitengah', 'Lamongan', 'Jawa Timur', '85706333333', '85706333333', null, '323/2323/D/47', '20120601', '34.5', '323/2323/D/47', '20120601', 'SMPN 1 Kalitengah', 'Lamongan', 'Agus Bastian', 'PNS', '75497952820', 'Siti Zulaikha', null, 'Karanggeneng', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('48', '2', '3', '0', '148', 'ONKY ALEXANDER KHOLILULLAH', 'Lamongan', '19970604', 'L', 'Islam', 'Mertani', 'Lamongan', 'Jawa Timur', '85706333333', '85706333333', null, '323/2323/D/48', '20120601', '33.6', '323/2323/D/48', '20120601', 'SMPN 1 Karanggeneg', 'Lamongan', 'Agus Suprapto', 'Tani', '74997950509', 'NOPRI MURTASIAH', null, 'Ds Dibee Kec Kalitengah', 'Lamongan', null, null, null, null, '0', null, null, '1');
INSERT INTO calonsiswa VALUES ('49', '3', '5', '0', '149', 'RIZAL AINUL ROHMAN', 'Lamongan', '19961221', 'L', 'Islam', 'Ds. Mayong Kec Kalitengah', 'Lamongan', 'Jawa Timur', '81331313113', '81331313113', null, '323/2323/D/49', '20120601', '33', '323/2323/D/49', '20120601', 'MTS Wachid Hasyim Sukodadi', 'Lamongan', 'Ahmad Afrianto', 'PNS', '74497948198', 'NUR HAMIYAH', null, 'Mertani', 'Lamongan', null, null, null, null, '5', null, null, '1');
INSERT INTO calonsiswa VALUES ('50', '4', '1', '0', '150', 'RIZKI DAMAYANTI', 'Gresik', '19970604', 'P', 'Islam', 'Mertani', 'Lamongan', 'Jawa Timur', '82497985172', '82497985172', null, '323/2323/D/50', '20120601', '33.75', '323/2323/D/50', '20120601', 'MTSN 1 BABAT ', 'Lamongan', 'Ahmad Itsnaini P. Kh. N', 'PNS', '73997945887', 'OKTABELLA DWI HAKIKI', null, 'Ds. Mayong Kec Kalitengah', 'Lamongan', null, null, null, null, '5', null, null, '1');
INSERT INTO calonsiswa VALUES ('68', '4', '2', '0', '1212', 'anas', '', '19960101', 'L', 'Islam', '', 'Lamongan', 'Jawa Timur', '', '', '', '121212', '20120501', '20.00', '', '20120501', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', null);
INSERT INTO calonsiswa VALUES ('66', '4', '5', '0', '1111111', 'xxxx', null, '19960101', 'L', 'Islam', null, 'Lamongan', 'Jawa Timur', null, null, null, '1111111', '20120501', '20.00', null, '20120501', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO calonsiswa VALUES ('67', '5', '1', '0', '999', 'agus', 'LAMONGAN', '19960101', 'L', 'Islam', '', 'Lamongan', 'Jawa Timur', '', '', '', '90788667', '20120501', '30.00', '', '20120501', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', null);

-- ----------------------------
-- Table structure for `jurusan`
-- ----------------------------
DROP TABLE IF EXISTS `jurusan`;
CREATE TABLE `jurusan` (
  `IDJUR` tinyint(4) NOT NULL AUTO_INCREMENT,
  `NAMAJURUSAN` varchar(50) DEFAULT NULL,
  `JUMLAHMAKS` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDJUR`),
  UNIQUE KEY `JURUSANPILIHAN1_PK` (`IDJUR`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of jurusan
-- ----------------------------
INSERT INTO jurusan VALUES ('4', 'MULTIMEDIA', '10');
INSERT INTO jurusan VALUES ('3', 'TEKNIK KOMPUTER JARINGAN', '10');
INSERT INTO jurusan VALUES ('2', 'PERBANKAN', '10');
INSERT INTO jurusan VALUES ('1', 'TATA BUSANA', '10');
INSERT INTO jurusan VALUES ('5', 'TEKNIK KENDARAAN RINGAN', '10');

-- ----------------------------
-- Table structure for `nilai`
-- ----------------------------
DROP TABLE IF EXISTS `nilai`;
CREATE TABLE `nilai` (
  `IDNILAI` bigint(4) NOT NULL AUTO_INCREMENT,
  `IDPENDAFTARAN` int(11) DEFAULT NULL,
  `IDUJIAN` tinyint(4) DEFAULT NULL,
  `NILAIUJIAN` tinyint(4) DEFAULT NULL,
  `IDJUR` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`IDNILAI`)
) ENGINE=MyISAM AUTO_INCREMENT=184 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of nilai
-- ----------------------------
INSERT INTO nilai VALUES ('97', '1', '14', '10', '0');
INSERT INTO nilai VALUES ('98', '3', '14', '10', '0');
INSERT INTO nilai VALUES ('99', '14', '14', '10', '0');
INSERT INTO nilai VALUES ('100', '15', '14', '0', '0');
INSERT INTO nilai VALUES ('101', '17', '14', '0', '0');
INSERT INTO nilai VALUES ('102', '18', '14', '0', '0');
INSERT INTO nilai VALUES ('103', '19', '14', '0', '0');
INSERT INTO nilai VALUES ('104', '20', '14', '10', '0');
INSERT INTO nilai VALUES ('105', '1', '9', '60', '0');
INSERT INTO nilai VALUES ('106', '3', '9', '80', '0');
INSERT INTO nilai VALUES ('107', '14', '9', '80', '0');
INSERT INTO nilai VALUES ('108', '15', '9', '70', '0');
INSERT INTO nilai VALUES ('109', '17', '9', '80', '0');
INSERT INTO nilai VALUES ('110', '18', '9', '80', '0');
INSERT INTO nilai VALUES ('111', '19', '9', '80', '0');
INSERT INTO nilai VALUES ('112', '20', '9', '80', '0');
INSERT INTO nilai VALUES ('113', '2', '25', '90', '0');
INSERT INTO nilai VALUES ('114', '4', '25', '90', '0');
INSERT INTO nilai VALUES ('115', '5', '25', '0', '0');
INSERT INTO nilai VALUES ('116', '6', '25', '0', '0');
INSERT INTO nilai VALUES ('117', '7', '25', '0', '0');
INSERT INTO nilai VALUES ('118', '2', '26', '0', '0');
INSERT INTO nilai VALUES ('119', '4', '26', '0', '0');
INSERT INTO nilai VALUES ('120', '5', '26', '100', '0');
INSERT INTO nilai VALUES ('121', '6', '26', '0', '0');
INSERT INTO nilai VALUES ('122', '7', '26', '0', '0');
INSERT INTO nilai VALUES ('123', '1', '4', '100', '0');
INSERT INTO nilai VALUES ('124', '3', '4', '100', '0');
INSERT INTO nilai VALUES ('125', '14', '4', '80', '0');
INSERT INTO nilai VALUES ('126', '15', '4', '86', '0');
INSERT INTO nilai VALUES ('127', '17', '4', '85', '0');
INSERT INTO nilai VALUES ('128', '18', '4', '80', '0');
INSERT INTO nilai VALUES ('129', '19', '4', '77', '0');
INSERT INTO nilai VALUES ('130', '20', '4', '75', '0');
INSERT INTO nilai VALUES ('131', '16', '7', '100', '0');
INSERT INTO nilai VALUES ('132', '16', '2', '100', '0');
INSERT INTO nilai VALUES ('133', '2', '6', '90', '0');
INSERT INTO nilai VALUES ('134', '4', '6', '88', '0');
INSERT INTO nilai VALUES ('135', '5', '6', '90', '0');
INSERT INTO nilai VALUES ('136', '6', '6', '70', '0');
INSERT INTO nilai VALUES ('137', '7', '6', '0', '0');
INSERT INTO nilai VALUES ('138', '24', '6', '0', '0');
INSERT INTO nilai VALUES ('139', '25', '6', '0', '0');
INSERT INTO nilai VALUES ('140', '26', '6', '0', '0');
INSERT INTO nilai VALUES ('141', '47', '6', '0', '0');
INSERT INTO nilai VALUES ('142', '34', '14', '0', '0');
INSERT INTO nilai VALUES ('143', '35', '14', '0', '0');
INSERT INTO nilai VALUES ('144', '36', '14', '0', '0');
INSERT INTO nilai VALUES ('145', '37', '14', '0', '0');
INSERT INTO nilai VALUES ('146', '38', '14', '0', '0');
INSERT INTO nilai VALUES ('147', '39', '14', '0', '0');
INSERT INTO nilai VALUES ('148', '40', '14', '0', '0');
INSERT INTO nilai VALUES ('149', '45', '14', '0', '0');
INSERT INTO nilai VALUES ('150', '46', '14', '0', '0');
INSERT INTO nilai VALUES ('151', '50', '14', '0', '0');
INSERT INTO nilai VALUES ('152', '8', '13', '10', '0');
INSERT INTO nilai VALUES ('153', '9', '13', '10', '0');
INSERT INTO nilai VALUES ('154', '10', '13', '10', '0');
INSERT INTO nilai VALUES ('155', '11', '13', '0', '0');
INSERT INTO nilai VALUES ('156', '12', '13', '0', '0');
INSERT INTO nilai VALUES ('157', '13', '13', '0', '0');
INSERT INTO nilai VALUES ('158', '28', '13', '0', '0');
INSERT INTO nilai VALUES ('159', '29', '13', '0', '0');
INSERT INTO nilai VALUES ('160', '30', '13', '0', '0');
INSERT INTO nilai VALUES ('161', '31', '13', '0', '0');
INSERT INTO nilai VALUES ('162', '32', '13', '0', '0');
INSERT INTO nilai VALUES ('163', '33', '13', '0', '0');
INSERT INTO nilai VALUES ('164', '49', '13', '0', '0');
INSERT INTO nilai VALUES ('165', '34', '4', '60', '0');
INSERT INTO nilai VALUES ('166', '35', '4', '50', '0');
INSERT INTO nilai VALUES ('167', '36', '4', '50', '0');
INSERT INTO nilai VALUES ('168', '37', '4', '50', '0');
INSERT INTO nilai VALUES ('169', '38', '4', '50', '0');
INSERT INTO nilai VALUES ('170', '39', '4', '60', '0');
INSERT INTO nilai VALUES ('171', '40', '4', '90', '0');
INSERT INTO nilai VALUES ('172', '45', '4', '60', '0');
INSERT INTO nilai VALUES ('173', '46', '4', '60', '0');
INSERT INTO nilai VALUES ('174', '50', '4', '60', '0');
INSERT INTO nilai VALUES ('175', '2', '45', '10', '0');
INSERT INTO nilai VALUES ('176', '4', '45', '0', '0');
INSERT INTO nilai VALUES ('177', '5', '45', '0', '0');
INSERT INTO nilai VALUES ('178', '6', '45', '0', '0');
INSERT INTO nilai VALUES ('179', '7', '45', '10', '0');
INSERT INTO nilai VALUES ('180', '24', '45', '0', '0');
INSERT INTO nilai VALUES ('181', '25', '45', '0', '0');
INSERT INTO nilai VALUES ('182', '26', '45', '0', '0');
INSERT INTO nilai VALUES ('183', '47', '45', '0', '0');

-- ----------------------------
-- Table structure for `nilaiakhir`
-- ----------------------------
DROP TABLE IF EXISTS `nilaiakhir`;
CREATE TABLE `nilaiakhir` (
  `IDPENDAFTARAN` int(11) NOT NULL DEFAULT '0',
  `NUN` decimal(11,4) DEFAULT NULL,
  `US` decimal(11,4) DEFAULT NULL,
  `NA` decimal(11,4) DEFAULT NULL,
  PRIMARY KEY (`IDPENDAFTARAN`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of nilaiakhir
-- ----------------------------
INSERT INTO nilaiakhir VALUES ('1', '36.5300', '60.0000', '96.5300');
INSERT INTO nilaiakhir VALUES ('3', '38.0000', '60.0000', '98.0000');
INSERT INTO nilaiakhir VALUES ('14', '34.0000', '50.0000', '84.0000');
INSERT INTO nilaiakhir VALUES ('15', '33.0000', '43.0000', '76.0000');
INSERT INTO nilaiakhir VALUES ('17', '36.5300', '42.5000', '79.0300');
INSERT INTO nilaiakhir VALUES ('18', '36.5300', '40.0000', '76.5300');
INSERT INTO nilaiakhir VALUES ('19', '35.0000', '38.5000', '73.5000');
INSERT INTO nilaiakhir VALUES ('20', '34.0000', '47.5000', '81.5000');
INSERT INTO nilaiakhir VALUES ('34', '34.0000', '30.0000', '64.0000');
INSERT INTO nilaiakhir VALUES ('35', '33.7500', '25.0000', '58.7500');
INSERT INTO nilaiakhir VALUES ('36', '32.0000', '25.0000', '57.0000');
INSERT INTO nilaiakhir VALUES ('37', '36.5300', '25.0000', '61.5300');
INSERT INTO nilaiakhir VALUES ('38', '34.5300', '25.0000', '59.5300');
INSERT INTO nilaiakhir VALUES ('39', '35.0000', '30.0000', '65.0000');
INSERT INTO nilaiakhir VALUES ('40', '34.0000', '45.0000', '79.0000');
INSERT INTO nilaiakhir VALUES ('45', '35.0000', '30.0000', '65.0000');
INSERT INTO nilaiakhir VALUES ('46', '34.0000', '30.0000', '64.0000');
INSERT INTO nilaiakhir VALUES ('50', '33.7500', '30.0000', '63.7500');
INSERT INTO nilaiakhir VALUES ('68', '20.0000', '0.0000', '20.0000');
INSERT INTO nilaiakhir VALUES ('66', '20.0000', '0.0000', '20.0000');
INSERT INTO nilaiakhir VALUES ('8', '33.0000', '10.0000', '43.0000');
INSERT INTO nilaiakhir VALUES ('9', '32.0000', '10.0000', '42.0000');
INSERT INTO nilaiakhir VALUES ('10', '38.0000', '10.0000', '48.0000');
INSERT INTO nilaiakhir VALUES ('11', '37.0000', '0.0000', '37.0000');
INSERT INTO nilaiakhir VALUES ('12', '36.0000', '0.0000', '36.0000');
INSERT INTO nilaiakhir VALUES ('13', '35.0000', '0.0000', '35.0000');
INSERT INTO nilaiakhir VALUES ('28', '33.0000', '0.0000', '33.0000');
INSERT INTO nilaiakhir VALUES ('29', '32.0000', '0.0000', '32.0000');
INSERT INTO nilaiakhir VALUES ('30', '33.7500', '0.0000', '33.7500');
INSERT INTO nilaiakhir VALUES ('31', '37.0000', '0.0000', '37.0000');
INSERT INTO nilaiakhir VALUES ('32', '36.0000', '0.0000', '36.0000');
INSERT INTO nilaiakhir VALUES ('33', '33.0000', '0.0000', '33.0000');
INSERT INTO nilaiakhir VALUES ('49', '33.0000', '0.0000', '33.0000');
INSERT INTO nilaiakhir VALUES ('16', '32.0000', '50.0000', '82.0000');
INSERT INTO nilaiakhir VALUES ('23', '38.0000', '0.0000', '38.0000');
INSERT INTO nilaiakhir VALUES ('41', '33.7500', '0.0000', '33.7500');
INSERT INTO nilaiakhir VALUES ('42', '32.0000', '0.0000', '32.0000');
INSERT INTO nilaiakhir VALUES ('43', '36.5300', '0.0000', '36.5300');
INSERT INTO nilaiakhir VALUES ('44', '34.5300', '0.0000', '34.5300');
INSERT INTO nilaiakhir VALUES ('48', '33.6000', '0.0000', '33.6000');
INSERT INTO nilaiakhir VALUES ('2', '36.5300', '32.5000', '69.0300');
INSERT INTO nilaiakhir VALUES ('4', '37.0000', '22.0000', '59.0000');
INSERT INTO nilaiakhir VALUES ('5', '36.0000', '22.5000', '58.5000');
INSERT INTO nilaiakhir VALUES ('6', '35.0000', '17.5000', '52.5000');
INSERT INTO nilaiakhir VALUES ('7', '34.0000', '10.0000', '44.0000');
INSERT INTO nilaiakhir VALUES ('24', '37.0000', '0.0000', '37.0000');
INSERT INTO nilaiakhir VALUES ('25', '33.7500', '0.0000', '33.7500');
INSERT INTO nilaiakhir VALUES ('26', '34.5000', '0.0000', '34.5000');
INSERT INTO nilaiakhir VALUES ('47', '34.5000', '0.0000', '34.5000');
INSERT INTO nilaiakhir VALUES ('21', '32.0000', '0.0000', '32.0000');
INSERT INTO nilaiakhir VALUES ('22', '33.7500', '0.0000', '33.7500');
INSERT INTO nilaiakhir VALUES ('27', '33.6000', '0.0000', '33.6000');
INSERT INTO nilaiakhir VALUES ('67', '30.0000', '0.0000', '30.0000');

-- ----------------------------
-- Table structure for `petugas`
-- ----------------------------
DROP TABLE IF EXISTS `petugas`;
CREATE TABLE `petugas` (
  `IDPETUGAS` tinyint(4) NOT NULL AUTO_INCREMENT,
  `NAMAPETUGAS` varchar(50) DEFAULT NULL,
  `USERNAMEPETUGAS` varchar(20) NOT NULL DEFAULT '',
  `PASSWORDPETUGAS` varchar(50) DEFAULT NULL,
  `LEVEL` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`IDPETUGAS`,`USERNAMEPETUGAS`),
  UNIQUE KEY `PETUGAS_PK` (`IDPETUGAS`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of petugas
-- ----------------------------
INSERT INTO petugas VALUES ('1', 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'ADMIN');
INSERT INTO petugas VALUES ('3', 'petugas', 'petugas', 'afb91ef692fd08c445e8cb1bab2ccf9c', 'PETUGAS');
INSERT INTO petugas VALUES ('2', 'panitia', 'panitia', 'd32b1673837a6a45f795c13ea67ec79e', 'PANITIA');

-- ----------------------------
-- Table structure for `propinsi`
-- ----------------------------
DROP TABLE IF EXISTS `propinsi`;
CREATE TABLE `propinsi` (
  `IdPropinsi` tinyint(2) NOT NULL,
  `NamaPropinsi` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`IdPropinsi`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of propinsi
-- ----------------------------
INSERT INTO propinsi VALUES ('0', 'Pusat');
INSERT INTO propinsi VALUES ('1', 'DKI Jakarta');
INSERT INTO propinsi VALUES ('2', 'Jawa Barat');
INSERT INTO propinsi VALUES ('3', 'Jawa Tengah');
INSERT INTO propinsi VALUES ('4', 'DI Yogyakarta');
INSERT INTO propinsi VALUES ('5', 'Jawa Timur');
INSERT INTO propinsi VALUES ('6', 'Nanggroe Aceh Darussalam');
INSERT INTO propinsi VALUES ('7', 'Sumatera Utara');
INSERT INTO propinsi VALUES ('8', 'Sumatera Barat');
INSERT INTO propinsi VALUES ('9', 'Riau');
INSERT INTO propinsi VALUES ('10', 'Jambi');
INSERT INTO propinsi VALUES ('11', 'Sumatera Selatan');
INSERT INTO propinsi VALUES ('12', 'Lampung');
INSERT INTO propinsi VALUES ('13', 'Kalimantan Barat');
INSERT INTO propinsi VALUES ('14', 'Kalimantan Tengah');
INSERT INTO propinsi VALUES ('15', 'Kalimantan Selatan');
INSERT INTO propinsi VALUES ('16', 'Kalimantan Timur');
INSERT INTO propinsi VALUES ('17', 'Sulawesi Utara');
INSERT INTO propinsi VALUES ('18', 'Sulawesi Tengah');
INSERT INTO propinsi VALUES ('19', 'Sulawesi Selatan');
INSERT INTO propinsi VALUES ('20', 'Sulawesi Tenggara');
INSERT INTO propinsi VALUES ('21', 'Maluku');
INSERT INTO propinsi VALUES ('22', 'Bali');
INSERT INTO propinsi VALUES ('23', 'Nusa Tenggara Barat');
INSERT INTO propinsi VALUES ('24', 'Nusa Tenggara Timur');
INSERT INTO propinsi VALUES ('25', 'Papua');
INSERT INTO propinsi VALUES ('26', 'Bengkulu');
INSERT INTO propinsi VALUES ('28', 'Maluku Utara');
INSERT INTO propinsi VALUES ('29', 'Banten');
INSERT INTO propinsi VALUES ('30', 'Bangka Belitung');
INSERT INTO propinsi VALUES ('31', 'Gorontalo');
INSERT INTO propinsi VALUES ('32', 'Kepulauan Riau');
INSERT INTO propinsi VALUES ('33', 'Irian Jaya Barat');
INSERT INTO propinsi VALUES ('34', 'Sulawesi Barat');

-- ----------------------------
-- Table structure for `rangking`
-- ----------------------------
DROP TABLE IF EXISTS `rangking`;
CREATE TABLE `rangking` (
  `PERINGKAT` int(11) DEFAULT NULL,
  `IDPENDAFTARAN` int(11) DEFAULT NULL,
  `IDJUR` int(11) DEFAULT NULL,
  `NAMAJURUSAN` varchar(50) DEFAULT NULL,
  `NA` decimal(10,0) DEFAULT NULL,
  `KUOTA` int(11) DEFAULT NULL,
  `PIL1` tinyint(4) DEFAULT NULL,
  `PIL2` tinyint(4) DEFAULT NULL,
  `MASUKJUR` tinyint(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of rangking
-- ----------------------------
INSERT INTO rangking VALUES ('1', '2', '1', 'TATA BUSANA', '69', '10', '1', '2', '1');
INSERT INTO rangking VALUES ('2', '4', '1', 'TATA BUSANA', '59', '10', '1', '4', '1');
INSERT INTO rangking VALUES ('3', '5', '1', 'TATA BUSANA', '59', '10', '1', '5', '1');
INSERT INTO rangking VALUES ('4', '6', '1', 'TATA BUSANA', '53', '10', '1', '2', '1');
INSERT INTO rangking VALUES ('5', '7', '1', 'TATA BUSANA', '44', '10', '1', '4', '1');
INSERT INTO rangking VALUES ('6', '24', '1', 'TATA BUSANA', '37', '10', '1', '5', '1');
INSERT INTO rangking VALUES ('7', '47', '1', 'TATA BUSANA', '35', '10', '1', '4', '1');
INSERT INTO rangking VALUES ('8', '26', '1', 'TATA BUSANA', '35', '10', '1', '4', '1');
INSERT INTO rangking VALUES ('9', '25', '1', 'TATA BUSANA', '34', '10', '1', '3', '1');
INSERT INTO rangking VALUES ('13', '45', '1', 'MULTIMEDIA', '65', '10', '4', '1', '3');
INSERT INTO rangking VALUES ('14', '46', '1', 'MULTIMEDIA', '64', '10', '4', '1', '3');
INSERT INTO rangking VALUES ('15', '50', '1', 'MULTIMEDIA', '64', '10', '4', '1', '3');
INSERT INTO rangking VALUES ('20', '28', '1', 'TEKNIK KOMPUTER JARINGAN', '33', '10', '3', '1', '3');
INSERT INTO rangking VALUES ('1', '16', '2', 'PERBANKAN', '82', '10', '2', '1', '1');
INSERT INTO rangking VALUES ('2', '23', '2', 'PERBANKAN', '38', '10', '2', '1', '1');
INSERT INTO rangking VALUES ('3', '43', '2', 'PERBANKAN', '37', '10', '2', '1', '1');
INSERT INTO rangking VALUES ('4', '44', '2', 'PERBANKAN', '35', '10', '2', '1', '1');
INSERT INTO rangking VALUES ('5', '41', '2', 'PERBANKAN', '34', '10', '2', '1', '1');
INSERT INTO rangking VALUES ('6', '48', '2', 'PERBANKAN', '34', '10', '2', '3', '1');
INSERT INTO rangking VALUES ('7', '42', '2', 'PERBANKAN', '32', '10', '2', '1', '1');
INSERT INTO rangking VALUES ('9', '34', '2', 'MULTIMEDIA', '64', '10', '4', '2', '2');
INSERT INTO rangking VALUES ('10', '37', '2', 'MULTIMEDIA', '62', '10', '4', '2', '2');
INSERT INTO rangking VALUES ('11', '38', '2', 'MULTIMEDIA', '60', '10', '4', '2', '3');
INSERT INTO rangking VALUES ('12', '35', '2', 'MULTIMEDIA', '59', '10', '4', '2', '3');
INSERT INTO rangking VALUES ('13', '36', '2', 'MULTIMEDIA', '57', '10', '4', '2', '3');
INSERT INTO rangking VALUES ('20', '68', '2', 'MULTIMEDIA', '20', '10', '4', '2', '3');
INSERT INTO rangking VALUES ('1', '10', '3', 'TEKNIK KOMPUTER JARINGAN', '48', '10', '3', '4', '1');
INSERT INTO rangking VALUES ('2', '8', '3', 'TEKNIK KOMPUTER JARINGAN', '43', '10', '3', '4', '1');
INSERT INTO rangking VALUES ('3', '9', '3', 'TEKNIK KOMPUTER JARINGAN', '42', '10', '3', '5', '1');
INSERT INTO rangking VALUES ('4', '11', '3', 'TEKNIK KOMPUTER JARINGAN', '37', '10', '3', '4', '1');
INSERT INTO rangking VALUES ('5', '31', '3', 'TEKNIK KOMPUTER JARINGAN', '37', '10', '3', '4', '1');
INSERT INTO rangking VALUES ('6', '32', '3', 'TEKNIK KOMPUTER JARINGAN', '36', '10', '3', '2', '1');
INSERT INTO rangking VALUES ('7', '12', '3', 'TEKNIK KOMPUTER JARINGAN', '36', '10', '3', '2', '1');
INSERT INTO rangking VALUES ('8', '13', '3', 'TEKNIK KOMPUTER JARINGAN', '35', '10', '3', '5', '1');
INSERT INTO rangking VALUES ('9', '30', '3', 'TEKNIK KOMPUTER JARINGAN', '34', '10', '3', '4', '1');
INSERT INTO rangking VALUES ('10', '33', '3', 'TEKNIK KOMPUTER JARINGAN', '33', '10', '3', '2', '1');
INSERT INTO rangking VALUES ('11', '28', '3', 'TEKNIK KOMPUTER JARINGAN', '33', '10', '3', '1', '3');
INSERT INTO rangking VALUES ('12', '49', '3', 'TEKNIK KOMPUTER JARINGAN', '33', '10', '3', '5', '3');
INSERT INTO rangking VALUES ('13', '29', '3', 'TEKNIK KOMPUTER JARINGAN', '32', '10', '3', '5', '3');
INSERT INTO rangking VALUES ('1', '3', '4', 'MULTIMEDIA', '98', '10', '4', '3', '1');
INSERT INTO rangking VALUES ('2', '1', '4', 'MULTIMEDIA', '97', '10', '4', '1', '1');
INSERT INTO rangking VALUES ('3', '14', '4', 'MULTIMEDIA', '84', '10', '4', '1', '1');
INSERT INTO rangking VALUES ('4', '20', '4', 'MULTIMEDIA', '82', '10', '4', '5', '1');
INSERT INTO rangking VALUES ('5', '17', '4', 'MULTIMEDIA', '79', '10', '4', '3', '1');
INSERT INTO rangking VALUES ('6', '40', '4', 'MULTIMEDIA', '79', '10', '4', '5', '1');
INSERT INTO rangking VALUES ('7', '18', '4', 'MULTIMEDIA', '77', '10', '4', '3', '1');
INSERT INTO rangking VALUES ('8', '15', '4', 'MULTIMEDIA', '76', '10', '4', '5', '1');
INSERT INTO rangking VALUES ('9', '19', '4', 'MULTIMEDIA', '74', '10', '4', '5', '1');
INSERT INTO rangking VALUES ('10', '39', '4', 'MULTIMEDIA', '65', '10', '4', '5', '1');
INSERT INTO rangking VALUES ('11', '45', '4', 'MULTIMEDIA', '65', '10', '4', '1', '3');
INSERT INTO rangking VALUES ('12', '46', '4', 'MULTIMEDIA', '64', '10', '4', '1', '3');
INSERT INTO rangking VALUES ('13', '34', '4', 'MULTIMEDIA', '64', '10', '4', '2', '3');
INSERT INTO rangking VALUES ('14', '50', '4', 'MULTIMEDIA', '64', '10', '4', '1', '3');
INSERT INTO rangking VALUES ('15', '37', '4', 'MULTIMEDIA', '62', '10', '4', '2', '3');
INSERT INTO rangking VALUES ('16', '38', '4', 'MULTIMEDIA', '60', '10', '4', '2', '3');
INSERT INTO rangking VALUES ('17', '35', '4', 'MULTIMEDIA', '59', '10', '4', '2', '3');
INSERT INTO rangking VALUES ('18', '36', '4', 'MULTIMEDIA', '57', '10', '4', '2', '3');
INSERT INTO rangking VALUES ('19', '68', '4', 'MULTIMEDIA', '20', '10', '4', '2', '3');
INSERT INTO rangking VALUES ('20', '66', '4', 'MULTIMEDIA', '20', '10', '4', '5', '3');
INSERT INTO rangking VALUES ('1', '22', '5', 'TEKNIK KENDARAAN RINGAN', '34', '10', '5', '2', '1');
INSERT INTO rangking VALUES ('2', '27', '5', 'TEKNIK KENDARAAN RINGAN', '34', '10', '5', '4', '1');
INSERT INTO rangking VALUES ('3', '21', '5', 'TEKNIK KENDARAAN RINGAN', '32', '10', '5', '2', '1');
INSERT INTO rangking VALUES ('4', '67', '5', 'TEKNIK KENDARAAN RINGAN', '30', '10', '5', '1', '1');
INSERT INTO rangking VALUES ('14', '49', '5', 'TEKNIK KOMPUTER JARINGAN', '33', '10', '3', '5', '3');
INSERT INTO rangking VALUES ('15', '29', '5', 'TEKNIK KOMPUTER JARINGAN', '32', '10', '3', '5', '3');
INSERT INTO rangking VALUES ('16', '66', '5', 'MULTIMEDIA', '20', '10', '4', '5', '3');

-- ----------------------------
-- Table structure for `setting`
-- ----------------------------
DROP TABLE IF EXISTS `setting`;
CREATE TABLE `setting` (
  `IDSET` tinyint(4) NOT NULL AUTO_INCREMENT,
  `NAMASET` varchar(50) DEFAULT NULL,
  `SET1` varchar(50) DEFAULT NULL,
  `SET2` varchar(50) DEFAULT NULL,
  `SET3` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IDSET`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of setting
-- ----------------------------
INSERT INTO setting VALUES ('3', 'Ujian Nasional', '40', '40', null);

-- ----------------------------
-- Table structure for `ujian`
-- ----------------------------
DROP TABLE IF EXISTS `ujian`;
CREATE TABLE `ujian` (
  `IDUJIAN` tinyint(4) NOT NULL AUTO_INCREMENT,
  `NAMAUJIAN` varchar(50) DEFAULT NULL,
  `BOBOT` tinyint(4) DEFAULT NULL,
  `SKORMAKSIMAL` tinyint(4) DEFAULT NULL,
  `IDJUR` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`IDUJIAN`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of ujian
-- ----------------------------
INSERT INTO ujian VALUES ('2', 'Ujian Sekolah', '25', '100', '0');
INSERT INTO ujian VALUES ('1', 'Ujian Sekolah', '25', '100', null);
INSERT INTO ujian VALUES ('3', 'Ujian Sekolah', '50', '100', '3');
INSERT INTO ujian VALUES ('4', 'Ujian Sekolah', '50', '100', '4');
INSERT INTO ujian VALUES ('5', 'Ujian Sekolah', '25', '100', '0');
INSERT INTO ujian VALUES ('6', 'Ujian Produktif TB', '25', '100', null);
INSERT INTO ujian VALUES ('7', 'Ujian Produktif Perbankan', '25', '100', '2');
INSERT INTO ujian VALUES ('8', 'Ujian Produktif TKJ', '25', '100', '3');
INSERT INTO ujian VALUES ('44', 'Ujian Sekolah', '50', '100', '1');
INSERT INTO ujian VALUES ('10', 'Ujian Produktif TKR', '25', '100', '5');
INSERT INTO ujian VALUES ('45', 'Wawancara', '10', '10', '1');
INSERT INTO ujian VALUES ('11', 'Prestasi', '10', '10', null);
INSERT INTO ujian VALUES ('12', 'Prestasi', '10', '10', '2');
INSERT INTO ujian VALUES ('13', 'Prestasi', '10', '10', '3');
INSERT INTO ujian VALUES ('14', 'Prestasi', '10', '10', '4');
INSERT INTO ujian VALUES ('15', 'Prestasi', '10', '10', '5');
