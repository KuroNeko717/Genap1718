<?php require_once('Connections/koneksi.php');

session_start();?>
<?php
$IDPILJUR1 = $_POST['NAMAJURUSAN1'];
$IDPILJUR2 = $_POST['NAMAJURUSAN2'];
$NOPENDAFTARAN = $_POST['NoPendaftaran'];
$NAMASISWA = $_POST['NamaSiswa'];
$TEMPATLAHIR = $_POST['TempatLahir'];
$TGLLAHIR = $_POST['tahun'].$_POST['bulan'].$_POST['Tgl'];
$JENISKELAMIN = $_POST['radio'];
$AGAMA = $_POST['Agama'];
$ALAMAT = $_POST['Alamat'];
$KOTAALAMAT = $_POST['KotaAlamatSiswa'];
$PROPINSI = $_POST['Propinsi'];
$NOTELPRUMAH = $_POST['NOTELPRUMAH'];
$NOHP = $_POST['NOHP'];
$NOIJASAH = $_POST['NOIJASAH'];
$TGLIJASAH = $_POST['tahun2'].$_POST['bulan2'].$_POST['Tgl2'];
$NUN = $_POST['NUN1']. $_POST['NUN2'].".". $_POST['NUN3']. $_POST['NUN4'];
$NOSKHUN = $_POST['NOSKHUN'];
$TGLSKHUN = $_POST['tahun3'].$_POST['bulan3'].$_POST['Tgl3'];
$ASALSMP = $_POST['ASALSMP'];
$NAMAAYAH = $_POST['NAMAAYAH'];
$PEKERJAANAYAH = $_POST['PEKERJAANAYAH'];
$NOHPAYAH = $_POST['NOHPAYAH'];
$NAMAIBU = $_POST['NAMAIBU'];
$PEKERJAANIBU = $_POST['PEKERJAANIBU'];
$ALAMATAYAH = $_POST['ALAMATAYAH'];
$KOTAALAMATAYAH = $_POST['KOTAALAMATAYAH'];
$NAMAWALI = $_POST['NAMAWALI'];
$ALAMATWALI = $_POST['ALAMATWALI'];
$PEKERJAANWALI = $_POST['PEKERJAANWALI'];
$NOHPWALI = $_POST['NOHPWALI'];
$POINT = $_POST['POINT'];
$PRESTASI = $_POST['PRESTASI'];
$CATATANLAIN = $_POST['CATATANLAIN'];               

if ($NUN == "" or $NoPendaftaran == "" or $NamaSiswa == "" or $NOIJASAH == "" or $ASALSMP == "") {
	echo "<center>Data Belum Lengkap, silahkan <a href = 'input.php'>isi lagi</a></center>";
	} else if ($IDPILJUR1 == $IDPILJUR2) {
	echo "<center>Jurusan tidak boleh sama, silahkan <a href = 'input.php'>Perbaiki data lagi</a></center>";
	} else {
?>




<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_koneksi, $koneksi);
$query_jurusan1 = "SELECT * FROM jurusan WHERE IDJUR = $IDPILJUR1";
$jurusan1 = mysql_query($query_jurusan1, $koneksi) or die(mysql_error());
$row_jurusan1 = mysql_fetch_assoc($jurusan1);
$totalRows_jurusan1 = mysql_num_rows($jurusan1);

mysql_select_db($database_koneksi, $koneksi);
$query_jurusan2 = "SELECT * FROM jurusan WHERE IDJUR = $IDPILJUR2";
$jurusan2 = mysql_query($query_jurusan2, $koneksi) or die(mysql_error());
$row_jurusan2 = mysql_fetch_assoc($jurusan2);
$totalRows_jurusan2 = mysql_num_rows($jurusan2);
?>
 



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $title ?></title>
<style type="text/css">
<!--
.style1 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style3 {font-size: 12px}
.style18 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; }
-->
</style>
</head>

<body>
<table width="1024" border="0" align="center" cellpadding="0" cellspacing="0" id="Table_01">
<tr>
		<td colspan="5"><img src="images/header.jpg" alt="" width="1024" height="105" id="header" /></td>
  </tr>
	<tr>
		<td colspan="5" background="images/menu.jpg">&nbsp;</td>
  </tr>
	<tr>
		<td width="1024" height="8" colspan="5">
			<img src="images/spacer.gif" alt="" width="1024" height="8" /></td>
	</tr>
	<tr>
		<td width="48" height="19">&nbsp;</td>
		<td colspan="3"><p align="center" class="style20 style1 style3 style3">FORMULIR PPDB</p>	    </td>
  <td width="54" height="56"><span class="style19"></span></td>
	</tr>
	<tr>
	  <td width="48" height="11">&nbsp;</td>
		<td width="922" height="11" colspan="3">&nbsp;</td>
        <td width="54" height="11"><span class="style19"></span></td>
  </tr>
	<tr>
	  <td width="48" height="19">&nbsp;</td>
		<td><span class="style22 style1 style3 style3">Identitas Siswa</span></td>
  <td width="42" height="413" rowspan="2">&nbsp;</td>
		<td><span class="style22 style1 style3 style3">Identitas Asal Sekolah</span></td>
        <td width="54" height="19"><span class="style19"></span></td>
  </tr>
	<tr>
	  <td width="48" height="13">&nbsp;</td>
		<td width="440" height="13" align="left" valign="top"><table width="420" border="0" align="left">
          <tr>
            <td width="140" class="style18 style1 style3 style3">Nomer Pendaftaran</td>
            <td width="7" class="style18 style1 style3 style3">:</td>
            <td width="251" class="style18 style1 style3 style3"><?php echo $NOPENDAFTARAN ?>&nbsp;</td>
          </tr>
          <tr>
            <td class="style18 style1 style3 style3">Nama Calon Siswa</td>
            <td class="style18 style1 style3 style3">:</td>
            <td class="style18 style1 style3 style3"><?php echo $NAMASISWA; ?></td>
          </tr>
          <tr>
            <td class="style18 style1 style3 style3">Tempat Lahir</td>
            <td class="style18 style1 style3 style3">:</td>
            <td class="style18 style1 style3 style3"><?php echo $TEMPATLAHIR ?></td>
          </tr>
          <tr>
            <td class="style18 style1 style3 style3">Tanggal Lahir</td>
            <td class="style18 style1 style3 style3">:</td>
            <td class="style18 style1 style3 style3"><?php echo $_POST['Tgl'], " - ", $_POST['bulan'], " - ", $_POST['tahun'] ?></td>
          </tr>
          <tr>
            <td class="style18 style1 style3 style3">Jenis Kelamin</td>
            <td class="style18 style1 style3 style3">:</td>
            <td class="style18 style1 style3 style3"><?php 
			
			
			if ($JENISKELAMIN=="L"){
			echo "Laki-laki" ;
			} else {
			echo "Perempuan" ;
			}
			 ?>
            
            
            &nbsp;</td>
          </tr>
          <tr>
            <td class="style18 style1 style3 style3">Agama</td>
            <td class="style18 style1 style3 style3">:</td>
            <td class="style18 style1 style3 style3"><?php echo $AGAMA ?>&nbsp;</td>
          </tr>
          <tr>
            <td class="style18 style1 style3 style3">Alamat</td>
            <td class="style18 style1 style3 style3">:</td>
            <td class="style18 style1 style3 style3"><?php echo $ALAMAT ?>&nbsp;</td>
          </tr>
          <tr>
            <td class="style18 style1 style3 style3">Kota</td>
            <td class="style18 style1 style3 style3">:</td>
            <td class="style18 style1 style3 style3"><?php echo $KOTAALAMAT ?>&nbsp;</td>
          </tr>
          <tr>
            <td class="style18 style1 style3 style3">Propinsi</td>
            <td class="style18 style1 style3 style3">:</td>
            <td class="style18 style1 style3 style3"><?php echo $PROPINSI ?>&nbsp;</td>
          </tr>
          <tr>
            <td class="style18 style1 style3 style3">No Telp</td>
            <td class="style18 style1 style3 style3">:</td>
            <td class="style18 style1 style3 style3"><?php echo $NOTELPRUMAH ?>&nbsp;</td>
          </tr>
          <tr>
            <td class="style18 style1 style3 style3">No Hp</td>
            <td class="style18 style1 style3 style3">:</td>
            <td class="style18 style1 style3 style3"><?php echo $NOHP ?>&nbsp;</td>
          </tr>
        </table>
	  <p class="style18 style1 style3 style3">&nbsp;</p>
	  <p class="style18 style1 style3 style3">&nbsp;</p>
	  <p class="style18 style1 style3 style3">&nbsp;</p>
	  <p class="style18 style1 style3 style3">&nbsp;</p>
	  <p class="style18 style1 style3 style3">&nbsp;</p>
	  <p class="style18 style1 style3 style3">&nbsp;</p>
	  <p class="style18 style1 style3 style3">&nbsp;</p>
	  <p class="style18 style1 style3 style3">&nbsp;</p>
	  <table width="420" border="0" align="left">
        <tr>
          <td colspan="3" class="style22 style1 style3 style3">Identitas Orang Tua / Wali</td>
        </tr>
        <tr>
          <td width="140" class="style18 style1 style3 style3">Nama Ayah</td>
          <td width="7" class="style18 style1 style3 style3">:</td>
          <td width="251" class="style18 style1 style3 style3"><?php echo $NAMAAYAH ?>&nbsp;</td>
        </tr>
        <tr>
          <td class="style18 style1 style3 style3">Pekerjaan Ayah</td>
          <td class="style18 style1 style3 style3">&nbsp;</td>
          <td class="style18 style1 style3 style3"><?php echo $PEKERJAANAYAH ?>&nbsp;</td>
        </tr>
        <tr>
          <td class="style18 style1 style3 style3">No Telp Ayah</td>
          <td class="style18 style1 style3 style3">&nbsp;</td>
          <td class="style18 style1 style3 style3"><?php echo $NOHPAYAH ?>&nbsp;</td>
        </tr>
        <tr>
          <td class="style18 style1 style3 style3">Nama Ibu</td>
          <td class="style18 style1 style3 style3">&nbsp;</td>
          <td class="style18 style1 style3 style3"><?php echo $NAMAIBU ?>&nbsp;</td>
        </tr>
        <tr>
          <td class="style18 style1 style3 style3">Pekerjaan Ibu</td>
          <td class="style18 style1 style3 style3">&nbsp;</td>
          <td class="style18 style1 style3 style3"><?php echo $PEKERJAANIBU ?>&nbsp;</td>
        </tr>
        <tr>
          <td class="style18 style1 style3 style3">Alamat</td>
          <td class="style18 style1 style3 style3">&nbsp;</td>
          <td class="style18 style1 style3 style3"><?php echo $ALAMATAYAH ?>&nbsp;</td>
        </tr>
        <tr>
          <td class="style18 style1 style3 style3">Kota </td>
          <td class="style18 style1 style3 style3">&nbsp;</td>
          <td class="style18 style1 style3 style3"><?php echo $KOTAALAMATAYAH ?>&nbsp;</td>
        </tr>
        <tr>
          <td class="style18 style1 style3 style3">&nbsp;</td>
          <td class="style18 style1 style3 style3">&nbsp;</td>
          <td class="style18 style1 style3 style3">&nbsp;</td>
        </tr>
        <tr>
          <td class="style18 style1 style3 style3">Nama Wali</td>
          <td class="style18 style1 style3 style3">&nbsp;</td>
          <td class="style18 style1 style3 style3"><?php echo $NAMAWALI ?>&nbsp;</td>
        </tr>
        <tr>
          <td class="style18 style1 style3 style3">Alamat Wali</td>
          <td class="style18 style1 style3 style3">&nbsp;</td>
          <td class="style18 style1 style3 style3"><?php echo $ALAMATWALI ?>&nbsp;</td>
        </tr>
        <tr>
          <td class="style18 style1 style3 style3">Pekerjaan Wali</td>
          <td class="style18 style1 style3 style3">&nbsp;</td>
          <td class="style18 style1 style3 style3"><?php echo $PEKERJAANWALI ?>&nbsp;</td>
        </tr>
        <tr>
          <td class="style18 style1 style3 style3">No Telp Wali</td>
          <td class="style18 style1 style3 style3">&nbsp;</td>
          <td class="style18 style1 style3 style3"><?php echo $NOHPWALI ?>&nbsp;</td>
        </tr>
        <tr>
          <td class="style18 style1 style3 style3">&nbsp;</td>
          <td class="style18 style1 style3 style3">&nbsp;</td>
          <td class="style18 style1 style3 style3">&nbsp;</td>
        </tr>
      </table>	  
	  <p class="style18 style1 style3 style3">&nbsp;</p></td>
  <td width="440" height="13" align="left" valign="top"><table width="420" border="0" align="left">
    <tr>
      <td width="140" class="style18 style1 style3 style3">Nomer Ijazah</td>
      <td width="7" class="style18 style1 style3 style3">:</td>
      <td width="251" class="style18 style1 style3 style3"><?php echo $NOIJASAH ?>&nbsp;</td>
    </tr>
    <tr>
      <td class="style18 style1 style3 style3">Tanggal Ijazah</td>
      <td class="style18 style1 style3 style3">:</td>
      <td class="style18 style1 style3 style3">&nbsp;<?php echo $_POST['Tgl2'], " - ", $_POST['bulan2'], " - ", $_POST['tahun2'] ?></td>
    </tr>
    <tr>
      <td class="style18 style1 style3 style3">Nilai Ujian Nasional</td>
      <td class="style18 style1 style3 style3">:</td>
      <td class="style18 style1 style3 style3"><?php echo $NUN ?></td>
    </tr>
    <tr>
      <td class="style18 style1 style3 style3"><span class="style18">Nomor STL/SKHUN</span></td>
      <td class="style18 style1 style3 style3">:</td>
      <td class="style18 style1 style3 style3"><?php echo $_POST['Tgl3'], " - ", $_POST['bulan3'], " - ", $_POST['tahun3'] ?></td>
    </tr>
    <tr>
      <td class="style18 style1 style3 style3"><span class="style18">Tanggal STL/SKHUN</span></td>
      <td class="style18 style1 style3 style3">:</td>
      <td class="style18 style1 style3 style3"><?php echo $NOSKHUN ?>&nbsp;</td>
    </tr>
    <tr>
      <td class="style18 style1 style3 style3">Asal SMP / Mts</td>
      <td class="style18 style1 style3 style3">:</td>
      <td class="style18 style1 style3 style3"><?php echo $ASALSMP ?>&nbsp;</td>
    </tr>
    <tr>
      <td class="style18 style1 style3 style3">Kota SMP / Mts</td>
      <td class="style18 style1 style3 style3">:</td>
      <td class="style18 style1 style3 style3"><?php echo $KOTAASALSMP ?>&nbsp;</td>
    </tr>
    <tr>
      <td class="style18 style1 style3 style3">Prestasi</td>
      <td class="style18 style1 style3 style3">:</td>
      <td rowspan="2" align="left" valign="top" class="style18 style1 style3 style3"><?php echo $PRESTASI ?>&nbsp;</td>
    </tr>
    <tr>
      <td class="style18 style1 style3 style3">&nbsp;</td>
      <td class="style18 style1 style3 style3">&nbsp;</td>
      </tr>
  </table>
    <p class="style18 style1 style3 style3">&nbsp;</p>
    <p class="style18 style1 style3 style3">&nbsp;</p>
    <p class="style18 style1 style3 style3">&nbsp;</p>
    <p class="style18 style1 style3 style3">&nbsp;</p>
    <p class="style18 style1 style3 style3">&nbsp;</p>
    <table width="420" border="0" align="left">
      <tr>
        <td colspan="3" class="style22 style1 style3 style3">Program Keahlian</td>
        </tr>
      <tr>
        <td width="140" class="style18 style1 style3 style3">Pilihan 1</td>
        <td width="7" class="style18 style1 style3 style3">:</td>
        <td width="251" class="style18 style1 style3 style3"><?php echo $row_jurusan1['NAMAJURUSAN']; ?></td>
      </tr>
      <tr>
        <td class="style18 style1 style3 style3">Pilihan 2</td>
        <td class="style18 style1 style3 style3">:</td>
        <td class="style18 style1 style3 style3"><?php echo $row_jurusan2['NAMAJURUSAN']; ?></td>
      </tr>
      <tr>
        <td class="style18 style1 style3 style3">Point</td>
        <td class="style18 style1 style3 style3">:</td>
        <td class="style18 style1 style3 style3"><?php echo $POINT ?>&nbsp;</td>
      </tr>
      <tr>
        <td class="style18 style1 style3 style3">Catatan</td>
        <td class="style18 style1 style3 style3">:</td>
        <td rowspan="2" align="left" valign="top" class="style18 style1 style3 style3"><?php echo $CATATANLAIN ?>&nbsp;</td>
      </tr>
      <tr>
        <td class="style18 style1 style3 style3">&nbsp;</td>
        <td class="style18 style1 style3 style3">&nbsp;</td>
        </tr>
      <tr>
        <td colspan="3" class="style18 style1 style3 style3"><p>&nbsp;</p>

          <form id="form1" name="form1" method="post" action="cetak.php">
          <input name="IDPILJUR1" type="hidden" value="<?php echo $IDPILJUR1 ?>" />
          <input name="IDPILJUR2" type="hidden" value="<?php echo $IDPILJUR2 ?>" />
          <input name="IDPETUGAS" type="hidden" value="<?php echo $IDPETUGAS ?>" />
          <input name="NOPENDAFTARAN" type="hidden" value="<?php echo $NOPENDAFTARAN ?>" />
          <input name="NAMASISWA" type="hidden" value="<?php echo $NAMASISWA ?>" />
          <input name="TEMPATLAHIR" type="hidden" value="<?php echo $TEMPATLAHIR ?>" />
          <input name="TGLLAHIR" type="hidden" value="<?php echo $TGLLAHIR ?>" />
          <input name="JENISKELAMIN" type="hidden" value="<?php echo $JENISKELAMIN ?>" />
          <input name="AGAMA" type="hidden" value="<?php echo $AGAMA ?>" />
          <input name="ALAMAT" type="hidden" value="<?php echo $ALAMAT ?>" />
          <input name="KOTAALAMAT" type="hidden" value="<?php echo $KOTAALAMAT ?>" />
          <input name="PROPINSI" type="hidden" value="<?php echo $PROPINSI ?>" />
          <input name="NOTELPRUMAH" type="hidden" value="<?php echo $NOTELPRUMAH ?>" />
          <input name="NOHP" type="hidden" value="<?php echo $NOHP ?>" />
          <input name="FOTO" type="hidden" value="<?php echo $FOTO ?>" />
          <input name="NOIJASAH" type="hidden" value="<?php echo $NOIJASAH ?>" />
          <input name="TGLIJASAH" type="hidden" value="<?php echo $TGLIJASAH ?>" />
          <input name="NUN" type="hidden" value="<?php echo $NUN ?>" />
          <input name="NOSKHUN" type="hidden" value="<?php echo $NOSKHUN ?>" />
          <input name="TGLSKHUN" type="hidden" value="<?php echo $TGLSKHUN ?>" />
          <input name="ASALSMP" type="hidden" value="<?php echo $ASALSMP ?>" />
          <input name="KOTAASALSMP" type="hidden" value="<?php echo $KOTAASALSMP ?>" />
          <input name="NAMAAYAH" type="hidden" value="<?php echo $NAMAAYAH ?>" />
          <input name="PEKERJAANAYAH" type="hidden" value="<?php echo $PEKERJAANAYAH ?>" />
          <input name="NOHPAYAH" type="hidden" value="<?php echo $NOHPAYAH ?>" />
          <input name="NAMAIBU" type="hidden" value="<?php echo $NAMAIBU ?>" />
          <input name="PEKERJAANIBU" type="hidden" value="<?php echo $IPEKERJAANIBU ?>" />
          <input name="ALAMATAYAH" type="hidden" value="<?php echo $ALAMATAYAH ?>" />
          <input name="KOTAALAMATAYAH" type="hidden" value="<?php echo $KOTAALAMATAYAH ?>" />
          <input name="NAMAWALI" type="hidden" value="<?php echo $NAMAWALI ?>" />
          <input name="ALAMATWALI" type="hidden" value="<?php echo $ALAMATWALI ?>" />
          <input name="PEKERJAANWALI" type="hidden" value="<?php echo $PEKERJAANWALI ?>" />
          <input name="NOHPWALI" type="hidden" value="<?php echo $NOHPWALI ?>" />
          <input name="POINT" type="hidden" value="<?php echo $POINT ?>" />
          <input name="PRESTASI" type="hidden" value="<?php echo $PRESTASI ?>" />
          <input name="CATATANLAIN" type="hidden" value="<?php echo $CATATANLAIN   ?>" />
                               
            <input type="submit" name="OKE" id="OKE" value="Submit" />
                    </form>
                    <?php 
						
					
					?>
          <p>&nbsp;</p>
          <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p></td>
        </tr>
    </table>    
    <p class="style18 style1 style3 style3">&nbsp;</p></td>
  <td width="54" height="13"><span class="style19"></span></td>
  </tr>
	<tr>
	  <td width="48" height="146">&nbsp;</td>
		<td colspan="3"><span class="style3"></span></td>
        <td width="54" height="146">&nbsp;</td>
  </tr>
	<tr>
	  <td width="48" height="7">&nbsp;</td>
		<td width="922" height="7" colspan="3">
			<img src="images/spacer.gif" alt="" width="922" height="7" class="style3" /></td>
	    <td width="54" height="7">&nbsp;</td>
	</tr>
	<tr>
	  <td width="48" height="300">&nbsp;</td>
		<td colspan="3"><span class="style3"></span></td>
        <td width="54" height="300">&nbsp;</td>
  </tr>
	<tr>
	  <td width="48" height="25">&nbsp;</td>
		<td width="922" height="25" colspan="3"><span class="style3"></span></td>
        <td width="54" height="25">&nbsp;</td>
  </tr>
</table>

</body>
</html>
<?php
mysql_free_result($jurusan1);

mysql_free_result($jurusan2);
 } ?>