<?php require_once('Connections/koneksi.php'); 
if (!isset($_SESSION)) {
  session_start();
}

$group = $_SESSION['MM_UserGroup'];

if($group == "ADMIN"){
include('menu.php');
} elseif ($group == "PANITIA"){
include('menu2.php');
} else {
header( 'Location: input.php' ) ;
}

?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?><?php require_once('Connections/koneksi.php'); 

mysql_select_db($database_koneksi, $koneksi);
$query_jurusan = "SELECT * FROM jurusan ORDER BY IDJUR ASC";
$jurusan = mysql_query($query_jurusan, $koneksi) or die(mysql_error());
$row_jurusan = mysql_fetch_assoc($jurusan);
$totalRows_jurusan = mysql_num_rows($jurusan);


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<p>REKAPITULASI PENERIMAAN SISWA BARU TAHUN PELAJARAN <?php echo $TahunPelajaran; ?><br />
    <?php echo $NamaSekolah; ?><br />
</p>
<table width="800" class="myTable" height="77" border="1" cellpadding="0" cellspacing="0">
  <tr class="myTableth">
    <td width="30" rowspan="2"><div align="center">No</div></td>
    <td width="316" rowspan="2"><div align="center">Kompetensi Keahlian</div></td>
    <td width="70" rowspan="2"><div align="center">Jumlah Pagu</div></td>
    <td colspan="3"><div align="center">Pendaftar</div></td>
    <td colspan="3"><div align="center">Diterima</div></td>
    <td colspan="3"><div align="center">Tidak Diterima</div></td>
  </tr>
  <tr class="myTableth">
    <td width="37"><div align="center">L</div></td>
    <td width="37"><div align="center">P</div></td>
    <td width="46"><div align="center">Jumlah</div></td>
    <td width="36"><div align="center">L</div></td>
    <td width="36"><div align="center">P</div></td>
    <td width="46"><div align="center">Jumlah</div></td>
    <td width="31"><div align="center">L</div></td>
    <td width="36"><div align="center">P</div></td>
    <td width="53"><div align="center">Jumlah</div></td>
  </tr>
  <?php do { ?>
    <tr>
      <td><div align="center"><?php echo $row_jurusan['IDJUR']; ?></div></td>
      <td><?php echo $row_jurusan['NAMAJURUSAN']; ?></td>
      <td><div align="center"><?php echo $row_jurusan['JUMLAHMAKS']; 
	  									$pagu = $row_jurusan['JUMLAHMAKS'];
										$totalpagu = $totalpagu + $row_jurusan['JUMLAHMAKS'];?>
                                        
       </div></td>
      <td>
        <div align="center">
          <?php 
	  
	 $IDJUR = $row_jurusan['IDJUR'];
	 mysql_select_db($database_koneksi, $koneksi);
	$query_pendaftar = "SELECT count(calonsiswa.IDPILJUR1) as jumlah FROM calonsiswa INNER JOIN jurusan ON calonsiswa.IDPILJUR1 = jurusan.IDJUR
						WHERE jurusan.IDJUR = '$IDJUR' AND calonsiswa.JENISKELAMIN = 'L'";
	$pendaftar = mysql_query($query_pendaftar, $koneksi) or die(mysql_error());
	$row_pendaftar = mysql_fetch_assoc($pendaftar);
	echo $row_pendaftar['jumlah']; 
	$jumdaftarL = $jumdaftarL + $row_pendaftar['jumlah'];
	
	 ?>
          
          
          
        </div></td>
      <td>
      
                <div align="center">
                  <?php 
	  
	 $IDJUR = $row_jurusan['IDJUR'];
	 mysql_select_db($database_koneksi, $koneksi);
$query_pendaftar2 = "SELECT count(calonsiswa.IDPILJUR1) as jumlah FROM calonsiswa INNER JOIN jurusan ON calonsiswa.IDPILJUR1 = jurusan.IDJUR
						WHERE jurusan.IDJUR = '$IDJUR' AND calonsiswa.JENISKELAMIN = 'P'";
	$pendaftar2 = mysql_query($query_pendaftar2, $koneksi) or die(mysql_error());
	$row_pendaftar2 = mysql_fetch_assoc($pendaftar2);
	echo $row_pendaftar2['jumlah'];
	$jumdaftarP = $jumdaftarP + $row_pendaftar2['jumlah'];
	
	 ?>
                  
                  
                </div></td>
      <td><div align="center"><?php $jumlahpendaftar = $row_pendaftar['jumlah'] + $row_pendaftar2['jumlah']; 
	  								echo $jumlahpendaftar ?></div></td>
      <td>
      
        <div align="center">
          <?php 


		mysql_select_db($database_koneksi, $koneksi);
		$query_lp = "SELECT calonsiswa.JENISKELAMIN, nilaiakhir.NA
							FROM nilaiakhir INNER JOIN calonsiswa ON nilaiakhir.IDPENDAFTARAN = calonsiswa.IDPENDAFTARAN
							WHERE calonsiswa.IDPILJUR1 = '$IDJUR' ORDER BY nilaiakhir.NA DESC";
							
		$lp = mysql_query($query_lp, $koneksi) or die(mysql_error());
		$row_lp = mysql_fetch_assoc($lp);
		$totalRows_lp = mysql_num_rows($lp);

if ($jumlahpendaftar > $pagu ){
		$L = 0;
		for ($i=1;$i<=$pagu;$i++){
				
			if ($row_lp['JENISKELAMIN'] =="L") {
				$L++;		
				}
		 	$row_lp  = mysql_fetch_assoc($lp); 
			} 
			echo $L;
	} else {
	$L = $row_pendaftar['jumlah'];
	echo $L ; 
	}

		?>
          
          
          
        </div></td>
      <td>
      
        <div align="center">
          <?php 


		mysql_select_db($database_koneksi, $koneksi);
		$query_lp2 = "SELECT calonsiswa.JENISKELAMIN, nilaiakhir.NA
							FROM nilaiakhir INNER JOIN calonsiswa ON nilaiakhir.IDPENDAFTARAN = calonsiswa.IDPENDAFTARAN
							WHERE calonsiswa.IDPILJUR1 = '$IDJUR' ORDER BY nilaiakhir.NA DESC";
							
		$lp2 = mysql_query($query_lp2, $koneksi) or die(mysql_error());
		$row_lp2 = mysql_fetch_assoc($lp2);
	
if ($jumlahpendaftar > $pagu ){
		$P = 0;	
		for ($i=1;$i<=$pagu;$i++){
			if ($row_lp2['JENISKELAMIN'] =="P" ) {
				$P++;		
				}		
		 	$row_lp2  = mysql_fetch_assoc($lp2); 
			} 
			echo $P;
		} else {
			$P = $row_pendaftar2['jumlah'];
			echo $P;
		}	

		?>
          
          
        </div></td>
      <td>
      
      
        <div align="center">
          <?php 
	  if ($jumlahpendaftar <= $row_jurusan['JUMLAHMAKS']){
	  echo $jumlahpendaftar;
	  } else {
	  echo $row_jurusan['JUMLAHMAKS'];
	  }
	  ?>
          
          
        </div></td>
      <td><div align="center"><?php echo $row_pendaftar['jumlah'] - $L; 

	  ?>
      
      </div></td>
      <td><div align="center"><?php echo  $row_pendaftar2['jumlah'] - $P;?></div></td>
      <td>
        <div align="center">
          <?php 
	  if ($jumlahpendaftar <= $row_jurusan['JUMLAHMAKS']){
	  echo 0;
	  } else {
	  echo $jumlahpendaftar - $row_jurusan['JUMLAHMAKS'];
      } ?>
      </td>
    </tr>
    <?php 
	$jumterimaL = $jumterimaL + $L;
	$jumterimaP = $jumterimaP + $P;
	} while ($row_jurusan = mysql_fetch_assoc($jurusan)); ?>
              
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><div align="center"> <?php echo $totalpagu ?></div></td>
    <td><div align="center"> <?php echo $jumdaftarL?></div></td>
    <td><div align="center"> <?php echo $jumdaftarP?></div></td>
    <td><div align="center"> <?php echo $jumdaftarL + $jumdaftarP?></div></td>
    <td><div align="center"> <?php echo $jumterimaL ?></div></td>
    <td><div align="center"> <?php echo $jumterimaP ?></div></td>
    <td><div align="center"> <?php echo $jumterimaL + $jumterimaP ?></div></td>
    <td><div align="center"> <?php echo $jumdaftarL - $jumterimaL?></div></td>
    <td><div align="center"> <?php echo $jumdaftarP - $jumterimaP?></div></td>
    <td><div align="center"> <?php echo ($jumdaftarL - $jumterimaL) + ($jumdaftarP - $jumterimaP) ?></div></td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($jurusan);

mysql_free_result($pendaftar);
?>
