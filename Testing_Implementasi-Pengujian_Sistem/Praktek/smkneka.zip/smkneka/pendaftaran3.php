
<?php require_once('Connections/koneksi.php');

$IDPILJUR1 = $_POST['IDPILJUR1'];
$IDPILJUR2  = $_POST['IDPILJUR2'];
$IDPETUGAS  = $_POST['IDPETUGAS'];
$NOPENDAFTARAN  = $_POST['NOPENDAFTARAN'];
$NAMASISWA  = $_POST['NAMASISWA'];
$TEMPATLAHIR  = $_POST['TEMPATLAHIR'];
$TGLLAHIR  = $_POST['TGLLAHIR'];
$JENISKELAMIN = $_POST['JENISKELAMIN'];
$AGAMA = $_POST['AGAMA'];
$ALAMAT = $_POST['ALAMAT'];
$KOTAALAMAT = $_POST['KOTAALAMAT'];
$PROPINSI = $_POST['PROPINSI'];
$NOTELPRUMAH = $_POST['NOTELPRUMAH'];
$NOHP = $_POST['NOHP'];
$FOTO = $_POST['FOTO'];
$NOIJASAH = $_POST['NOIJASAH'];
$TGLIJASAH  = $_POST['TGLIJASAH'];
$NUN = $_POST['NUN'];
$NOSKHUN  = $_POST['NOSKHUN'];
$TGLSKHUN  = $_POST['TGLSKHUN'];
$ASALSMP = $_POST['ASALSMP'];
$KOTAASALSMP = $_POST['KOTAASALSMP'];
$NAMAAYAH = $_POST['NAMAAYAH'];
$PEKERJAANAYAH = $_POST['PEKERJAANAYAH'];
$NOHPAYAH = $_POST['NOHPAYAH'];
$NAMAIBU = $_POST['NAMAIBU'];
$PEKERJAANIBU = $_POST['PEKERJAANIBU'];
$ALAMATAYAH = $_POST['ALAMATAYAH'];
$KOTAALAMATAYAH = $_POST['KOTAALAMATAYAH'];
$NAMAWALI = $_POST['NAMAWALI'];
$ALAMATWALI = $_POST['ALAMATWALI'];
$PEKERJAANWALI = $_POST['PEKERJAANWALI'];
$NOHPWALI = $_POST['NOHPWALI'];
$POINT = $_POST['POINT'];
$PRESTASI = $_POST['PRESTASI'];
$CATATANLAIN  = $_POST['CATATANLAIN'];
$JUR1  = $_POST['JUR1'];
$JUR2  = $_POST['JUR2'];



$kueri = "INSERT INTO calon (IDPILJUR1,IDPILJUR2,IDPETUGAS,NOPENDAFTARAN,NAMASISWA,
TEMPATLAHIR,TGLLAHIR,JENISKELAMIN,AGAMA,ALAMAT,KOTAALAMAT,
PROPINSI,NOTELPRUMAH,NOHP,FOTO,NOIJASAH,TGLIJASAH,NUN,NOSKHUN,
TGLSKHUN,ASALSMP,KOTAASALSMP,NAMAAYAH,PEKERJAANAYAH,NOHPAYAH,NAMAIBU,
PEKERJAANIBU,ALAMATAYAH,KOTAALAMATAYAH,NAMAWALI,ALAMATWALI,PEKERJAANWALI,
NOHPWALI,POINT,PRESTASI,CATATANLAIN,APPROVE)
VALUES 
('$_POST[IDPILJUR1]','$_POST[IDPILJUR2]','$_POST[IDPETUGAS]','$_POST[NOPENDAFTARAN]'
,'$_POST[NAMASISWA]','$_POST[TEMPATLAHIR]','$_POST[TGLLAHIR]'
,'$_POST[JENISKELAMIN]','$_POST[AGAMA]','$_POST[ALAMAT]'
,'$_POST[KOTAALAMAT]','$_POST[PROPINSI]','$_POST[NOTELPRUMAH]'
,'$_POST[NOHP]','$_POST[FOTO]','$_POST[NOIJASAH]'
,'$_POST[TGLIJASAH]','$_POST[NUN]','$_POST[NOSKHUN]'
,'$_POST[TGLSKHUN]','$_POST[ASALSMP]','$_POST[KOTAASALSMP]'
,'$_POST[NAMAAYAH]','$_POST[PEKERJAANAYAH]','$_POST[NOHPAYAH]'
,'$_POST[NAMAIBU]','$_POST[PEKERJAANIBU]','$_POST[ALAMATAYAH]'
,'$_POST[KOTAALAMATAYAH]','$_POST[NAMAWALI]','$_POST[ALAMATWALI]'
,'$_POST[PEKERJAANWALI]','$_POST[NOHPWALI]','$_POST[POINT]'
,'$_POST[PRESTASI]','$_POST[CATATANLAIN]','$_POST[APPROVE]'
)";

mysql_query($kueri);

echo $KOTAALAMATAYAH;


?>

<SCRIPT LANGUAGE="JavaScript"> 
if (window.print) {
document.write('<form><input type=button name=print value="Print" onClick="window.print()"></form>');
}
</script>


<style type="text/css">
<!--
.style5 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12; }
.style6 {font-size: 12}
.style8 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12; font-weight: bold; }
.style9 {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-style: italic;
}
.style12 {font-size: 12; font-weight: bold; }
-->
</style>
<table width="800" height="227" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="4"><div align="center"><span class="style8">FORMULIR PENDAFTARAN PENERIMAAN PESERTA DIDIK BARU </span></div></td>
  </tr>
  <tr>
    <td height="24" colspan="4" class="style8"><div align="center"><?php echo $NamaSekolah; ?>&nbsp;</div></td>
  </tr>
  <tr>
    <td colspan="4" class="style8"><div align="center">TAHUN PELAJARAN : <?php echo $TahunPelajaran ?></div></td>
  </tr>
  <tr>
    <td colspan="4">&nbsp;</td>
  </tr>
  <tr>
    <td width="133" class="style5"><span class="style8">NO FORMULIR</span></td>
    <td width="305" class="style5"><span class="style12">:<?php echo $NOPENDAFTARAN ?></span></td>
    <td width="95" class="style5">PILIHAN 1</td>
    <td width="267" class="style5"><span class="style6">:<?php echo $JUR1 ?></span></td>
  </tr>
  <tr>
    <td class="style5"><span class="style6"></span></td>
    <td class="style5"><span class="style6"></span></td>
    <td class="style5"><span class="style6">PILIHAN 2</span></td>
    <td class="style5"><span class="style6">:<?php echo $JUR2 ?></span></td>
  </tr>
  <tr>
    <td class="style5"><span class="style5">NAMA LENGKAP</span></td>
    <td class="style5"><span class="style5">:<?php echo $NAMASISWA ?></span></td>
    <td class="style5">&nbsp;</td>
    <td class="style5">&nbsp;</td>
  </tr>
  <tr>
    <td class="style5">TTL</td>
    <td class="style5">:<?php echo $TEMPATLAHIR . " , " . $TGLLAHIR ;?></td>
    <td class="style5">&nbsp;</td>
    <td class="style5">&nbsp;</td>
  </tr>
  <tr>
    <td class="style5"><span class="style5">ASAL SEKOLAH</span></td>
    <td class="style5">:<?php echo $ASALSMP ?></td>
    <td class="style5"><span class="style6">NILAI UN</span></td>
    <td class="style5">: <?php echo $NUN ?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td class="style5">&nbsp;</td>
    <td class="style5">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="4">&nbsp;</td>
  </tr>
</table>
<table width="800" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td bordercolor="#000000"><p align="center" class="style9">Blanko Verifikasi :</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p></td>
  </tr>
</table>
<p>&nbsp;</p>
<table width="800" height="227" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="4"><div align="center"><span class="style8">FORMULIR PENDAFTARAN PENERIMAAN PESERTA DIDIK BARU </span></div></td>
  </tr>
  <tr>
    <td height="24" colspan="4" class="style8"><div align="center"><?php echo $NamaSekolah; ?>&nbsp;</div></td>
  </tr>
  <tr>
    <td colspan="4" class="style8"><div align="center">TAHUN PELAJARAN : <?php echo $TahunPelajaran ?></div></td>
  </tr>
  <tr>
    <td colspan="4">&nbsp;</td>
  </tr>
  <tr>
    <td width="133" class="style5"><span class="style8">NO FORMULIR</span></td>
    <td width="305" class="style5"><span class="style12">:<?php echo $NOPENDAFTARAN ?></span></td>
    <td width="95" class="style5">PILIHAN 1</td>
    <td width="267" class="style5"><span class="style6">:<?php echo $JUR1 ?></span></td>
  </tr>
  <tr>
    <td class="style5"><span class="style6"></span></td>
    <td class="style5"><span class="style6"></span></td>
    <td class="style5"><span class="style6">PILIHAN 2</span></td>
    <td class="style5"><span class="style6">:<?php echo $JUR2 ?></span></td>
  </tr>
  <tr>
    <td class="style5">NAMA LENGKAP</td>
    <td class="style5">:<?php echo $NAMASISWA ?></td>
    <td class="style5">&nbsp;</td>
    <td class="style5">&nbsp;</td>
  </tr>
  <tr>
    <td class="style5">TTL</td>
    <td class="style5">:<?php echo $TEMPATLAHIR . " , " . $TGLLAHIR ;?></td>
    <td class="style5">&nbsp;</td>
    <td class="style5">&nbsp;</td>
  </tr>
  <tr>
    <td class="style5">ASAL SEKOLAH</td>
    <td class="style5">:<?php echo $ASALSMP ?></td>
    <td class="style5"><span class="style6">NILAI UN</span></td>
    <td class="style5">: <?php echo $NUN ?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td class="style5">&nbsp;</td>
    <td class="style5">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="4">&nbsp;</td>
  </tr>
</table>
<table width="800" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td bordercolor="#000000"><p align="center" class="style9">Blanko Verifikasi :</p>
        <p>&nbsp;</p>
      <p>&nbsp;</p></td>
  </tr>
</table>
<p></p>
<p>&nbsp;</p>

