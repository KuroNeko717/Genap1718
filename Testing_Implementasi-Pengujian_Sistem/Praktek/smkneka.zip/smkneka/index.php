<?php require_once('Connections/koneksi.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_koneksi, $koneksi);
$query_indexberita = "SELECT IDBERITA, JUDUL FROM berita ORDER BY IDBERITA DESC";
$indexberita = mysql_query($query_indexberita, $koneksi) or die(mysql_error());
$row_indexberita = mysql_fetch_assoc($indexberita);
$totalRows_indexberita = mysql_num_rows($indexberita);



$colname_berita = $row_indexberita['IDBERITA'];
if (isset($_GET['IDBERITA'])) {
  $colname_berita = $_GET['IDBERITA'];
}
mysql_select_db($database_koneksi, $koneksi);
$query_berita = sprintf("SELECT * FROM berita WHERE IDBERITA = %s", GetSQLValueString($colname_berita, "int"));
$berita = mysql_query($query_berita, $koneksi) or die(mysql_error());
$row_berita = mysql_fetch_assoc($berita);
$totalRows_berita = mysql_num_rows($berita);


?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $title ?></title>
<style type="text/css">
<!--
#apDiv1 {
	position:absolute;
	left:15px;
	top:135px;
	width:178px;
	height:341px;
	z-index:0;
}
#apDiv2 {
	position:absolute;
	left:15px;
	top:135px;
	width:162px;
	height:344px;
	z-index:0;
	padding-left: 8px;
	padding-top: 8px;
	padding-right: 8px;
	background-color: #EEEEEE;
}
#apDiv3 {
	position:absolute;
	left:210px;
	top:135px;
	width:528px;
	height:343px;
	z-index:2;
	padding-left: 8px;
	padding-top: 8px;
	padding-right: 8px;
}
#apDiv4 {
	position:absolute;
	left:766px;
	top:136px;
	width:260px;
	height:341px;
	z-index:3;
	padding-left: 8px;
	padding-top: 8px;
	padding-right: 8px;
	background-color: #EEEEEE;
}
.style1 {color: #000000}
.style2 {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 14px;
}
.style3 {
	color: #996699;
	font-weight: bold;
}
.style4 {color: #996699; font-weight: bold; font-family: Geneva, Arial, Helvetica, sans-serif; }
.style5 {
	font-size: 10px
}
a:link {
	color: #333333;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #333333;
}
a:hover {
	text-decoration: underline;
	color: #999999;
}
a:active {
	text-decoration: none;
	color: #333333;
}
-->
</style>
</head>

<body>
<div id="apDiv1"></div>
<div class="style2" id="apDiv3">
  <p class="style3">INFORMASI PPDB</p>
  <p> <strong><?php echo $row_berita['JUDUL']; ?></strong><br />
      <br />
      <?php echo $row_berita['ISIAWAL']; ?><br />
<br />
<br />
  </p>
</div>
<div class="style4" id="apDiv4">
  <p>Index Info</p>
  <?php do { ?>
    <p class="style2 style1 style5"><a href="index.php?IDBERITA=<?php echo $row_indexberita['IDBERITA']; ?>">- <?php echo $row_indexberita['JUDUL']; ?></a></p>
    <?php } while ($row_indexberita = mysql_fetch_assoc($indexberita)); ?></div>
    
    
<img src="images/header.jpg" />
<div class="style2" id="apDiv2">
  <p><a href="pendaftaran.php">Pendaftaran</a></p>
  <p><a href="pengumuman.php">P<span class="style1">engumuman</span></a></p>
  <p>Test Online</p>
  <p><a href="index1.php">Login</a></p>
</div>

</body>
</html>
<?php
mysql_free_result($berita);

mysql_free_result($indexberita);
?>
