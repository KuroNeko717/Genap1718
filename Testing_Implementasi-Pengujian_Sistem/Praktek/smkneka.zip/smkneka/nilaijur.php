<?php require_once('Connections/koneksi.php'); 
if (!isset($_SESSION)) {
  session_start();
}

$group = $_SESSION['MM_UserGroup'];

if($group == "ADMIN"){
include('menu.php');
} elseif ($group == "PANITIA"){
include('menu2.php');
} else {
header( 'Location: input.php' ) ;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_koneksi, $koneksi);
$query_jurusan = "SELECT * FROM jurusan ORDER BY IDJUR ASC";
$jurusan = mysql_query($query_jurusan, $koneksi) or die(mysql_error());
$row_jurusan = mysql_fetch_assoc($jurusan);
$totalRows_jurusan = mysql_num_rows($jurusan);

$colname_ujian = "-1";
if (isset($_GET['IDJUR'])) {
  $colname_ujian = $_GET['IDJUR'];
}
mysql_select_db($database_koneksi, $koneksi);
$query_ujian = sprintf("SELECT * FROM ujian WHERE IDJUR = %s ORDER BY IDJUR ASC", GetSQLValueString($colname_ujian, "int"));
$ujian = mysql_query($query_ujian, $koneksi) or die(mysql_error());
$row_ujian = mysql_fetch_assoc($ujian);
$totalRows_ujian = mysql_num_rows($ujian);

$kodeujian = $_GET['IDUJIAN'];

mysql_select_db($database_koneksi, $koneksi);
$query_Recordset1 = "SELECT calonsiswa.IDPENDAFTARAN, calonsiswa.NOPENDAFTARAN, calonsiswa.NAMASISWA, jurusan.NAMAJURUSAN, ujian.IDUJIAN, ujian.NAMAUJIAN FROM calonsiswa INNER JOIN jurusan ON calonsiswa.IDPILJUR1 = jurusan.IDJUR INNER JOIN ujian ON jurusan.IDJUR = ujian.IDJUR WHERE calonsiswa.IDPILJUR1 = '$colname_ujian'  AND ujian.IDUJIAN = '$kodeujian' ORDER BY calonsiswa.NOPENDAFTARAN ASC ";
$Recordset1 = mysql_query($query_Recordset1, $koneksi) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);





?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

    <span class="style1"><table class="myTable" width="60%" border="1">
  <tr>
  <?php do { ?>
    <td width="446"><div align="center"><a href="nilaijur.php?IDJUR=<?php echo $row_jurusan['IDJUR']; ?>"><?php echo $row_jurusan['NAMAJURUSAN']; ?></a></div></td>
  <?php } while ($row_jurusan = mysql_fetch_assoc($jurusan)); ?>
  </tr>
</table>
</span>

  <span class="style1"><table width="60%" border="0" cellpadding="0" cellspacing="0">
   <tr>
  <?php do { ?>
  <td width="446" bgcolor="#E6E6E6"><div align="center">
    <div align="center"><a href="nilaijur.php?IDUJIAN=<?php echo $row_ujian['IDUJIAN']; ?>&amp;IDJUR=<?php echo $row_ujian['IDJUR']; ?>">&bull; <?php echo $row_ujian['NAMAUJIAN']; ?></a></div></td>
    <?php } while ($row_ujian = mysql_fetch_assoc($ujian)); ?>
      </tr>
</table>
</span>
  <p>Program Keahlian : <?php echo $row_Recordset1['NAMAJURUSAN']; ?><br />
  Nama Ujian :
  <?php echo $row_Recordset1['NAMAUJIAN']; ?></p>
<form id="form1" name="form1" method="post" action="nilaiproses.php">
<table width="521" class="myTable">
  <tr class="myTableth">
    <td width="30"><div align="center">No</div></td>
    <td width="80"><div align="center">No <br />
      Pendaftaran</div></td>
    <td width="196"><div align="center">Nama Siswa</div></td>
    <td width="60"><div align="center">Nilai</div></td>
  </tr>
  <?php 

  for ($i=1;$i<=$totalRows_Recordset1;$i++) { ?>
    <tr>
      <td><?php echo $i; ?></td>
      <td width="80">   
        <?php echo $row_Recordset1['NOPENDAFTARAN']; ?></td>      
      <td>  
        <?php echo $row_Recordset1['NAMASISWA']; ?></td>
      <td width="60"><div align="center">
      
      <input type="hidden" name="IDPENDAFTARAN<?php echo $i ?>" value="<?php echo $row_Recordset1['IDPENDAFTARAN']; ?>" />
      <input type="hidden" name="IDUJIAN<?php echo $i ?>" value="<?php echo $row_Recordset1['IDUJIAN']; ?>"/>
      <input type="hidden" name="IDJUR<?php echo $i ?>" value="<?php echo $row_Recordset1['IDJUR']; ?>"/> 
      
      <?php 
	  $kodedaftar = $row_Recordset1['IDPENDAFTARAN'];
	  mysql_select_db($database_koneksi, $koneksi);
	$query_datanilai = "SELECT nilai.IDNILAI, nilai.IDPENDAFTARAN, nilai.IDUJIAN, nilai.NILAIUJIAN, nilai.IDJUR FROM nilai WHERE nilai.IDUJIAN 		= '$kodeujian' and nilai.IDPENDAFTARAN = '$kodedaftar'";
	$datanilai = mysql_query($query_datanilai, $koneksi) or die(mysql_error());
	$row_datanilai = mysql_fetch_assoc($datanilai);
	$totalRows_datanilai = mysql_num_rows($datanilai);
	  ?>
      
      <input type="hidden" name="IDNILAI<?php echo $i ?>" value="<?php echo $row_datanilai['IDNILAI']; ?>"/>
      <input type="textfield" name="NILAIUJIAN<?php echo $i ?>" size="4" value="<?php echo $row_datanilai['NILAIUJIAN'];?>" />
      </div></td>
    </tr>
     <?php ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); } ?>
    <tr>
      <td><input name="jumlah" type="hidden" value="<?php echo $totalRows_Recordset1; ?>" />&nbsp;
      		<input name="kodeujian" type="hidden" value="<?php echo $kodeujian;?>" />
            <input name="kodejur" type="hidden" value="<?php echo $colname_ujian;?>" />
      </td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><div align="center">
        <input type="submit" name="submit" id="submit" value="Submit" />
      </div></td>
    </tr>
</table>
<p>&nbsp;</p>
</form>
<p><?php echo $row_Recordset1['NILAIUJIAN']; ?></p>
</body>
</html>
<?php
mysql_free_result($jurusan);
mysql_free_result($ujian);

mysql_free_result($Recordset1);

//mysql_free_result($datanilai);
?>
