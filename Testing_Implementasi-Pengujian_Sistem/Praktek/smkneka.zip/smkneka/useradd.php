<?php require_once('Connections/koneksi.php'); 
include ('menu.php');?>

<script type="text/javascript"> 
 
function checkForm(form) { 
 
if(form.pwd1.value != "" && form.pwd1.value == form.pwd2.value) { 
if(!checkPassword(form.pwd1.value)) { 
alert("The password you have entered is not valid!"); 
form.pwd1.focus(); 
return false; } 
} else { 
alert("Error: Please check that you've entered and confirmed your password!"); 
form.pwd1.focus();
 return false; } 
 return true; } 
 </script> 
 
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "adduser")) {
  $insertSQL = sprintf("INSERT INTO petugas (NAMAPETUGAS, USERNAMEPETUGAS, PASSWORDPETUGAS, `LEVEL`) VALUES (%s, %s, %s, %s)",
                       GetSQLValueString($_POST['username2'], "text"),
                       GetSQLValueString($_POST['username'], "text"),
                       GetSQLValueString(md5($_POST['pwd1']), "text"),
                       GetSQLValueString($_POST['level'], "text"));

  mysql_select_db($database_koneksi, $koneksi);
  $Result1 = mysql_query($insertSQL, $koneksi) or die(mysql_error());

  $insertGoTo = "user.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?>
TAMBAH PETUGAS<br>

<form name="adduser" method="POST" action="<?php echo $editFormAction; ?>" onsubmit="return checkForm(this);">
  <table width="303" height="140" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="126">Nama Lengkap</td>
    <td width="177"><input type="text" name="username2"></td>
  </tr>
  <tr>
    <td>Username</td>
    <td><input type="text" name="username"></td>
  </tr>
  <tr>
    <td>Password</td>
    <td><input type="password" name="pwd1"></td>
  </tr>
  <tr>
    <td>Confirm Password</td>
    <td><input type="password" name="pwd2"></td>
  </tr>
  <tr>
    <td>Level User</td>
    <td><select name="level" id="level">
      <option value="PETUGAS">PETUGAS</option>
      <option value="PANITIA">PANITIA</option>
      <option value="ADMIN">ADMIN</option>
    </select></td>
  </tr>
</table>
<p>
  <input type="submit" value="submit">
</p> 
<input type="hidden" name="MM_insert" value="adduser">
</form>
