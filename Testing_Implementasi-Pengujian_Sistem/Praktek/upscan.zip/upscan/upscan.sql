-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 04, 2018 at 08:47 AM
-- Server version: 10.0.34-MariaDB-0ubuntu0.16.04.1
-- PHP Version: 7.0.28-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scan`
--

-- --------------------------------------------------------

--
-- Table structure for table `captcha`
--

CREATE TABLE `captcha` (
  `captcha_id` bigint(13) UNSIGNED NOT NULL,
  `captcha_time` int(10) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `word` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `captcha`
--

INSERT INTO `captcha` (`captcha_id`, `captcha_time`, `ip_address`, `word`) VALUES
(171, 1454666940, '::1', 'oxFK'),
(172, 1454667006, '::1', 'Z9y1'),
(173, 1454667066, '::1', '5lLz'),
(174, 1454667106, '::1', 'PyHi'),
(175, 1465024499, '::1', 'PZIp'),
(176, 1477443597, '127.0.0.1', 'IjMt'),
(177, 1477446229, '127.0.0.1', 'EKlI'),
(178, 1477447317, '127.0.0.1', 'iKCh'),
(179, 1477447617, '127.0.0.1', 'pDFa'),
(180, 1477447622, '127.0.0.1', 'F23U'),
(181, 1477448501, '127.0.0.1', 'm1iY'),
(182, 1477448504, '127.0.0.1', 'RiaG'),
(183, 1477456933, '127.0.0.1', 'FGdI'),
(184, 1477460786, '127.0.0.1', 'FrLg'),
(185, 1477460790, '127.0.0.1', 'wBgf'),
(186, 1477463151, '127.0.0.1', 'sMhs'),
(187, 1477463156, '127.0.0.1', 'aD5g'),
(188, 1477463161, '127.0.0.1', 'DWBg'),
(189, 1477463168, '127.0.0.1', 'KIXW'),
(190, 1477463172, '127.0.0.1', 'chpP'),
(191, 1477463175, '127.0.0.1', '3ITq'),
(192, 1477464181, '127.0.0.1', 'i6hy'),
(193, 1477464205, '127.0.0.1', 'ch9T'),
(194, 1477464915, '127.0.0.1', 'bViS'),
(195, 1477465018, '127.0.0.1', 'NSFz'),
(196, 1477465024, '127.0.0.1', 'JtcF'),
(197, 1477465053, '127.0.0.1', 'qctI'),
(198, 1477465059, '127.0.0.1', 'SEOG'),
(199, 1477465895, '127.0.0.1', 'xPeV'),
(200, 1477465924, '127.0.0.1', 'FH7g'),
(201, 1478251767, '127.0.0.1', 'dyDO'),
(202, 1478252168, '127.0.0.1', 'Y5Rh'),
(203, 1478252170, '127.0.0.1', 'gFqS'),
(204, 1478252173, '127.0.0.1', 'EUop'),
(205, 1522805579, '::1', 'vTYN'),
(206, 1522805589, '::1', 'WZYU'),
(207, 1522805666, '::1', 'gUXz'),
(208, 1522805669, '::1', 'YtJt'),
(209, 1522805671, '::1', 'tSRe'),
(210, 1522805673, '::1', 'F8ub');

-- --------------------------------------------------------

--
-- Table structure for table `scankp`
--

CREATE TABLE `scankp` (
  `id_kp` int(11) NOT NULL,
  `nim_kp` char(13) NOT NULL,
  `nama_kp` varchar(50) NOT NULL,
  `telp_kp` varchar(15) NOT NULL,
  `judul_kp` text NOT NULL,
  `semester_kp` char(5) NOT NULL,
  `file_kp` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `scankp`
--

INSERT INTO `scankp` (`id_kp`, `nim_kp`, `nama_kp`, `telp_kp`, `judul_kp`, `semester_kp`, `file_kp`) VALUES
(1, 'G.211.10.0001', 'Febian Wijaya', '0818099888', 'Analisa dan Perancangan Absensi', '20151', ''),
(2, 'G.211.10.0002', 'Bagus', '0899', 'Implementasi Jaringan Mikrotik', '20151', ''),
(3, 'G.211.10.0144', 'Bernadus Very Christioko', '08122576927', 'Analisa dan Perancangan Berorientasi Obyek', '20151', 'Yosembiance-master.zip'),
(7, 'G.231.12.0055', 'Santi Noviyanti', '0856789101112', 'Aplikasi Penyusunan Maze untuk Anak Usia TK Menggunakan Adobe Flash Profesional CC di CV Edukreasi', '20151', 'kp_G_231_12_0055.zip'),
(8, 'G.231.11.0184', 'Teguh Budi Satria', '088888888888888', 'Pengembangan Sistem Penggajian di CV Putra Karya Raharja', '20151', 'kp_G_231_11_0184.zip');

-- --------------------------------------------------------

--
-- Table structure for table `scanprop`
--

CREATE TABLE `scanprop` (
  `id_prop` int(11) NOT NULL,
  `nim_prop` char(13) NOT NULL,
  `nama_prop` varchar(50) NOT NULL,
  `telp_prop` varchar(15) NOT NULL,
  `judul_prop` text NOT NULL,
  `semester_prop` char(5) NOT NULL,
  `file_prop` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `scanprop`
--

INSERT INTO `scanprop` (`id_prop`, `nim_prop`, `nama_prop`, `telp_prop`, `judul_prop`, `semester_prop`, `file_prop`) VALUES
(1, 'G.211.10.0001', 'very', '999999999999999', 'judulku', '20151', 'prop_.zip'),
(2, 'G.211.10.0001', 'very', '999999999999999', 'judulku', '20151', 'prop_G_211_10_0001.zip');

-- --------------------------------------------------------

--
-- Table structure for table `scanta`
--

CREATE TABLE `scanta` (
  `id_ta` int(11) NOT NULL,
  `nim_ta` char(13) NOT NULL,
  `nama_ta` varchar(50) NOT NULL,
  `telp_ta` varchar(15) NOT NULL,
  `judul_ta` text NOT NULL,
  `semester_ta` char(5) NOT NULL,
  `status_ta` enum('Ya','Tidak') NOT NULL DEFAULT 'Ya',
  `file_ta` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `scanta`
--

INSERT INTO `scanta` (`id_ta`, `nim_ta`, `nama_ta`, `telp_ta`, `judul_ta`, `semester_ta`, `status_ta`, `file_ta`) VALUES
(2, 'G.211.12.0007', 'april firman daru', '089888888888888', 'Prediksi Kelulusan', '20151', 'Ya', 'ta_G_211_12_0007.zip'),
(4, 'G.211.12.0011', 'bayu', '999999999999999', 'judulku', '20142', 'Tidak', 'ta_G_211_12_0011.zip'),
(5, 'G.211.12.0007', 'bayu', '089888888888888', 'jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj', '20142', 'Ya', 'ta_G_211_12_0007.zip');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(3) NOT NULL,
  `name` char(8) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `pass`) VALUES
(1, 'G038', '7435c6343a85391504f1fcd7161ac066');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `captcha`
--
ALTER TABLE `captcha`
  ADD PRIMARY KEY (`captcha_id`),
  ADD KEY `word` (`word`);

--
-- Indexes for table `scankp`
--
ALTER TABLE `scankp`
  ADD PRIMARY KEY (`id_kp`);

--
-- Indexes for table `scanprop`
--
ALTER TABLE `scanprop`
  ADD PRIMARY KEY (`id_prop`);

--
-- Indexes for table `scanta`
--
ALTER TABLE `scanta`
  ADD PRIMARY KEY (`id_ta`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `captcha`
--
ALTER TABLE `captcha`
  MODIFY `captcha_id` bigint(13) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=211;
--
-- AUTO_INCREMENT for table `scankp`
--
ALTER TABLE `scankp`
  MODIFY `id_kp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `scanprop`
--
ALTER TABLE `scanprop`
  MODIFY `id_prop` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `scanta`
--
ALTER TABLE `scanta`
  MODIFY `id_ta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
