<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	var $data=array();
	
	public function __construct(){
		parent::__construct();
		$this->load->helper(array('form', 'url'));
		$this->load->model('Upload_m');
		$this->load->library('session');
		$this->load->library('form_validation');
	}
	
	public function index()
	{
		if($this->session->has_userdata('logged_in')){
			$this->load->view('dashboard');
		}else{
			$this->load->view('signin');
		}
	}
	
	public function kp()
	{
		if($this->session->has_userdata('logged_in')){
			$this->data['kp']=$this->Upload_m->getKp();
			$this->load->view('dashboard_kp',$this->data);
		}else{
			$this->load->view('signin');
		}
	
	}
	
	public function ta()
	{
		if($this->session->has_userdata('logged_in')){
			$this->data['ta']=$this->Upload_m->getTa();
			$this->load->view('dashboard_ta',$this->data);
		}else{
			$this->load->view('signin');
		}
	}
	
	public function prop()
	{
		if($this->session->has_userdata('logged_in')){
			$this->data['prop']=$this->Upload_m->getProp();
			$this->load->view('dashboard_prop',$this->data);
		}else{
			$this->load->view('signin');
		}
	}
	
	function check_validation()
	{
		$this->form_validation->set_rules('name', 'User', 'trim|required|callback_user_check');
		$this->form_validation->set_rules('pass', 'Password', 'trim|required|callback_pass_check');
		//---------------------------
		$this->form_validation->set_message('required', '{field} tidak boleh kosong.');
		$this->form_validation->set_message('min_length', 'Data {field} minimal memiliki {param} karakter.');
		$this->form_validation->set_error_delimiters('<div class="label label-danger">', '</div><br/>');
		
		if($this->form_validation->run()==true){
			$this->setSession();
		}else{
			$this->index();
		}
	}
	
	public function user_check()
	{
		$sql = 'SELECT COUNT(*) AS count FROM user WHERE name = ?';
		$binds = array($_POST['name']);
		$query = $this->db->query($sql, $binds);
		$row = $query->row();
		
		if ($row->count == 0){
			$this->form_validation->set_message('user_check', 'User tidak terdaftar');
			return FALSE;
		}else{
			return TRUE;
		}
	}
	
	public function pass_check()
	{
		$sql = 'SELECT COUNT(*) AS count FROM user WHERE name = ? AND pass = ?';
		$binds = array($_POST['name'],md5($_POST['pass']));
		$query = $this->db->query($sql, $binds);
		$row = $query->row();
		
		if ($row->count == 0){
			$this->form_validation->set_message('pass_check', 'Password tidak sesuai');
			return FALSE;
		}else{
			return TRUE;
		}
	}
	
	public function setSession()
	{
		$data = array(
				'username'  => $_POST['name'],
				'logged_in' => TRUE
		);
		
		$this->session->set_userdata($data);
		$this->index();
	}
	
	public function logout()
	{
		$array_items = array('username', 'logged_in');
		
		$this->session->unset_userdata($array_items);
		$this->index();
	}
}
