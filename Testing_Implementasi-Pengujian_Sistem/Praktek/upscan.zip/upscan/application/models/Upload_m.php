<?php
class Upload_m extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}

	function getKp()
	{
		$this->db->select('*');
		$this->db->from('scankp');
		$query=$this->db->get();
		return $query;		
	}
	
	function insertKp($data)
	{
		$query = $this->db->insert('scankp', $data);
		return $query;		
	}
	
	function getTa()
	{
		$this->db->select('*');
		$this->db->from('scanta');
		$query=$this->db->get();
		return $query;
	}
	
	function insertTa($data)
	{
		$query = $this->db->insert('scanta', $data);
		return $query;
	}
	
	function getProp()
	{
		$this->db->select('*');
		$this->db->from('scanprop');
		$query=$this->db->get();
		return $query;
	}
	
	function insertProp($data)
	{
		$query = $this->db->insert('scanprop', $data);
		return $query;
	}
	
	function getUser()
	{
		$this->db->select('*');
		$this->db->from('user');
		$query=$this->db->get();
		return $query;
	}
	
	function capt($cap)
	{
		$data = array(
				'captcha_time'  => $cap['time'],
				'ip_address'    => $this->input->ip_address(),
				'word'          => $cap['word']
		);		
		$query = $this->db->insert_string('captcha', $data);
		$this->db->query($query);
	}
}
?>