<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Unggah file & scan dokumen Tugas Akhir</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url("assets/css/bootstrap.min.css"); ?>" rel="stylesheet">    
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="<?php echo base_url("assets/css/ie10-viewport-bug-workaround.css"); ?>" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?php echo base_url("assets/css/jumbotron-narrow.css"); ?>" rel="stylesheet">
    <script src="<?php echo base_url("assets/js/ie-emulation-modes-warning.js"); ?>"></script>
  </head>

  <body>

    <div class="container">
      <div class="header clearfix">
        <nav>
          <ul class="nav nav-pills pull-right">
            <li role="presentation"><a href="<?php echo site_url("upload"); ?>">Home</a></li>
            <li role="presentation"><a href="<?php echo site_url("upload/kp"); ?>">Kerja Praktek</a></li>        
	        <li role="presentation" class="dropdown active">
	          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Tugas Akhir <span class="caret"></span></a>
	          <ul class="dropdown-menu">
	            <li><a href="<?php echo site_url("upload/prop"); ?>">Proposal TA</a></li>
	            <li><a href="<?php echo site_url("upload/ta"); ?>">Laporan TA</a></li>
	          </ul>
	        </li>
        <li role="presentation"><a href="<?php echo site_url("admin"); ?>">Login</a></li>
          </ul>
        </nav>
      
        <h3 class="text-muted">Unggah Dokumen</h3>
      </div>

      <div class="jumbotron">    
        <h2>Laporan Tugas Akhir (TA)</h2><hr>
        <p class="lead">
        <?php 
        	echo form_open_multipart('upload/check_validationTa');
        	echo form_label('NIM');
        	echo "<br/>";
        	$datanim=array(
        			'type'=>'text',
        			'name'=>'nim_ta',
        			'size'=>'20',
        			'maxlength'=>'13',
        			'class'=>'form-control',
        			'placeholder'=>'G.XXX.XX.XXXX',
        	);
        	$nimx = set_value('nim_ta') == false ? $this->input->post('nim_ta') : set_value('nim_ta');
        	echo form_input($datanim,$nimx);
        	echo form_error('nim_ta');
        	
        	echo "<br/>";
        	echo form_label('Nama Lengkap');
        	echo "<br/>";
        	$datanama=array(
        			'type'=>'text',
        			'name'=>'nama_ta',
        			'size'=>'50',
        			'maxlength'=>'50',
        			'class'=>'form-control',
        			'placeholder'=>'Nama Lengkap'
        	);
        	$namax = set_value('nama_ta') == false ? $this->input->post('nama_ta') : set_value('nama_ta');
        	echo form_input($datanama,$namax);
        	echo form_error('nama_ta');
        	
        	echo "<br/>";
        	echo form_label('Nomor Handphone');
        	echo "<br/>";
        	$datatelp=array(
        			'type'=>'text',
        			'name'=>'telp_ta',
        			'size'=>'50',
        			'maxlength'=>'50',
        			'class'=>'form-control',
        			'placeholder'=>'Nomor handphone'
        	);
        	$telpx = set_value('telp_ta') == false ? $this->input->post('telp_ta') : set_value('telp_ta');
        	echo form_input($datatelp,$telpx);
        	echo form_error('telp_ta');
        	
        	echo "<br/>";
        	echo form_label('Judul Laporan Tugas Akhir');
        	echo "<br/>";
        	$datajudul=array(
        			'name'=>'judul_ta',
        			'rows'=>'3',
        			'cols'=>'75',
        			'class'=>'form-control',
        			'placeholder'=>'Judul Laporan Tugas Akhir'
        	);
        	$judulx = set_value('judul_ta') == false ? $this->input->post('judul_ta') : set_value('judul_ta');
        	echo form_textarea($datajudul,$judulx);
        	echo form_error('judul_ta');
        	
        	echo "<br/>";
        	echo form_label('Semester');
        	echo "<br/>";
        	$datasmt=array(
        			''=>'-- Pilih Semester --',
        			'20142'=>'Genap 2014/2015',
        			'20151'=>'Gasal 2015/2016',
        			'20152'=>'Genap 2015/2016',
        			'20161'=>'Gasal 2016/2017',
        			'20162'=>'Genap 2016/2017',
        			'20171'=>'Gasal 2017/2018',
        			'20172'=>'Genap 2017/2018',
        	);
        	$smtx = set_value('semester_ta') == false ? $this->input->post('semester_ta') : set_value('semester_ta');
        	echo form_dropdown('semester_ta',$datasmt,$smtx,array('class'=>'form-control'));
        	echo form_error('semester_ta');
        	
        	echo "<br/>";
			echo form_label('File dokumen max.size: 3 MB (.zip)');
        	echo "<br/>";
        	//$filex = set_value('userfile') == false ? $_FILES['userfile']['name'] : set_value('userfile');
        	echo form_upload('userfile','',array('class'=>'form-control'));
        	echo form_error('userfile');
        	echo "<br/>";
        	
        	echo "<br/>";
        	echo form_label('Status mahasiswa');
        	echo "<table align='center' width='100%' class='table-bordered'><tr>";
        	$stsx = set_value('status_ta') == false ? $this->input->post('status_ta') : set_value('status_ta');
        	echo "<td align='center' width='50%'>".form_radio('status_ta','Ya',TRUE,array('class'=>'form-control'))."<span>Bimbingan</span></td>";
        	echo "<td align='center' width='50%'>".form_radio('status_ta','Tidak',FALSE,array('class'=>'form-control'))."<span>Bukan Bimbingan</span></td>";
        	echo "</tr></table>";
        	echo form_error('status_ta');
        	echo "<br/>";
     	
        	// awal captcha
        	echo "<br/>";
        	echo form_label('Captcha: Masukkan 4 karakter yang Anda lihat');
        	echo "<br/>";
        	echo $captcha['image'];echo "&nbsp;";
        	$capt=array('type'=>'text','name'=>'captcha','size'=>'20');
        	echo form_input($capt);echo "<br/>";
        	echo form_error('captcha');
        	echo "<br/>";echo "<br/>";
        	// akhir captcha
        	
        	echo form_submit('submit','Unggah',array('class'=>'btn btn-default'));
        	echo form_close();
        ?>
      </div>

      <div class="row marketing">
        <div class="col-lg-12">
        	<h4>Daftar Pengunggah Laporan Tugas Akhir (TA)</h4>
          	<table class="table table-bordered">
  				<tr>
  					<th>No</th>
  					<th>Nim</th>
  					<th>Nama</th>
  					<th>Judul Tugas Akhir</th>
  					<th>Smt</th>
  				</tr>
<?php 
  	$no=0;
	foreach($ta->result_array() as $row)
	{
		$no++;		
		echo "<tr>
				<td>".$no."</td>
				<td>".$row['nim_ta']."</td>
				<td>".$row['nama_ta']."</td>
    			<td>".$row['judul_ta']."</td>
    			<td>".$row['semester_ta']."</td>
			  </tr>";
	}
?>			</table>
        </div>
      </div>

      <footer class="footer">
        <p>&copy; 2015 Bernard Very.</p>
      </footer>

    </div> <!-- /container -->
    
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="<?php echo base_url("assets/js/ie10-viewport-bug-workaround.js"); ?>"></script>
    <script type="text/javascript" src="<?php echo base_url("assets/js/jquery-1.11.3.min.js"); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url("assets/js/bootstrap.min.js"); ?>"></script>
	<script>
    $(document).ready(function () {
        $('.dropdown-toggle').dropdown();
    });
</script>
  </body>
</html>
