<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Unggah file & scan dokumen</title>

    <!-- Bootstrap core CSS -->
	<link href="<?php echo base_url("assets/css/bootstrap.min.css"); ?>" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="<?php echo base_url("assets/css/ie10-viewport-bug-workaround.css"); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo base_url("assets/css/jumbotron-narrow.css"); ?>" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="<?php echo base_url("assets/js/ie-emulation-modes-warning.js"); ?>"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div class="container">
      <div class="header clearfix">
        <nav>
          <ul class="nav nav-pills pull-right">
            <li role="presentation" class="active"><a href="<?php echo site_url("upload"); ?>">Home</a></li>
            <li role="presentation"><a href="<?php echo site_url("upload/kp"); ?>">Kerja Praktek</a></li>
            <li role="presentation" class="dropdown">
	          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Tugas Akhir <span class="caret"></span></a>
	          <ul class="dropdown-menu">
	            <li><a href="<?php echo site_url("upload/prop"); ?>">Proposal TA</a></li>
	            <li><a href="<?php echo site_url("upload/ta"); ?>">Laporan TA</a></li>
	          </ul>
	        </li>
	        <li role="presentation"><a href="<?php echo site_url("admin"); ?>">Login</a></li>
          </ul>
        </nav>
      
        <h3 class="text-muted">Unggah Dokumen</h3>
      </div>

      <div class="jumbotron">
      	<p class="lead">Halaman ini diperuntukkan bagi mahasiswa Kerja Praktek dan Tugas Akhir yang sudah <strong>SELESAI</strong> bimbingan dan telah diuji. Setiap mahasiswa <strong>WAJIB</strong> untuk melakukan unggah file & hasil scan dokumen (Laporan KP, Proposal TA, dan Laporan TA). Silahkan baca ketentuan file & scan dokumen yang wajib diupload.</p>
        <!--p><a class="btn btn-lg btn-success" href="#" role="button">Sign up today</a></p//-->
      </div>

      <div class="row marketing">
        <div class="col-lg-6">
          <h4>Ketentuan Laporan Kerja Praktek (KP)</h4>
          <p>
          	<ol>
          		<li>Lembar Pengesahan (scan asli, file: jpg)</li>
          		<li>Lembar Bimbingan/Konsultasi (scan asli, file: jpg)</li>
          		<li>Laporan Kerja Praktek (file: pdf)</li>
          	</ol>
          	<span>File-file tersebut diatas dikompres (file: zip)</span>
         </p>
        </div>

        <div class="col-lg-6">
          <h4>Ketentuan Laporan Tugas Akhir (TA)</h4>
          <p>
          	<ol>
          		<li>Halaman Persetujuan (scan asli, file: jpg) <span class="label label-info">*</span></li>
          		<li>Halaman Pengesahan (scan asli, file: jpg)</li>
          		<li>Lembar Bimbingan/Konsultasi (scan asli, file: jpg) <span class="label label-info">*</span></li>
          		<li>Laporan Tugas Akhir (file: pdf)</li>
          	</ol>
          	<span>File-file tersebut diatas dikompres (file: zip)</span>
          	</p>
          
          <h4>Ketentuan Proposal Tugas Akhir (TA)</h4>
          <p>
          	<ol>
          		<li>Halaman Pengesahan (scan asli, file: jpg)</li>
          		<li>Proposal Tugas Akhir (file: pdf)</li>
          	</ol>
          	<span>File-file tersebut diatas dikompres (file: zip)</span>
          </p>
        </div>
      </div>

      <footer class="footer">
        <p>&copy; 2015 FTIK.</p>
      </footer>

    </div> <!-- /container -->


    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="<?php echo base_url("assets/js/ie10-viewport-bug-workaround.js"); ?>"></script>
     <script type="text/javascript" src="<?php echo base_url("assets/js/jquery-1.11.3.min.js"); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url("assets/js/bootstrap.min.js"); ?>"></script>
	<script>
    $(document).ready(function () {
        $('.dropdown-toggle').dropdown();
    });
  </body>
</html>
