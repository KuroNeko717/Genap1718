<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Dashboard Unggah file & scan dokumen</title>

     <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url("assets/css/bootstrap.min.css"); ?>" rel="stylesheet">  
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="<?php echo base_url("assets/css/ie10-viewport-bug-workaround.css"); ?>" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?php echo base_url("assets/css/dashboard.css"); ?>" rel="stylesheet">
	<script src="<?php echo base_url("assets/js/ie-emulation-modes-warning.js"); ?>"></script>
  </head>

  <body>

    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Unggah file & scan dokumen</a>
        </div>
        
      </div>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li><a href="<?php echo site_url("admin"); ?>">Overview <span class="sr-only">(current)</span></a></li>
            <li class="active"><a href="<?php echo site_url("admin/kp"); ?>">Laporan Kerja Praktek</a></li>
            <li><a href="<?php echo site_url("admin/prop"); ?>">Proposal Tugas Akhir</a></li>
            <li><a href="<?php echo site_url("admin/ta"); ?>">Laporan Tugas Akhir</a></li>
             <li><a href="<?php echo site_url("admin/logout"); ?>">Logout</a></li>
          </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">Dashboard</h1>

          

          <h2 class="sub-header">Daftar pengunggah Laporan Kerja Praktek (KP)</h2>
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>#</th>
                  <th>NIM</th>
                  <th>Nama</th>
                  <th>No.Handphone</th>
                  <th>Judul Kerja Praktek</th>
                  <th>Semester</th>
                  <th>File</th>
                </tr>
              </thead>
              <tbody>
<?php 
  	$no=0;
	foreach($kp->result_array() as $row)
	{
		$no++;
		$url=base_url()."uploads/".$row['file_kp'];
		echo "<tr>
				<td>".$no."</td>
				<td>".$row['nim_kp']."</td>
				<td>".$row['nama_kp']."</td>
    			<td>".$row['telp_kp']."</td>
    			<td>".$row['judul_kp']."</td>
    			<td>".$row['semester_kp']."</td>
				<td><a href=$url>".$row['file_kp']."</a></td>
			  </tr>";
	}
?>	               
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

   <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="<?php echo base_url("/assets/js/vendor/jquery.min.js"); ?>"><\/script>')</script>
    <script src="<?php echo base_url("assets/js/bootstrap.min.js"); ?>"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="<?php echo base_url("assets/js/vendor/holder.min.js"); ?>"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="<?php echo base_url("assets/js/ie10-viewport-bug-workaround.js"); ?>"></script>
  </body>
</html>